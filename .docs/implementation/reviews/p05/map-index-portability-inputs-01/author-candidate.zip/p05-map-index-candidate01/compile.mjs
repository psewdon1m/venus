import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import ts from 'typescript';
const root='.artifacts/p05-map-index-candidate01',source=readFileSync(root+'/topic-map.ts','utf8'),sha=b=>createHash('sha256').update(b).digest('hex');
let code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022,strict:true}}).outputText;
for(const name of ['pack','types']){const before="from './"+name+".js'",after="from '"+pathToFileURL(resolve('packages/relationship-engine/dist/'+name+'.js')).href+"'";if(code.split(before).length!==2)throw Error('Exact import count');code=code.replace(before,after);}
writeFileSync(root+'/topic-map.prospective.mjs',code);writeFileSync(root+'/compile-receipt.json',JSON.stringify({scope:'EXCLUDED_CANDIDATE_TRANSPILE_TWO_ABSOLUTE_DEPENDENCY_IMPORTS_NOT_PRODUCT_BUILD',source_sha256:sha(source),module_sha256:sha(code),typescript:ts.version},null,2)+'\n');
