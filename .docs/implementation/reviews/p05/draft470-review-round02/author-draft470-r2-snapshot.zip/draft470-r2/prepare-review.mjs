/** Draft-only review packet. No registry, approval, family map or activation output. */
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,writeFileSync,copyFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {reviewedCandidate} from '../../packages/card-catalog/dist/index.js';
import {digest,FrozenPack} from '../../packages/relationship-engine/dist/index.js';
const root='.artifacts/p05-content-expansion-470-r2',prior='.artifacts/p05-content-expansion-470';
const load=p=>JSON.parse(readFileSync(p,'utf8')),sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const write=(name,value)=>writeFileSync(root+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const cards=readdirSync(root+'/cards').sort().map(n=>load(root+'/cards/'+n));
const priorIndex=load(prior+'/source-index470.json'),changes=load(root+'/changes.json').changed_cards;
const newIds=new Set(priorIndex.cards.filter(c=>c.origin!=='RETAINED445_EXACT_RAW').map(c=>c.id));
assert.equal(newIds.size,25);
const review=(name,subset,note)=>{
  const lines=['# Draft470 r2 · '+name,'',note,'','AUTHOR DRAFT: no human approval, family assignment, publication or runtime activation.',''];
  for(const card of subset){lines.push(`## ${card.id} r${card.revision}`,`Canonical SHA256: ${digest(card)}`,`Raw SHA256: ${sha(root+'/cards/'+card.id+'.json')}`,`Mode: ${card.mode}; category: ${card.category}; interaction: ${card.interaction}; C${card.min_comfort}/S${card.min_progression_stage}; contexts: ${card.meeting_contexts.join(', ')}; relationship: ${card.relationship_scope}.`,`Guards: ${JSON.stringify({participants_required:card.participants_required,consent:card.consent,required_capabilities:card.required_capabilities,requires_physical_contact:card.requires_physical_contact,requires_going_away:card.requires_going_away})}`,'');
    for(const locale of ['ru','en','tr'])for(const[field,text]of Object.entries(card.text[locale]))lines.push(`${locale}/${field}: ${text}`);
    lines.push('');
  }
  writeFileSync(root+'/'+name+'.md',lines.join('\n'),{flag:'wx'});
};
review('REVIEW_ALL470',cards,'Full active470. Three revisions changed; other467 raw bytes remain equal to r1. Whole450 historical human review does not approve these new or changed drafts.');
review('REVIEW_NEW25',cards.filter(c=>newIds.has(c.id)),'Full25 new drafts including three r2 corrections. These texts are unapproved and require full editorial/safety/rights/RU/EN/TR/semantic review.');
review('REVIEW_CHANGED3',cards.filter(c=>changes.some(r=>r.id===c.id)),'Priority re-review of P05-CONTENT470-001/002/003. Original revisions retained under revisions/. Finding closure is for an independent reviewer; author status is CORRECTED_PENDING_REVIEW.');
write('source-index470.json',{schema_version:1,status:'DRAFT_SOURCE_INDEX_NOT_TOPICMAP_OR_APPROVED_REGISTRY',cards:cards.map(card=>{
  const previous=priorIndex.cards.find(row=>row.id===card.id);return {...previous,revision:card.revision,source_path:root+'/cards/'+card.id+'.json',raw_sha256:sha(root+'/cards/'+card.id+'.json'),canonical_sha256:digest(card),r2_author_change:changes.some(row=>row.id===card.id),semantic_classification:newIds.has(card.id)?'NEW_DRAFT_UNVERIFIED_NOT_ASSIGNED_SINGLE_OR_FAMILY':previous.semantic_classification};
})});
write('authoring/active-selection470.json',{schema_version:1,status:'DRAFT_ACTIVE_SELECTION_NOT_APPROVED',cards:cards.map(c=>({id:c.id,revision:c.revision,sha256:digest(c)}))});
const findings=load('.docs/implementation/reviews/p05/draft470-review-round01/findings.json');
copyFileSync('.docs/implementation/reviews/p05/draft470-review-round01/findings.json',root+'/prior-review-findings.json');
copyFileSync('.docs/implementation/reviews/p05/draft470-review-round01/report.md',root+'/prior-review-report.md');
write('finding-dispositions.json',{schema_version:1,role:'AUTHOR_CORRECTED_PENDING_INDEPENDENT_REVIEW',human_approval:false,findings:findings.findings.map((finding,index)=>({id:finding.id,status:'CORRECTED_PENDING_INDEPENDENT_REVIEW',changed_card:['Q-1180','YB-1178','TD-1177'][index],preserved_comparisons:[...finding.cards,...finding.compare],change:changes.find(row=>row.id===['Q-1180','YB-1178','TD-1177'][index]),human_semantic_approval:false}))});
const items=[
  {ids:['Q-1180','Q-1069','Q-1079','TD-1076','YB-1076','YB-1119'],concern:'r2 asks for a shared adventure requiring opposite size abilities; compare answer operation to retained friendship traditions/rituals, including private YB1119. Author has not assigned a family.'},
  {ids:['Q-1177','YB-1178','TD-1174','YB-1106','TD-1040'],concern:'r2 YB1178 asks how to carry a song turning into ribbon, rather than infer mood from optimistic words. Compare new transport operation against retained imaginary sound storage, and Q1177 against other optimism tasks.'},
  {ids:['TD-1175','TD-1177','TD-1043','YB-1042','Q-1007','Q-1038','TD-1176','YB-1037'],concern:'r2 TD1177 replaces absent/late-note excuses with shape association and repeat/mutate syllable constraint. Compare both truth and dare with retained rhythm/music tasks; no performance required.'},
  {ids:['Q-1176','Q-1044'],concern:'Album-cover-choice response mechanics require targeted comparison.'},
  {ids:['Q-1178','TD-1059','YB-1056'],concern:'Advertisement theme: compare actual answer mechanics across modes.'},
  {ids:['TD-1178','Q-1052','TD-1106'],concern:'Few-word tune tasks need distinctness review.'},
  {ids:['TD-1184','Q-1157','TD-1169','YB-1154'],concern:'Omitted/offscreen/unknown detail: compare response mechanics and boundaries category fit.'},
  {ids:['YB-1179','Q-1054'],concern:'Private YB1179 versus public umbrella-excuse task requires mixed-visibility comparison; no automatic grouping or SINGLE assignment.'},
  ...load(prior+'/editorial-open-items.json').items.filter(row=>!row.ids.includes('YB-1178'))
];
write('editorial-open-items.json',{schema_version:1,status:'AUTHOR_TARGETED_REVIEW_QUEUE_NOT_SEMANTIC_VERDICTS',machine_token_queue:0,items,human_approval:false,classification_boundary:'All25 new drafts and retained SINGLE placeholders remain unproven semantic units. Three editorial fixes do not establish 100-family R100 support.'});
let blocked=false;try{reviewedCandidate(cards,[],[],['codex-draft470-r2-author']);}catch(error){assert.equal(error.message,'CATALOG_HUMAN_REVIEW_INCOMPLETE');blocked=true;}
assert(blocked);write('human-review-gate-negative.json',{schema_version:1,result:'EXPECTED_BLOCK_CATALOG_HUMAN_REVIEW_INCOMPLETE',actual_reviewedCandidate_called:true,empty_signed_reviews:true,human_approved:0});
const analysis=load(root+'/draft-analysis.json'),pack=FrozenPack.load(cards,analysis.manifest,true);
write('review-binding.json',{schema_version:1,catalog_digest:analysis.catalog_digest,draft_pack_digest:pack.digest,mode_counts:analysis.manifest.mode_counts,category_counts:analysis.manifest.category_counts,source_ledger_raw_sha256:sha(root+'/authoring/candidate.sqlite'),rollback_raw_sha256:sha(root+'/authoring/rollback-draft470-r1.sqlite'),full_new25_review:'REVIEW_NEW25.md',full_changed3_review:'REVIEW_CHANGED3.md',full470_review:'REVIEW_ALL470.md',human_approved:0,runtime_activated:false,semantic_support:'UNPROVEN'});
console.log(JSON.stringify({result:'DRAFT_REVIEW_PACKET_CREATED_HUMAN_GATE_BLOCKED',cards:cards.length,new25:newIds.size,changed:changes.length,catalog_digest:analysis.catalog_digest,draft_pack_digest:pack.digest}));
