"""Materialize only genuinely reserved draft IDs. No source card or original ledger writes."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib,unicodedata,shutil
R=Path('.artifacts/p05-content-expansion-470');load=lambda p:json.loads(Path(p).read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inp=load(R/'input-receipt.json');reserved=load(R/'authoring/reservation-receipt.json');concepts=load(R/'concepts.v1.json')['concepts'];mapping=load(inp['source_450_map']);drop={'TD-1005':'P04-SEM-18','YB-1005':'P04-SEM-18','YB-1113':'P04-SEM-17','YB-1126':'P04-SEM-17','YB-1133':'P04-SEM-18'}
assert len(concepts)==25 and len(reserved['operations'])==5
assert sha(inp['original_ledger_path'])==inp['original_ledger_raw_sha256'];assert sha(R/'authoring/candidate.sqlite')==reserved['clone_ledger_sha256'];assert reserved['materialized_cards'] is False
export=load(R/'authoring/reserved-before-materialization-export.json');assert export['head']==reserved['after_head'];assert len(export['events'])==143
assert not(R/'cards').exists();(R/'cards').mkdir();(R/'quarantine').mkdir();retained=[];quarantine=[]
for e in mapping['entries']:
 src=Path(e['source_path']);assert sha(src)==e['card_raw_sha256'];target=R/('quarantine' if e['card_id'] in drop else 'cards')/src.name;shutil.copyfile(src,target);assert sha(target)==e['card_raw_sha256']
 row={'id':e['card_id'],'revision':e['card_revision'],'source':src.as_posix(),'candidate_path':target.as_posix(),'raw_sha256':sha(target),'canonical_sha256':e['card_sha256']}
 if e['card_id'] in drop:row.update(reason='EXCLUDE_WHOLE_MIXED_FAMILY_INDEPENDENT_OF_PRIVATE_HISTORY',family=drop[e['card_id']]);quarantine.append(row)
 else:retained.append(row)
assert len(retained)==445 and len(quarantine)==5
responders=load('.docs/content/p04-r2-full/cards/YB-1113.json')['text'];created=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ');used=Counter();made=[]
def nfc(v):
 if isinstance(v,str):return unicodedata.normalize('NFC',v)
 if isinstance(v,dict):return {k:nfc(x) for k,x in v.items()}
 if isinstance(v,list):return [nfc(x) for x in v]
 return v
for item in concepts:
 b=item['batch'];request=load(inp['requests'][b]['path']);operation=reserved['operations'][b];assert request['batch_id']==operation['batch_id'];assert operation['reserved_before_any_card_materialization'];idx=used[b];used[b]+=1;card_id=operation['actual_reserved_ids'][idx];interaction=request['allowed_interactions'][0];private=interaction=='pair_private';scope=next(iter(request['relationship_scope_distribution']));comfort=int(next(iter(request['comfort_distribution'])));stage=int(next(iter(request['progression_distribution'])));texts=item['text']
 if request['mode']=='yes_but':
  for locale in ['ru','en','tr']:texts[locale]['responder']=responders[locale]['responder']
 card=nfc({'schema_version':1,'id':card_id,'revision':1,'pack_id':request['pack_id'],'mode':request['mode'],'status':'draft','category':item['category'],'interaction':interaction,'participants_required':0 if interaction=='group' else 1 if interaction=='solo' else 2,'meeting_contexts':request['meeting_contexts'],'relationship_scope':scope,'min_comfort':comfort,'min_progression_stage':stage,'consent':'individual' if interaction in ['group','solo'] else 'bilateral','requires_physical_contact':False,'requires_going_away':False,'required_capabilities':['private_text_chat'] if private and request['meeting_contexts']==['online'] else [],'safety_tags':['private','personal'] if private else ['neutral'],'expected_duration_seconds':60,'text':texts,'authoring':{'origin':'agent','batch_id':request['batch_id'],'created_at':created,'reviewed_by':None,'reviewed_at':None,'rights_status':'needs_review','policy_revision':'RE-1','instruction_revision':1,'source_notes':'New agent draft for the standalone470 capacity expansion. Idea: '+item['intent']+' Exact IDs reserved by the existing authoring CLI in a versioned copy. Human editorial, originality, safety and qualified RU/EN/TR review NOT performed. Not approved or activated.'}})
 path=R/'cards'/(card_id+'.json');assert not path.exists();path.write_text(json.dumps(card,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n');made.append({'id':card_id,'batch_id':request['batch_id'],'category':item['category'],'mode':request['mode'],'interaction':interaction,'path':path.as_posix(),'raw_sha256':sha(path),'intent':item['intent'],'human_review':False,'semantic_family':'UNCLASSIFIED_NEW_DRAFT_NOT_DISTINCTNESS_CERTIFICATE'})
assert len(made)==25 and len({x['id'] for x in made})==25;assert len(list((R/'cards').glob('*.json')))==470
for b,n in used.items():assert n==len(reserved['operations'][b]['actual_reserved_ids'])
receipt={'schema_version':1,'role':'DRAFT_AUTHOR_NOT_ACCEPTOR','created_utc':created,'source_ledger_raw_sha256_unchanged':sha(inp['original_ledger_path']),'reservation_receipt_sha256':sha(R/'authoring/reservation-receipt.json'),'reserved_export_before_materialization_sha256':sha(R/'authoring/reserved-before-materialization-export.json'),'retained_exact_raw445':retained,'quarantined_whole_mixed5':quarantine,'new25':made,'active_draft_total':470,'human_reviewed':0,'runtime_eligible':False,'source_mutations':False}
assert receipt['source_ledger_raw_sha256_unchanged']==inp['original_ledger_raw_sha256'];(R/'materialization-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps({'retained':445,'quarantined':5,'new':25,'candidate':470,'source_ledger_unchanged':True,'human_reviewed':0}))
