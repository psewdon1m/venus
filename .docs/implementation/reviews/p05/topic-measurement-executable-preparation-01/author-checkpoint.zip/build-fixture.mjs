import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fixtureDocuments,loadFixture} from './fixture.mjs';
const output=resolve(process.argv.find(a=>a.startsWith('--output='))?.slice(9)??'.artifacts/p05-topic-measurements/fixture-checkpoint01');
assert(!existsSync(output),'OUTPUT_EXISTS_IMMUTABLE');mkdirSync(output,{recursive:true});
const f=fixtureDocuments(),sha=b=>createHash('sha256').update(b).digest('hex'),files={};
for(const [name,value] of Object.entries({cards:f.cards,manifest:f.manifest,taxonomy:f.taxonomy,semantic:f.semantic,map:f.mapDoc})){const bytes=f.bytes[name]??Buffer.from(JSON.stringify(value)+'\n');writeFileSync(output+'/'+name+'.json',bytes);files[name+'.json']={sha256:sha(bytes),bytes:bytes.length};}
const reloaded=loadFixture(output);assert.deepEqual(reloaded.map.pins,f.map.pins);assert.equal(reloaded.pack.digest,f.pack.digest);
const names=f.pack.cards.filter(c=>c.interaction!=='pair_private').map(c=>'card:'+c.id),dictionary=JSON.parse(readFileSync('.artifacts/p05-topic-measurements/contracts/public-features.json'));
assert.deepEqual(names,dictionary.legacy_prefix.filter(n=>n.startsWith('card:')));assert.equal(sha(JSON.stringify(dictionary.names)),'2eba539a5104c8102606b8880f5d0113448a8d8fba11f1838cca16d50ad88bdd');
const report={schema_version:1,status:'NON_GATING_AUTHOR_FIXTURE_CHECKPOINT',cards:f.cards.length,semantic_families:f.semantic.families.length,excluded:f.map.excluded_card_ids,pack_digest:f.pack.digest,pins:f.map.pins,feature_count:dictionary.names.length,feature_name_sha256:sha(JSON.stringify(dictionary.names)),files,human_approval:false,statistical_RUN:false};
writeFileSync(output+'/report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
