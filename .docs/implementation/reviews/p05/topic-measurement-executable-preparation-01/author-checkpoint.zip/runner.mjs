/** Fail-closed launch boundary. No statistics execution is authorized currently. */
import {readFileSync,existsSync,writeFileSync,mkdirSync,readdirSync,statSync} from 'node:fs';
import {resolve,join,sep} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {counts} from './workload.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
export function validateRunAuthorization(ack,{source,commit,dirty,inputs,gitBlob}){
 assert(ack?.schema_version===1&&ack.kind==='ROOT_STATISTICAL_RUN_ACK'&&ack.status==='AUTHORIZED','MISSING_EXPLICIT_ROOT_STATS_RUN_ACK');
 assert(ack.source_identity===source&&ack.commit===commit&&!dirty,'CLEAN_FROZEN_SOURCE_REQUIRED');
 assert(typeof ack.preregistered_tag==='string'&&ack.preregistered_tag.length>0,'PREREG_TAG_REQUIRED');
 assert(ack.max_artifact_bytes===32*1024**3&&Number.isSafeInteger(ack.total_wall_ms)&&ack.total_wall_ms>0,'RESOURCE_LIMITS_REQUIRED');
 for(const name of ['C2','invariants','fairness','gf','social','exclusion','runtime_canary'])assert(Number.isSafeInteger(ack.section_wall_ms?.[name])&&ack.section_wall_ms[name]>0,'SECTION_WALL_LIMIT_REQUIRED:'+name);
 assert(ack.independent_fixture_support_review==='PASS'&&ack.independent_producer_review==='PASS'&&ack.actual_serializer_parity==='PASS'&&ack.actual_runtime_canary==='PASS','PREREQUISITE_NOT_ACCEPTED');
 for(const [name,digest] of Object.entries(inputs)){assert(ack.inputs?.[name]===digest,'INPUT_PIN_MISMATCH:'+name);assert(sha(gitBlob(ack.preregistered_tag,name))===digest,'INPUT_NOT_IN_PREREG_TAG:'+name);}
 assert(Object.keys(ack.inputs).length===Object.keys(inputs).length,'UNEXPECTED_ACK_INPUTS');
 return true;
}
export function artifactBudget(directory,limit=32*1024**3){let bytes=0;const scan=p=>{for(const n of readdirSync(p,{withFileTypes:true})){const path=join(p,n.name);if(n.isSymbolicLink())throw Error('ARTIFACT_SYMLINK');if(n.isDirectory())scan(path);else bytes+=statSync(path).size;}};if(existsSync(directory))scan(directory);return{get bytes(){return bytes;},write(name,value){const buffer=Buffer.isBuffer(value)?value:Buffer.from(value);assert(bytes+buffer.length<=limit,'ARTIFACT_BUDGET_EXCEEDED');const path=resolve(directory,name);assert(path.startsWith(resolve(directory)+sep),'OUTPUT_SCOPE');assert(!existsSync(path),'ARTIFACT_OVERWRITE');mkdirSync(resolve(path,'..'),{recursive:true});writeFileSync(path,buffer,{flag:'wx'});bytes+=buffer.length;}};}
export function main(args=process.argv.slice(2)){
 if(args.length===0||args.includes('--describe')){console.log(JSON.stringify({status:'NOT_RUN',counts,source:'ef009b7c3cf262028bc9dc20c6f06798d125d864ac19bb530e9b038a3701c571',statistics_authorized:false,implementation_only:true}));return;}
 assert(args.includes('--final'),'EXPLICIT_FINAL_REQUIRED');const path=args.find(a=>a.startsWith('--root-ack='))?.slice(11);assert(path&&existsSync(path),'MISSING_EXPLICIT_ROOT_STATS_RUN_ACK');
 // No fixture build/dynamic engine import occurs before authorization checks.
 const ack=JSON.parse(readFileSync(path)),commit=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),dirty=execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim().length>0;
 const inventory=JSON.parse(execFileSync(resolve('.venv/Scripts/python.exe'),['-B','-c','import sys,json;sys.path.insert(0,"tools");from stage_inventory import inventory,identity;f=inventory();print(json.dumps({"identity":identity(f),"files":f}))'],{encoding:'utf8'}));
 const inputManifest=JSON.parse(readFileSync('.artifacts/p05-topic-measurements/final-inputs.json'));
 validateRunAuthorization(ack,{source:inventory.identity,commit,dirty,inputs:inputManifest,gitBlob:(tag,name)=>execFileSync('git',['show',tag+':'+name])});
 throw Error('EXECUTABLE_SECTION_DISPATCH_NOT_REVIEWED_YET_NO_RUN');
}
if(process.argv[1]&&resolve(process.argv[1])===resolve(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1')))main();
