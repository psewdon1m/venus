/** Finite corpus-support certificate, not sampled selector sessions/statistics. */
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadFixture,modes,unions} from './fixture.mjs';
import {makeSnapshot,makeHistory,makeSafety} from './profiles.mjs';
import {certificate,hardEligible} from './support.mjs';
import {eligible} from '../../packages/relationship-engine/dist/index.js';
const out=resolve(process.argv.find(a=>a.startsWith('--output='))?.slice(9)??'.artifacts/p05-topic-measurements/support-checkpoint01');assert(!existsSync(out),'OUTPUT_EXISTS_IMMUTABLE');mkdirSync(out,{recursive:true});
const guards=JSON.parse(readFileSync('.artifacts/p05-topic-measurements/contracts/expected-status.json')).guard_table,f=loadFixture(process.argv.find(a=>a.startsWith('--fixture='))?.slice(10)??'.artifacts/p05-topic-measurements/fixture-checkpoint02'),hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex'),sets={},rows=[],failures=[];let parity=0;
const entry=new Map(f.map.entries.map(e=>[e.card_id,e])),excludedIds=new Set(f.map.excluded_card_ids),eligibleByMode=new Map(modes.map(mode=>[mode,f.pack.cards.filter(card=>card.mode===mode&&card.interaction==='pair_private'&&!excludedIds.has(card.id))])),paritySignatures=new Set();
const ref=list=>{const key=hash(list);sets[key]??=list;return{sha256:key,count:list.length};};
for(const g of guards)for(const mode of modes){
 const descriptor={size:2,seed_literal:'venus:P05-FIXTURE-SUPPORT:EXHAUSTIVE-GUARDS-1',mode,context:g.context,rounds:100,capability:g.capability,class_profile:g.class,comfort:g.comfort},snapshot=makeSnapshot(f,descriptor),history=makeHistory(f,snapshot,g.topic_regime),safety=makeSafety(snapshot,g.topic_regime),actors=snapshot.baseline.players.map(p=>p.id),requested=g.topic_regime==='T6_TARGETED_CHANGES'?['creative']:[],c=certificate(f,snapshot,history,safety,actors,g.stage,requested);
 const signature=[mode,g.context,g.capability,g.class,g.comfort,g.stage].join(':');if(!paritySignatures.has(signature)){for(const card of eligibleByMode.get(mode)){assert.equal(hardEligible(card,snapshot,actors,g.stage),eligible(card,snapshot.baseline,actors,g.stage),'INDEPENDENT_HARD_PREDICATE_PARITY:'+card.id);parity++;}paritySignatures.add(signature);}
 const perUnion=unions.map(topic_ids=>({topic_ids,families:[...new Set(c.after_targeted_topics.filter(id=>JSON.stringify(entry.get(id).topic_ids)===JSON.stringify(topic_ids)).flatMap(id=>entry.get(id).semantic_family_ids))].sort()}));
 const supported=g.private_status==='SUPPORTED_COMPLETE',safeEmpty=g.private_status==='TOPIC_SAFE_EMPTY',surviving=perUnion.filter(v=>v.families.length);
 if(supported&&(!surviving.length||surviving.some(v=>v.families.length<75)))failures.push({guard:g,mode,reason:'RESIDUAL_SINGLE_UNION_SUPPORT_BELOW75'});
 if(!supported&&!safeEmpty&&c.after_context_class_comfort_capability.length)failures.push({guard:g,mode,reason:'EXCLUDED_GUARD_HAS_HARD_CANDIDATES'});
 if(safeEmpty&&c.after_targeted_topics.length)failures.push({guard:g,mode,reason:'EXPECTED_EMPTY_HAS_CANDIDATE'});
 const fields=Object.fromEntries(Object.entries(c).map(([k,v])=>[k,Array.isArray(v)?ref(v):v]));
 rows.push({key:{section:'SUPPORT_CERTIFICATE',capability:g.capability,topic_regime:g.topic_regime,N:'2..8 equivalent per unordered pair; homogeneous class/comfort',mode,context:g.context,class_profile:g.class,comfort:g.comfort,R:'1..100',stage:g.stage,target_pair:'players0/1; every pair has same hard metadata',transition_index:0,requested_full_topic_union:requested,prior_revision:history.revision,safety_revision:safety.revision},pack_digest:f.pack.digest,map_digest:f.map.pins.map_sha256,semantic_digest:f.map.pins.semantic_sha256,source_identity:'ef009b7c3cf262028bc9dc20c6f06798d125d864ac19bb530e9b038a3701c571',expected_status:g.private_status,...fields,per_union:perUnion.map(v=>({topic_ids:v.topic_ids,families:ref(v.families)})),conservative_max_initial_candidate_demand:75});
}
// T6 second-opportunity exclusion: every possible current full union is retained.
const transitions=[];
for(const mode of modes)for(const context of ['online','in_person'])for(const excluded of unions){
 const s=makeSnapshot(f,{size:2,seed_literal:'venus:P05-FIXTURE-SUPPORT:T6-UNION-EXCLUSION-1',mode,context,rounds:100,capability:'CHAT_ON',class_profile:'F',comfort:1}),h=makeHistory(f,s,'T0_ALL'),state=makeSafety(s);state.revision++;state.members[0].revision++;state.members[0].excluded_topic_ids=excluded;state.members[0].allow_topic_ids=state.members[0].allow_topic_ids.filter(t=>!excluded.includes(t));
 const c=certificate(f,s,h,state,s.baseline.players.map(p=>p.id),3);assert(c.after_targeted_topics.every(id=>f.map.entry(id).topic_ids.every(t=>!excluded.includes(t))));assert(c.distinct_residual_family_ids.length===0||c.distinct_residual_family_ids.length>=96);transitions.push({mode,context,excluded_full_union:excluded,status:c.distinct_residual_family_ids.length?'SUPPORTED_COMPLETE':'TOPIC_SAFE_EMPTY',residual:ref(c.distinct_residual_family_ids)});
}
const publicSupport=[];
for(const mode of modes)for(const interaction of mode==='yes_but'?['pair_public']:['group','solo','pair_public']){const families=[...new Set(f.pack.cards.filter(c=>c.mode===mode&&c.interaction===interaction&&!excludedIds.has(c.id)).flatMap(c=>entry.get(c.id).semantic_family_ids))].sort();assert.equal(families.length,128);publicSupport.push({mode,interaction,initial_families:ref(families),worst_three_public_prior:125,maximum_round_demand:100});}
assert.equal(rows.length,11760);assert.equal(failures.length,0,JSON.stringify(failures.slice(0,2)));
writeFileSync(out+'/family-sets.json',JSON.stringify(sets)+'\n');writeFileSync(out+'/rows.ndjson',rows.map(r=>JSON.stringify(r)).join('\n')+'\n');
const report={status:'NON_GATING_AUTHOR_SUPPORT_CERTIFICATE',guards:guards.length,compressed_rows:rows.length,represented_logical_C2_rows:8232000,hard_predicate_card_checks:parity,failures,public_support:publicSupport,T6_exclusion_transitions:transitions,source_independence:'Eligibility recomputed explicit card predicates; actual eligible helper only parity check. No selector used.',consumption_proof:'For any supported exact union initial96 minus at most3 priorfamilies leaves93 >=75. Each selected/declined/replaced family consumes at most1 budget slot and1family of its union; no mutation multiplies family by variants. After target/fullunion exclusion, either supported exact unions keep96 or intended empty retained. Runtime session-specific certificate still recomputed before each selection/replacement.',limits:'All R reachability/cap guards retained separately; public group/solo X and YB X safe-refusal not discarded. This corpus certificate is not statistical fairness/selector approval or actual450 capacity.',human_approval:false};
writeFileSync(out+'/report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,rows:rows.length,hard_parity:parity,failures:failures.length}));
