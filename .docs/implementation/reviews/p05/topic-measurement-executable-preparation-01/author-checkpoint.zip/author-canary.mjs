/** Fixed bounded non-gating author controls; never statistical registered samples. */
import assert from 'node:assert/strict';
import {writeFileSync,readFileSync,mkdtempSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fixtureDocuments} from './fixture.mjs';
import {makeSnapshot,makeHistory,makeSafety,playerId,policy} from './profiles.mjs';
import {renderActualGame,transcriptAccumulator,structuralPublic} from './public-transcript.mjs';
import {validateRunAuthorization,artifactBudget} from './runner.mjs';
import {selectNextTopicRound,recordTopicOutcome,proposeConsent,consentResponse,resolvePair} from '../../packages/relationship-engine/dist/index.js';
const f=fixtureDocuments(),results=[];
for(const cl of ['X','J','F','G','M','S','R']){const s=makeSnapshot(f,{size:2,seed_literal:'venus:P05-AUTHOR-MICROFIXTURE:CLASS-1',mode:'questions',context:'in_person',capability:'DEFAULT_OFF',rounds:1,comfort:4,class_profile:cl});assert.equal(resolvePair(...s.baseline.players).pairClass,cl);results.push({id:'class-'+cl,status:'PASS'});}
const fixed=[['questions','online','DEFAULT_OFF','T0_ALL'],['questions','online','CHAT_ON','T1_EMPTY'],['truth_or_dare','in_person','DEFAULT_OFF','T4_PRIVATE_PRIOR'],['yes_but','online','CHAT_ON','T5_PUBLIC_AND_PRIVATE_PRIOR']];
for(const [mode,context,capability,regime] of fixed){
 const s=makeSnapshot(f,{size:2,seed_literal:'venus:P05-AUTHOR-MICROFIXTURE:SERIALIZER-1',mode,context,capability,rounds:12,comfort:4,class_profile:'F'}),state=makeSafety(s,regime),names=s.baseline.players.map((p,i)=>({id:p.id,display_name:'OBSERVER_ROLE_'+i+'_END'})),observations=[],acc=transcriptAccumulator(f.pack,s.baseline.players,{onRaw:meta=>observations.push(meta)});let h=makeHistory(f,s,regime),privateCount=0,cardDisclosures=0;
 for(let i=0;i<12;i++){
  const selected=selectNextTopicRound(s,h,f.pack,f.map,state);h=selected.history;let plan=selected.round;if(plan.interaction==='pair_private')privateCount++;
  const now=1000000+i*100,game={id:s.baseline.session_id,room_id:s.baseline.room_id,state:'active',pause_reason:null,rev:String(i+1),mode,round_count:12,current_round:i+1};
  const data={schema_version:2,plan,state:'pending',clock_floor:now,invitation:plan.actors.length===2?proposeConsent('synthetic-'+i,plan.actors,'invitation',now):null,action:null,choice:mode==='truth_or_dare'?(i%2?'dare':'truth'):null,condition:null,conversation_id:null,boot_id:'AUTHOR_PURE_FIXTURE_ONLY',content_revision:1};
  const first=renderActualGame(game,data,f.pack,h,'en',names,now);acc.observe({raw:JSON.stringify(first),channel:'game',transport:'HTTP',observed_at_ms:now,http_status:200,operation_kind_diagnostic_only:'pure_before_release'});
  if(data.invitation){for(const actor of [...plan.actors].sort()){data.invitation=consentResponse(data.invitation,actor,'accept',now+1,{offer_id:data.invitation.offer_id,scope:data.invitation.scope,proposal_revision:data.invitation.proposal_revision});}}
  if(plan.card){const outcome=recordTopicOutcome(s,h,f.pack,f.map,{expected_history_revision:h.revision,round_id:plan.round_id,offer_epoch:plan.interaction==='pair_private'?plan.attempts.at(-1).offer_epoch:null,card:plan.card,outcome:'disclosed'});h=outcome.history;plan=outcome.round;data.plan=plan;data.state='active';}
  const released=renderActualGame(game,data,f.pack,h,'en',names,now+2);if(plan.interaction==='pair_private')assert.equal(released.current_round.kind,'generic');else{assert.equal(released.current_round.kind,'public');cardDisclosures++;}
  acc.observe({raw:JSON.stringify(released),channel:'game',transport:'HTTP',observed_at_ms:now+2,http_status:200,operation_kind_diagnostic_only:'pure_after_release'});
 }
 const features=acc.finish({committed_round_count:12,requested_rounds:12});assert.equal(features.names.length,1075);assert.equal(features.raw[features.names.indexOf('frames')],0);assert.equal(features.raw[features.names.indexOf('v2:game:emitted_frames')],0);assert(features.features.every(Number.isFinite));
 if(context==='online'&&capability==='DEFAULT_OFF')assert.equal(privateCount,0);
 assert.equal(features.raw.filter((_,i)=>features.names[i].startsWith('card:')).reduce((a,b)=>a+b,0),cardDisclosures);
 results.push({id:[mode,context,capability,regime].join('/'),status:'PASS',actual_selector_rounds:12,private_opportunities:privateCount,observations:observations.length,actual_WS_frames:0,scope:'Pure actual selector/consent/production serializer; fabricated fixture row revisions, no runtime transport parity claim'});
}
for(const [key,payload] of [['epoch',{epoch:1}],['topic',{topic_ids:['creative']}],['secret',{credential:'synthetic-secret'}]]){assert.throws(()=>structuralPublic(payload));results.push({id:'structural-'+key,status:'PASS'});}
assert.throws(()=>validateRunAuthorization(null,{}),/MISSING_EXPLICIT_ROOT_STATS_RUN_ACK/);results.push({id:'missing-root-stats-ACK',status:'PASS'});
const testOut=mkdtempSync(join(tmpdir(),'venus-measurement-author-budget-')),budget=artifactBudget(testOut,4);budget.write('first','1234');assert.throws(()=>budget.write('second','x'),/ARTIFACT_BUDGET_EXCEEDED/);assert.equal(budget.bytes,4);results.push({id:'artifact-budget',status:'PASS',retained_synthetic_temp:testOut});
const report={status:'NON_GATING_AUTHOR_MICROFIXTURE_CONTROLS',checks:results.length,results,statistics_RUN:false,acceptance_by_author:false,runtime_serializer_parity:'PENDING_SEPARATE_ACTUAL_PG_WS_CANARY',counts_or_seeds_of_registered_measurement_changed:false},output=process.argv.find(a=>a.startsWith('--output='))?.slice(9)??'.artifacts/p05-topic-measurements/author-canary-result.json';assert(!existsSync(output),'OUTPUT_EXISTS_IMMUTABLE');writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
