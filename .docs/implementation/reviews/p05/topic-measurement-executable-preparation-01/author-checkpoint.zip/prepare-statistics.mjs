/** Exact historical pure mathematical functions, no historical runner execution. */
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import ts from '../../node_modules/typescript/lib/typescript.js';
const path='tools/p03-measurements.mjs',raw=readFileSync(path),source=raw.toString('utf8'),tree=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),names=['pairedRatioCI','aucCI','trainLDA'],functions=tree.statements.filter(ts.isFunctionDeclaration).filter(f=>names.includes(f.name?.text));assert.equal(functions.length,3);
const sha=createHash('sha256').update(raw).digest('hex'),output="/** Generated exact historical pure mathematics; source SHA256 "+sha+". */\nimport assert from 'node:assert/strict';\n"+functions.map(f=>f.getText(tree)).join('\n')+'\n';
writeFileSync('.artifacts/p05-topic-measurements/statistics.mjs',output);console.log(JSON.stringify({source:path,source_sha256:sha,exported:names,status:'EXACT_SOURCE_EXTRACTION_NO_STATISTICAL_RUN'}));
