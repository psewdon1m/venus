import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
import {loadFixture} from '../p05-topic-measurements/fixture.mjs';
import {makeSnapshot,makeHistory,makeSafety} from '../p05-topic-measurements/profiles.mjs';
import {renderActualGame} from '../p05-topic-measurements/public-transcript.mjs';
import {selectNextTopicRound,recordTopicOutcome} from '../../packages/relationship-engine/dist/index.js';
const base='.artifacts/p05-topic-measurements-next',design=JSON.parse(readFileSync(base+'/benchmark-design.json')),out=base+'/benchmark-result.json';assert(!existsSync(out),'OUTPUT_EXISTS_IMMUTABLE');
const started=performance.now(),cpu0=process.cpuUsage(),f=loadFixture('.artifacts/p05-topic-measurements/fixture-checkpoint02'),fixture_wall_ms=performance.now()-started,cpu1=process.cpuUsage(cpu0),results=[];let peak=process.memoryUsage().rss;
for(const [i,entry] of design.cases.entries()){
 const descriptor={...entry,seed_literal:design.seed_literals[i]},snapshot=makeSnapshot(f,descriptor),safety=makeSafety(snapshot,entry.regime);let history=makeHistory(f,snapshot,entry.regime),completed=0,refusal=null,private_opportunities=0;
 const names=snapshot.baseline.players.map((p,j)=>({id:p.id,display_name:'OBSERVER_ROLE_'+j+'_END'})),wall=performance.now(),cpu=process.cpuUsage();
 for(let n=0;n<entry.rounds;n++){
  assert(performance.now()-started<design.hard_wall_ms,'BENCHMARK_WALL_STOP');
  try{let result=selectNextTopicRound(snapshot,history,f.pack,f.map,safety);history=result.history;let plan=result.round;if(plan.interaction==='pair_private')private_opportunities++;
   if(plan.card){result=recordTopicOutcome(snapshot,history,f.pack,f.map,{expected_history_revision:history.revision,round_id:plan.round_id,offer_epoch:plan.interaction==='pair_private'?plan.attempts.at(-1).offer_epoch:null,card:plan.card,outcome:'disclosed'});history=result.history;plan=result.round;}
   const now=1000000+n*100,data={schema_version:2,plan,state:'active',clock_floor:now,invitation:null,action:null,choice:null,condition:null,conversation_id:null,boot_id:'AUTHOR_CPU_BENCHMARK_ONLY',content_revision:1},game={id:snapshot.baseline.session_id,state:'active',pause_reason:null,rev:String(n+1),mode:entry.mode,round_count:entry.rounds,current_round:n+1};
   const view=renderActualGame(game,data,f.pack,history,'en',names,now);assert(view.current_round);JSON.stringify(view);completed++;peak=Math.max(peak,process.memoryUsage().rss);
  }catch(error){if(error.code==='TOPIC_SAFE_POOL_EXHAUSTED'){refusal={code:error.code,completed_prefix:completed};break;}throw error;}
 }
 const elapsed=performance.now()-wall,used=process.cpuUsage(cpu),cpu_ms=(used.user+used.system)/1000;results.push({descriptor,rounds_completed:completed,safe_refusal_prefix:refusal,private_opportunities,case_wall_ms:elapsed,case_cpu_ms:cpu_ms,one_cpu_seconds_per_round:completed?cpu_ms/1000/completed:null,observed_rss_bytes:process.memoryUsage().rss});
}
const report={schema_version:1,status:'NON_GATING_AUTHOR_CPU_RESOURCE_DIAGNOSTIC',fixture_wall_ms,fixture_cpu_ms:(cpu1.user+cpu1.system)/1000,results,rounds_completed:results.reduce((a,b)=>a+b.rounds_completed,0),total_wall_ms:performance.now()-started,peak_observed_rss_bytes:peak,process_max_rss_kib:process.resourceUsage().maxRSS,node_version:process.version,statistics_RUN:false,no_ETA:true,limitations:design.interpretation};writeFileSync(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
