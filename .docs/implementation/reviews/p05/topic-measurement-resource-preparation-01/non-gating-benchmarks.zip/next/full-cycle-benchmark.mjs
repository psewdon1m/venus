import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
const base='.artifacts/p05-topic-measurements-next',design=JSON.parse(readFileSync(base+'/full-cycle-benchmark-design.json'));assert(!existsSync(base+'/full-cycle-benchmark-launch.json'),'ONE_FIXED_ATTEMPT_ONLY');assert(!existsSync(base+'/full-cycle-benchmark-result.json'));
const started=performance.now(),r=spawnSync(process.execPath,['--max-old-space-size='+design.node_heap_mib,base+'/full-cycle-benchmark-child.mjs'],{encoding:'utf8',timeout:design.hard_wall_ms,maxBuffer:1024*1024});writeFileSync(base+'/full-cycle-benchmark-raw.txt',r.stdout+r.stderr);
const report={status:r.error?.code==='ETIMEDOUT'?'HARD_WALL_STOPPED_NOT_ACCEPTED':r.status===0?'NON_GATING_CHILD_COMPLETE':'AUTHOR_CONTROL_FAILED',exit_code:r.status,signal:r.signal,error:r.error?.code??null,elapsed_ms:performance.now()-started,completed_child_report:existsSync(base+'/full-cycle-benchmark-result.json'),progress_retained:existsSync(base+'/full-cycle-progress.ndjson'),descriptor:design.descriptor,attempt:1,no_seed_retry:true,statistics_RUN:false};writeFileSync(base+'/full-cycle-benchmark-launch.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
