/** Bounded infrastructure diagnostics only. No disk writes or command retries. */
import assert from 'node:assert/strict';
export function captureProcess(child,{onFault=()=>{}}={}){
 const state={stdout:'',stderr:'',stdout_truncated:false,stderr_truncated:false,spawn_error:null},chunks={stdout:[],stderr:[]},counts={stdout:0,stderr:0};
 for(const [name,limit] of [['stdout',16384],['stderr',8192]])child[name].on('data',value=>{const b=Buffer.from(value),left=Math.max(0,limit-counts[name]);if(left)chunks[name].push(b.subarray(0,left));counts[name]+=b.length;state[name]=Buffer.concat(chunks[name]).toString('utf8');if(counts[name]>limit){state[name+'_truncated']=true;onFault('SUPERVISOR_DIAGNOSTIC_CAPTURE_OVERFLOW');}});
 child.on('error',error=>{state.spawn_error=['ENOENT','EACCES','EPERM','ENOMEM'].includes(error.code)?error.code:'UNLISTED_SPAWN_ERROR';onFault('SUPERVISOR_SPAWN_ERROR');});return state;
}
export function snapshotDiagnostics(state){return state?{...state}:{stdout:'',stderr:'',stdout_truncated:false,stderr_truncated:false,spawn_error:'SUPERVISOR_NOT_STARTED'};}
export function packageFailure(stderr,stage){
 try{assert(Buffer.byteLength(stderr)<=4096);const x=JSON.parse(stderr.trim());assert.deepEqual(Object.keys(x).sort(),['transport','status','stage','exception_class','reason','os_errno','winerror','primary'].sort());assert.equal(x.transport,'PYTHON_PACKAGE_FAILURE_V1');assert.equal(x.status,'NOT_ACCEPTED');assert.equal(x.stage,stage);assert.equal(x.primary,true);assert(['OutputStopped','OSError','PermissionError','ValueError','AssertionError','FileNotFoundError','OTHER'].includes(x.exception_class));assert(x.reason===null||/^[A-Z][A-Z0-9_]{0,127}$/.test(x.reason));for(const n of ['os_errno','winerror'])assert(x[n]===null||Number.isSafeInteger(x[n]));return x;}catch{return{transport:'PYTHON_PACKAGE_FAILURE_UNAVAILABLE',status:'NOT_ACCEPTED',stage};}
}
