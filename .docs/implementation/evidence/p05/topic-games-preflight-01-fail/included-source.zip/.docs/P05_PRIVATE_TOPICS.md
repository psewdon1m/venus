# P05 · Собственные темы: текущая реализация и границы

**Статус:** API adapter реализован, production injection выключена; полный topic/private conversation сценарий не принят. [ADR-023](adr/ADR-023-p05-room-topic-safety-lifecycle.md), [проект функции](P05_TOPIC_ADVICE_DESIGN.md), [schema](contracts/private-topic-settings.v1.schema.json).

## Контракт

Все пути начинаются `/api/v1/rooms/:roomId/me/private-topics`. Room credential, CSRF, browser Origin/Fetch Metadata проверяются теми же guards, что private chat. Query string и лишний `owner_member_id` запрещены. GET показывает только собственные settings; host не читает настройки другого участника.

| Метод | Тело | Результат |
|---|---|---|
| GET | — | Собственные `rev`, `safety_revision`, taxonomy и allow/exclude sets |
| PUT | `request_id`, `expected_rev`, `taxonomy_digest`, `allow_topic_ids`, `exclude_topic_ids` | Явное изменение разрешённых тем с optimistic own revision; ранее исключённое не включается |
| POST `/exclusions` | `request_id`, `taxonomy_digest`, `topic_ids` | Только монотонное сужение без зависимости от прежней settings/game revision |

После mutation HTTP делает новый fenced GET текущего состояния. Idempotent replay не возвращает старый permissive receipt. Sets сортируются и шифруются в padded16KiB ciphertext; AAD связывает room/owner/incarnation/revision. Публичные room events не содержат topic settings. Request cache имеет предел4096 записей/комнату; исчерпание отказывает операции, а не ослабляет ограничения. Полное поведение при capacity/failure и зависимые private grants ещё требует интеграции.

Перед первым durable narrowing нужен текущий auth fence: поздний response fence не может отменить файловую запись. Перед выдачей ответа повторяются credential/acceptance/TTL, собственная safety revision и внешний lifecycle fence. Таймер или само наличие allow-set не являются согласием на prompt.

## Реализованные файлы

- `apps/api/src/private-topic-preferences.ts`: owner adapter, pin validation, encrypted settings, ledger union, request replay, fences и требуемые lifecycle hooks.
- `apps/api/private-topic-migrations/001_private_topics.sql` и migration runner: отдельная family, protocol classification, linked birth, preferences/requests. Нормальный UPDATE protocol запрещён; exact external descriptor остаётся обязательным даже при наличии DB constraints.
- `app.ts`/`room-routes.ts`: только явная инъекция adapter. В `server.ts` нет подключения этой функции и её birth factory. Существующие protocol1 комнаты автоматически не обновляются.

## Доказательства

[Первый preflight](implementation/evidence/p05/topic-settings-preflight-01/index.json): identity `283afb9e842aaa5d561d55c05ad1bf2ba0c2135d6e8b17ecc424338403c0a806`, 34 focused и440 host tests PASS/43 platform skips; actual8/8 Linux ledger/PostgreSQL/loopback HTTP. [Независимый round01](implementation/reviews/p05/topic-settings-round01.md) нашёл TOPICSET001: сессия могла истечь до durable narrowing. Его CHANGES_REQUESTED и исходный FAIL сохранены.

[Исправленный preflight](implementation/evidence/p05/topic-settings-preflight-02/index.json): identity `62483f11349dadd121bedf3e6790fccb6a7402b8bcf2b435589df29424fe226f`, 35 focused иactual9/9 PASS, image `sha256:9ffff109ba5269f5a8ed2a7e74e1ee3548a97edd025dc3afeefd6b04ca441d41`, source unchanged, cleanup completed. SQL07 действительно ждёт fixture advisory lock внутри count-read; после expiry API даёт401, файловый ledger не изменён, DB preferences не опубликованы. SQL08 отдельно проверяет expiry во время final auth-read. [Независимый round02](implementation/reviews/p05/topic-settings-round02.md):22 собственные проверки и35 авторских rerun PASS; TOPICSET001 закрыт в пределах adapter. Lifecycle и полный P05 не приняты.

Оба прогона имеют recoverable exact included-source ZIP и raw outputs. Это dirty synthetic adapter proof: loopback HTTP не называется браузерным HTTPS, возврат старой encrypted row не называется full PostgreSQL backup restore. Epoch revoke и birth/retirement descriptor в этих тестах — явные fixture seams. Новые source bytes не наследуют глобальную source identity старого прогона; применимость component evidence определяется точными файлами.

## Что ещё требуется

Per-room lifecycle, birth/admission flow, member/session withdrawal, grant/epoch/chat/advice revoke, protected volume/readiness и restore; version2 game planner/transport, topic picker и structured advice UI; C2/fairness/privacy и полный browser/gate цикл. LIFE001–004 из [design review](implementation/reviews/p05/ledger-lifecycle-design-round01.md) открыты. До этого adapter не включается в serving. Каталог450 по-прежнему human HOLD.
