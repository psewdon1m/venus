# Part 01. Interface And Interaction Unification

> This is a normative component of the [Part 00 documentation authority](./PART_00_SYSTEM_UNIFICATION_SPECIFICATION.md).

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT** and **MAY** are
normative. Numeric defaults may change only after workload measurement, while
the safety property behind every limit MUST be preserved.

## Central Authority And Material Divergence

This Part takes precedence over conflicting project-local documentation.
Project documents MUST adapt these rules to current project-specific values
without weakening them. A material implementation difference follows the
reporting and decision protocol in [Part 00](./PART_00_SYSTEM_UNIFICATION_SPECIFICATION.md#1-mandatory-material-divergence-protocol); stale local documentation is corrected and is not an alternative authority.

---
## 1. Product Character

An operational interface is a tool, not a marketing page. It should be quiet,
technical, dense and optimized for repeated work. Content appears immediately;
decorative hero sections, floating cards, gradients, glass effects, textures
and ornamental shapes are outside this visual language.

The unified style is based on:

- a true black working surface;
- white information and structural lines with one nested-opacity level;
- one configurable accent, with blue `#00A8FF` as the baseline;
- Space Grotesk for service and page display names and Consolas for every other
  interface role;
- rectangular geometry;
- hierarchy expressed through line opacity, spacing and position rather than
  shadows or nested decorative containers.

### Terminal operator profile

The host-local terminal operator profile uses the same quiet, dense visual
language, expressed in terminal cells. Its keyboard baseline is arrows,
Enter, Esc and Tab; every mutation is available through visible menus and an
explicit confirmation. Letter-key navigation, function keys, mouse support,
special fonts and graphical terminal extensions are not prerequisites.
Terminal fonts belong to the client. Monochrome rendering must preserve focus
and textual status. Narrow/short terminals scroll the focused control into
view, preserve form values across resize and keep an exit path available.

Terminal clients must mask credential input, treat bracketed paste as data,
strip terminal-control sequences from external labels, restore terminal state
on normal exit/interruption and distinguish stale observations from current
health. A terminal UI may observe a durable host job but must not own its
execution lifetime. Terminal acceptance includes real PTY input, ordinary and
application-cursor arrows, resize and reconnect; a PTY fixture does not by
itself certify a named desktop or mobile SSH client. Browser pixel dimensions,
DOM-specific behavior and raster typography are not terminal requirements.

### 1.1 Reference Templates And Precedence

The PNG files in [`./src`](./src/) are normative visual references where this
part links them. They define composition, palette, hierarchy, relative scale,
control anatomy and interaction-state appearance. The reference canvas is
approximately `1919x1030`; the full-page PNG exports are `1919x1034`. These
pixel dimensions describe the supplied reference view, not a fixed CSS canvas.

The exact measurement audit of the linked PNG templates is incorporated into
the coordinate, component and template ledgers below. This Part is the
implementation source of truth; developers do not need to reconcile two files
at runtime or copy product-specific labels from the measurement audit.

The written token, behavior, accessibility and responsive rules in this part
take precedence over incidental anti-aliasing colors, export cropping and
one-pixel rounding in a PNG. When a measured template dimension is marked
`approximately`, preserve the relationship and layout token rather than
forcing an absolute coordinate at every viewport.

Template content is interpreted as follows:

- `example` is a placeholder for the actual service name;
- the blue doughnut is a placeholder for the actual service icon and MUST NOT
  ship unless it is the real product asset;
- example metrics, labels, menu commands, versions, hosts and values illustrate
  information hierarchy and are not product data requirements;
- visual order is normative only where a section explicitly defines it;
- a service-specific departure from a linked template is a material UI/UX
  difference and follows the Mandatory Material-Divergence Protocol.

## 2. Theme, Typography And Geometry

### 2.1 Theme Inputs

The interface uses exactly five base hues: black, white, the configured accent,
success green and danger red. `#111111`, 80%-white and the fixed `#D9D9D9`
decorative-dot shade are approved variants of black and white, not additional
theme inputs.

| Token | Baseline | Configurable | Purpose |
| --- | --- | --- | --- |
| `--black` | `#000000` | No | Page, sidebar, card, control and dialog background |
| `--surface-hover` | `#111111` | No | Hover, focus and raised interactive surface |
| `--white` | `#FFFFFF` | No | Primary text and level-one outlines |
| `--white-80` | `rgb(255 255 255 / 80%)` | No | Secondary text and every nested outline; renders as `#CCCCCC` on black |
| `--decorative-dot` | `#D9D9D9` | No | Rest-state four-dot drag marks only |
| `--accent` | `#00A8FF` | Yes | Active state, display titles, focus, selection and live emphasis |
| `--success` | `#62FF8C` | No | Healthy, successful or explicitly good state |
| `--danger` | `#F83D3D` | No | Failed, unavailable, destructive or explicitly bad state |

Only `--accent` is editable under Appearance. Editing previews the accent
immediately across the login and authenticated shell, but the new value becomes
authoritative only after `Apply color`. `Reset color` restores `#00A8FF` and is
subject to the same explicit apply step. Cancel or navigation before apply
restores the last persisted accent.

The canonical tokens are:

```css
:root {
  --black: #000000;
  --surface-hover: #111111;
  --white: #ffffff;
  --white-80: rgb(255 255 255 / 80%);
  --decorative-dot: #d9d9d9;
  --accent: #00a8ff;
  --success: #62ff8c;
  --danger: #f83d3d;
  --line-outer: var(--white);
  --line-inner: var(--white-80);
  --text-primary: var(--white);
  --text-secondary: var(--white-80);
}
```

All structural borders are normally `1px`. The outline hierarchy has exactly
two levels:

1. A top-level bordered element that is not inside another bordered element
   uses `--line-outer` at 100% white.
2. Every bordered element inside a bordered element uses `--line-inner` at 80%
   white. Deeper descendants remain at 80%; a third visual level MUST NOT be
   introduced by reducing opacity again.

Accent, success and danger may replace a structural outline only when they
communicate an interactive or semantic state. Color never replaces text,
position, iconography or an accessible state name. Arbitrary per-feature colors
MUST NOT be introduced. Explicit opacity remains permitted for non-outline
effects already defined by this guide, including disabled state, drag source,
overlay backdrop and visualization de-emphasis; it does not create another
outline-hierarchy level.

### 2.2 Typography

Only Regular and Bold weights are used. Do not request or synthesize medium,
semibold, extrabold or black weights.

```css
.service-wordmark,
.page-title {
  font-family: "Space Grotesk", "Segoe UI", sans-serif;
  font-weight: 700;
  letter-spacing: 0;
}

body,
button,
input,
select,
textarea,
code {
  font-family: Consolas, "Cascadia Mono", "Segoe UI Mono", monospace;
  font-weight: 400;
  letter-spacing: 0;
}

strong,
b,
.metric-value,
.section-title {
  font-weight: 700;
}
```

- Desktop page titles are left-aligned, accent-colored Space Grotesk Bold,
  exactly `80px` at the reference width, with a responsive
  `clamp(48px, 4.2vw, 80px)` and line height from `0.95` to `1.05`.
- The login service wordmark is approximately `72px`; the sidebar service name
  is exactly `42px` at the reference canvas. Long real names shrink within
  explicit bounds and never clip, wrap one glyph per line or overlap the
  service icon.
- Titled-card and metric headings are `24px` Consolas Bold and use the accent.
  Settings group headings are `20px` Consolas Bold. A measured `28px` label in
  a design annotation is annotation text, not a runtime UI type token.
- Navigation, controls, descriptions, log cells, ordinals and ordinary body
  text are `14px` at the reference canvas.
- Muted explanatory text uses `--text-secondary` and a line height between
  `1.5` and `1.7`.
- Button labels begin with a capital letter.
- Preserve the product's actual title casing. Do not force large service or
  page names to uppercase.
- Ordinary content MUST NOT use negative letter spacing or unbounded
  viewport-width font scaling.

Description text may step down at explicit character thresholds. Its vertical
origin remains fixed, so editing never moves the first line.

### 2.3 Geometry And Spacing

- All stated component widths and heights use `box-sizing: border-box` unless a
  source measurement explicitly describes an outer export rather than a box.
- Corners are square by default. Radius is `0` and MUST NOT exceed `8px` when a
  platform convention requires rounding.
- Borders and dividers are `1px` unless an explicit focus outline is defined.
- Base control height is `40px`; compact controls MAY be `36px` but never below
  the accessible target required by the target platform.
- The spacing scale is `4px`, `8px`, `10px`, `20px`, `30px` and `40px`.
  Components SHOULD compose these tokens instead of introducing arbitrary
  nearby values.
- The fixed desktop sidebar is `250px` wide. The main page header is
  exactly `123px` high at the reference canvas, and main content uses a `30px`
  outer inset.
- Full-width section bodies use approximately `40px` inner padding. Compact
  controls and navigation rows use `10-12px` internal padding where `20px`
  would make the interface unnecessarily sparse.
- The standard vertical gap between dashboard rows and between primary grid
  groups is `30px`. Two `1x` cards inside a `2x` group use a `40px` gap.
- Stable controls and status changes MUST NOT reflow neighboring content.
- A bordered workspace may contain structured sections, but decorative cards
  MUST NOT be nested recursively.

At the reference desktop content width, universal card widths are derived as a
hierarchy:

```text
4x = 1610px
2x = (4x - 30px primary gap) / 2 = 790px
1x = (2x - 40px nested gap) / 2 = 375px
```

These are reference results, not rigid minimums. Below the reference width,
tracks use `minmax(0, 1fr)`, card contents reflow, and the layout collapses by
logical group while preserving DOM, keyboard and reading order.

### 2.4 Reference Coordinate Model

Exact pixel coordinates in this document use the top-left of the supplied
desktop export as `(0, 0)`. The measured PNG is `1919x1034px`, while the design
layout targets a `1920px`-wide browser canvas; the export may omit the final
rightmost raster column. This does not change the following reference tracks:

| Region | Reference geometry |
| --- | --- |
| Viewport/export | `1919x1034px` capture of the `1920px` design canvas |
| Expanded sidebar | `left: 0; top: 0; width: 250px; height: 1033px` |
| Main layout track | `left: 250px; width: 1670px` on the design canvas |
| Main header divider | horizontal line at `top: 123px` |
| Main content inset | `left: 280px`, or `30px` after the sidebar |
| Full content/card width | `1610px`, ending at design coordinate `1890px` |

The canonical implementation is `width: 250px; border-right: 1px solid
var(--white); box-sizing: border-box`. The main region therefore begins at
`left: 250px`. A legacy source layer represented the same separator as a rotated
line near `x=251`; that construction is not normative. Visual output must be one
continuous device-pixel line with no second seam.

The canonical reference-spacing ledger is:

| Relationship | Exact value |
| --- | --- |
| Navigation label origin | `31px` from the sidebar's left edge |
| Navigation ordinal origin | `left: 209px`, or `41px` before the sidebar's right edge |
| Active-row frame inset | `18px` from the sidebar's left edge |
| Nominal navigation text-row step | `45px` |
| Main content origin | `280px`, equal to `250px + 30px` |
| Metric-card content origin | `37px` from the card's left edge |
| `2x` dashboard column-origin step | `820px`, equal to `790px + 30px` |
| Dashboard row-origin step | `196px`, equal to `166px + 30px` |
| `1x` nested-card origin step | `415px`, equal to `375px + 40px` |
| Card ordinal inset | `10px` from the left and top |

Global coordinates are verification targets only for the reference viewport
with the sidebar fixed open. Production layout MUST derive them from sidebar,
header, inset and grid tokens rather than absolutely positioning the entire
application. When the viewport or sidebar mode changes, responsive rules in
section 9 take precedence; component-local dimensions and internal insets stay
exact wherever space permits.

A one-device-pixel difference caused by screenshot cropping, CSS border
rasterization or fractional scaling is acceptable for isolated divider
coordinates. It does not permit cumulative drift, different component sizes or
changing a documented gap token.

## 3. Shared Interaction Contract

### 3.1 Hover, Focus, Pressed And Disabled States

Buttons, clickable rows, inputs, selects and interactive work items share one
state language. The visual references are [example - hover - no hover](<./src/example - hover - no hover.png>),
[example - hover - hover 1](<./src/example - hover - hover 1.png>) and
[example - hover - hover 2](<./src/example - hover - hover 2.png>).

The states are:

| State | Fill | Element border | Text | Extra outline | Geometry |
| --- | --- | --- | --- | --- | --- |
| Rest | `--black` | Structural 100% or nested 80% white | Existing primary/secondary roles | None | Base size |
| Hover 1 | `--surface-hover` | Accent | Existing content colors | None | Proportional growth |
| Hover 2 / keyboard focus | `--surface-hover` | Accent | Interactive label or ordinal becomes accent | `1px` accent with approximately `3px` visual separation | Same grown element size as Hover 1 |
| Pressed | Hover fill | Accent | Active state color | Focus outline remains for keyboard activation | Uniform `scale(.985)` |
| Disabled/pending | Existing fill | Existing border | Existing color at `0.45` opacity | None | Base size; no growth |

Hover 1 is the normal pointer treatment for a bordered card or neutral control.
Hover 2 is the emphasized treatment and the minimum keyboard-focus treatment.
The outer outline in Hover 2 does not participate in layout sizing, so both
hover templates have the same control-box size even though the second PNG has
additional pixels around it.

The three source PNG dimensions record the supplied historical exports:

| State export | Outer export | Interactive card box | Offset inside export |
| --- | --- | --- | --- |
| Rest | `375x166px` | `375x166px` | `0, 0` |
| Hover 1 | `380x169px` | `380x169px` | `0, 0` |
| Hover 2 / focus | `388x177px` | `380x169px` | `4px, 4px` |

They demonstrate state anatomy, not the normative scaling result. The formula
below takes precedence over the old `380x169px` raster. For a `375x166px` base,
it produces `growth = 8.3px` and a target control box of approximately
`383.3x174.3px`. Hover 2 adds the non-layout focus outline and its separation
around that same computed box. Its ordinal becomes accent while four-dot marks
become `#FFFFFF`.

Hover and focus transitions last about `160ms` with an ease curve. The element
grows through `transform`, never through layout dimensions. Its background is
the exact `#111111` token; do not substitute a runtime 10%-white color mix that
produces a different hex value.

Growth adds the same absolute number of pixels to both dimensions:

```js
const growth = Math.min(width, height) * 0.05;
const scaleX = (width + growth) / width;
const scaleY = (height + growth) / height;
```

Items touching a grid edge set `transform-origin` to that edge so growth moves
inward. Other elements use a centered origin. Growth MUST NOT overlap unrelated
controls, trigger scrollbars, change track calculation or move adjacent items.

The canonical pressed effect is `transform: scale(.985)` with a transition
duration of about `60ms`; release returns through
the ordinary `160ms` transition. This short uniform scale is an intentional
press-feedback exception to proportional hover growth.

Disabled or pending controls preserve their dimensions, use `0.45` opacity and
do not scale. A long-running command replaces its verb with a progressive label
such as `Saving...` or `Checking...`. `prefers-reduced-motion: reduce` removes
transform and non-essential animation while retaining border, fill, text and
focus distinctions.

### 3.2 Drag And Drop

Use direct manipulation only where order has semantic or personal meaning.

There are two reorder presentations:

- a one-dimensional navigation or list reorder uses an accent insertion line at
  the exact before/after position;
- a two-dimensional card reorder uses a live placeholder with the dragged
  card's span and reflows every affected card into its prospective position.

During either drag:

1. Source opacity becomes approximately `45%`.
2. The pointer is compared continuously with the target midpoint.
3. A `1px` accent insertion line or full-size grid placeholder shows the exact
   destination; changing pointer position updates the preview before drop.
4. Drop updates the order immediately and adaptive two-digit ordinals are
   recomputed from the new visible order.
5. Authenticated layout order is persisted as operator presentation state so it
   survives reload and a new login. Browser-only persistence is acceptable only
   for an explicitly local unauthenticated surface.
6. Failed persistence restores the last confirmed order and shows an error.

Universal cards start pointer dragging from the four-dot handle at the upper
right. Navigation rows may use the row as the drag target. Dragging MUST
suppress the item's ordinary open, navigation or command action. A keyboard
reorder command MUST expose the same destinations and announce the resulting
position.

### 3.3 Overlays

Focused forms, destructive confirmation, Access Key changes, control-plane token
rotation, imports, restore actions and update discovery use a custom overlay:

- a fixed full-viewport backdrop;
- `rgba(0,0,0,.35)` plus about `9px` backdrop blur;
- a dialog centered on every open;
- maximum dimensions constrained to the viewport with internal scrolling;
- header dragging clamped to an `8px` viewport inset;
- an explicit close control and Escape handling;
- no accidental close from a click inside the dialog.

The dialog outer border is level-one white; controls nested inside it use the
level-two 80%-white outline. Opening moves focus to the heading or first field,
Tab is trapped inside, and closing restores focus to the invoking control.
Backdrop click may close a read-only or untouched dialog. It MUST NOT silently
discard entered credentials, a selected restore archive or an accepted
destructive step.

A restore overlay controls file-selection state, archive metadata,
confirmation, progress and outcome. The operating-system file picker launched
from it remains native; a web application MUST NOT imitate or replace that
trusted picker.

Notifications render above overlays; overlays render above workspaces and
context menus that belong to the underlying page.

### 3.4 Clipboard Copy And Constrained Webviews

Writing generated text, links or commands to the system clipboard is a
progressive enhancement. Automatic copying MUST NOT be the only way to obtain
a value or a prerequisite for completing a workflow.

A clipboard write SHOULD use `navigator.clipboard.writeText()` and MUST be
attempted only from a secure context, while the document is active and focused,
and directly in response to a trusted pointer or keyboard action. If the value
must first be generated or fetched asynchronously, the operation MUST finish
before the user is offered a `Copy` or `Copy and continue` action. Page load,
timer, redirect completion and background-event handlers MUST NOT be relied on
for clipboard writes because user activation may be absent or may have expired.

The interface MUST:

1. feature-detect clipboard support instead of inferring it from the user agent;
2. handle rejected clipboard promises as an expected capability outcome;
3. show `Copied` only after the write promise resolves;
4. keep the complete value visible and selectable when copying fails;
5. provide an explicit retry control and concise manual-copy guidance;
6. preserve the user's progress when copying is unavailable.

A deprecated `document.execCommand("copy")` fallback MAY be attempted for legacy
webviews, but only during the same user action and never as the sole fallback.
`Open in browser` or `Share` MAY be offered as secondary actions on constrained
mobile clients. A native clipboard bridge MAY be used only in an application-
owned webview and MUST preserve the same explicit action and success feedback.

Embedded browsers, including the browser opened from Telegram, MUST be treated
as capability-variable environments. Their web engine, application version,
permission handling or embedding policy may prevent a clipboard write even
when it works in a standalone browser. Telegram Mini Apps provide a native
clipboard-read operation but no documented clipboard-write operation, so the
web fallback remains mandatory.

Sensitive values such as credentials, recovery codes and access tokens MUST
NOT be copied silently. Copying them requires an explicit action and a visible
description of what will replace the current clipboard contents.

### 3.5 Context Menus

The visual reference is [example context menu](<./src/example context menu.png>).
A context menu MAY invert the ordinary palette for maximum contrast: white
background, black text and accent text for the hovered, focused or selected
command. This is an approved component-specific inversion, not a second theme.

Context menus:

- use rectangular geometry, no decorative shadow and compact Consolas text;
- size to their longest localized command within a viewport maximum;
- open next to the invocation point, then flip or clamp to remain fully inside
  an `8px` viewport inset;
- keep command order and separators stable while open;
- move focus with Arrow Up/Down, activate with Enter or Space, close with Escape
  or an outside pointer press and restore focus to the invoker;
- expose disabled state without removing the command from its expected place;
- never use hover color as the only indication of keyboard focus.

The Russian commands and numbering in the PNG are illustrative. Product
commands, localization and authorization determine the actual menu content.

The reference export uses `width: 155px; height: 197px; overflow: hidden`. Its
inner white panel uses `width: 156px; height: 197px; left: -1px`, with a `1px`
white border. The
ordered-list origin is `left: 16px; top: 9px`; list content uses `14px` Consolas
Bold, black text, `21px` list-item left indentation and `22px` line height. The
highlighted fourth example command is accent. Production commands may differ,
but row height, text origin and menu geometry remain the component baseline;
hover or focus MUST NOT resize the `155x197px` outer box.

## 4. Authentication And Primary Navigation

### 4.1 Login View

The visual reference is [example Log in page](<./src/example Log in page.png>).
The service is single-operator: authentication uses one Access Key field and
MUST NOT ask for a login name, username, email or separate password.

The login view uses the `public authenticated` exposure profile. It MUST be
reachable through the canonical HTTPS origin from every client IP; neither the
application nor the server Nginx may require `OPERATOR_CIDR`, a source-IP
allow-list or a VPN merely to render the login and submit an Access Key. Before
successful authentication, the response exposes no operator data. Protected
pages and APIs require a valid Access Key-derived server session, enforce
authorization on every request and never treat network location as proof of
identity. IP address remains usable for rate limiting and abuse telemetry, not
as the operator authentication boundary.

At the reference desktop viewport:

- the complete login composition is horizontally centered and visually centered
  around the viewport midpoint with at least `24px` viewport padding;
- the bordered authentication panel is exactly `560x268px` and becomes
  `min(560px, calc(100vw - 48px))` on smaller screens;
- the accent service name and actual service icon sit immediately above the
  panel as one brand group; the name is `72px` Space Grotesk Bold and the icon
  fits a `100x100px` visual box without distortion;
- the panel has one level-one white border, black fill, no radius and no shadow;
- reachability, the Access Key field and the submit button share the same left
  origin; the field and button share the full inner content width;
- nested fields and buttons use the 80%-white outline until hover, focus or a
  semantic state replaces it.

The exact `1919x1034px` reference ledger is:

| Login element | Global geometry or painted bounds |
| --- | --- |
| Example service wordmark | painted bounds `left: 677px; top: 350px; width: 317px; height: 72px`; width changes with the real name |
| Example service-icon artwork | painted bounds `left: 1139px; top: 345px; width: 87px; height: 72px` inside the `100x100px` icon box |
| Authentication panel | `left: 680px; top: 444px; width: 560px; height: 268px` |
| Reachability box | `left: 705px; top: 466px; width: 255px; height: 50px` |
| Reachability label paint | `left: 717px; top: 486px; width: 154px; height: 13px` for the example label |
| Reachability square | `left: 926px; top: 482px; width: 18px; height: 18px` |
| Access Key field | `left: 705px; top: 578px; width: 511px; height: 31px` |
| Access Key placeholder paint | `left: 717px; top: 588px; width: 98px; height: 12px` for `Access Key...` |
| Submit button | `left: 705px; top: 635px; width: 511px; height: 50px` |
| Submit-label paint | `left: 910px; top: 655px; width: 99px; height: 11px` for `Enter service` |

Painted bounds document this exact example raster and are not fixed boxes for a
different service name, localization or font rasterizer. The `31px` visible
Access Key field is a Login-specific visual exception to the `40px` base-control
height; its wrapper/hit target MUST still meet the platform minimum without
changing the visible reference border.

Reachability is independent of authentication:

| State | Text and square | Motion |
| --- | --- | --- |
| Checking | Explicit neutral text using white/80%-white | None required |
| Reachable | `#62FF8C` text and solid square; nested border is the 80% semantic color `#4ECC70` | One smooth opacity fade cycle every `2s` |
| Unreachable | `#F83D3D` text and solid square; nested border uses 80% danger | None |

The green square never disappears completely during its fade. Reduced-motion
mode makes it static. Availability is checked immediately and periodically; an
invalid Access Key does not change a reachable service to unavailable.

The Access Key control:

- is empty on every fresh render and reset;
- uses a masked secret input with an accessible `Access Key` label even if the
  compact visual presentation uses a placeholder;
- accepts the explicitly supplied value as opaque exact text: there is no
  minimum or maximum length, strength/entropy score, required or forbidden
  character class, URL-safe/ASCII-only restriction or denylist;
- has no password-strength meter and shows no composition hint such as a
  character count or a requirement for letters, digits or symbols;
- never trims, normalizes, changes case, truncates or otherwise rewrites the
  submitted value; an absent value is an unconfigured/empty field, not a weak
  value;
- uses `autocomplete="current-password"` so standards-based password managers
  can offer the saved Access Key without requiring a fabricated username field;
- is never initialized from markup, server-rendered state, query parameters,
  local storage or a previously submitted value;
- submits through the same pending-safe action from Enter and the full-width
  `Enter service` button;
- stays visible after rejection and receives focus with a concise error that
  does not disclose which part of the credential was wrong.

Authentication, recovery, provisioning and settings forms MUST render every
Access Key, password, PIN, recovery-code and access-token input empty on first
open. Reopening or resetting such a form MUST clear those values again. A
placeholder is descriptive UI text, not a value, and MUST NOT contain a real
credential. Application code must not simulate credential-manager behavior
with defaults.

### 4.2 Sidebar

The visual references are [example Left Menu](<./src/example Left Menu.png>) and
[Example of left menu and main page side by side, base layer of main page, name of main page](<./src/Example of left menu and main page side by side, base layer of main page, name of main page.png>).

The expanded desktop sidebar is fixed to the left edge, occupies the full
viewport height and is `250px` wide including its `1px` level-one right border.
Its canonical box is:

```css
.sidebar {
  box-sizing: border-box;
  width: 250px;
  border-right: 1px solid var(--white);
}
```

Its final background is opaque `#000000`. The source composition places an
optional full-size `object-fit: cover` image below that fully opaque black
layer; an implementation SHOULD omit the hidden image request when no visible
state reveals it. The reference composition uses:

- an actual service icon in a `192x192px` box at `left: 31px; top: 6px`, using
  `object-fit: cover` only when cropping is approved for the real asset;
- the accent service name in `42px` Space Grotesk Bold, centered in a
  `170x76px` text box whose horizontal center is `x=125px` and whose top is
  `175px`;
- primary navigation beginning with a `221x42px` active-row box at
  `left: 18px; top: 285px`;
- label text at `left: 31px` and adaptive ordinals at `left: 209px`, both
  `14px` Consolas Bold;
- Documentation and Logout as an unnumbered group with text tops at `943px`
  and `988px` respectively in the `1033px` reference sidebar.

The reference text-top ledger is:

| Visible position | Label | Text top | Ordinal | Ordinal top |
| --- | --- | --- | --- | --- |
| 1 | Active primary destination | `299px` | `01` | `299px` |
| 2 | Primary destination | `346px` | `02` | `346px` |
| 3 | Primary destination | `391px` | `03` | `391px` |
| 4 | Primary destination | `436px` | `04` | `436px` |
| 5 | Primary destination | `481px` | `05` | `481px` |
| 6 | Settings in the supplied reference | `526px` | `06` | `526px` |

The nominal text-top step after the second entry is `45px`; the first measured
step is `47px`. Implement the list as a `42px` row plus a `3px` row gap and use
the active row's own content alignment to reproduce the reference without
hard-coded per-route coordinates. The supplied destination names are examples;
actual primary destinations occupy the same ordered slots.

Every primary destination row contains its label at left and an adaptive
two-digit ordinal at right. Ordinals represent current visible position: after
a reorder they are recomputed sequentially as `01`, `02`, `03` and so on. They
are not persistent IDs.

The legacy sidebar PNGs contain the sequence `01`, `02`, `04`, `05`, `06`,
`07`. The missing `03` is a template defect and MUST NOT be reproduced.

The active primary destination uses accent label text, a rectangular `1px`
accent border and an external accent arrow on the left. The arrow has a short
rectangular base and points toward the active row. It occupies reserved or
overflow-visible marker space and MUST NOT change row width or move its label.
At the first reference row, the rectangular base is `4x22px` at
`left: -2px; top: 295px`; the right-pointing SVG triangle is `12x5.77px` at
`left: 0` and is vertically centered around `top: 306px`.

Inactive primary rows have a transparent border reservation. On hover they use
the shared proportional growth, `#111111` fill, accent border and accent label.
The ordinal remains legible and may also become accent in the emphasized
variant. The row touching the sidebar edge grows inward.

Documentation and Logout are explicit exceptions: they are never bordered,
never numbered, never scaled and never draggable. Hover, focus and the active
Documentation state change their text to accent while retaining a separate
keyboard-visible focus indication that does not resemble the primary-row box.

Primary destinations may be reordered through pointer or keyboard interaction.
The new order and recomputed ordinals persist after reload and a new login.
Documentation and Logout remain outside that order. Navigation changes views
without a full page reload, and the active destination name appears exactly
once in the main page header.

The reference desktop state keeps the sidebar open. The operator may choose a
persisted fixed or auto-hide mode under Appearance:

- fixed mode reserves exactly `250px`; the main region uses the remaining width
  and its own `30px` content inset;
- auto-hide mode translates the sidebar fully left while an `18px` activation
  strip remains; reveal and hide take about `180ms`;
- when the sidebar closes, the main region expands through grid/flex track
  calculation, and cards reflow in their existing logical order without
  absolute-position jumps, overlap or horizontal scrolling;
- at `720px` and below, an explicit menu button opens the sidebar as an overlay
  instead of reserving permanent width.

## 5. Workspaces, Feedback And Documentation

### 5.1 Main Page Shell And Workspaces

The base-shell reference is
[Example of left menu and main page side by side, base layer of main page, name of main page](<./src/Example of left menu and main page side by side, base layer of main page, name of main page.png>).
It demonstrates page construction rather than dashboard content.

With the sidebar fixed open at the reference width:

- the sidebar occupies `250px` and the main page begins immediately after its
  right border;
- the header spans the remaining `1670px` and is exactly `123px` high in the
  source coordinate model;
- the page title begins at `left: 280px; top: 15px`, occupies a measured
  `783x76px` reference box, uses `80px` Space Grotesk Bold and the accent, and
  is vertically centered without touching the divider;
- a level-one white horizontal divider terminates the header;
- the reference content-zone frame begins at `left: 250px; top: 123px`, has
  design dimensions `1670x978px` and is viewport-clipped when its measured
  height extends below the export; page content itself begins at `left: 280px`
  and normally `28-30px` below the divider;
- empty working space remains true black and is not filled with decorative
  containers.

A detail view uses one fullscreen work surface with its page title at the upper
left, an optional close control at the upper right, description and structured
fields first, and related collections below when required. Close returns
exactly one navigation level. Shared field definitions are references: editing
one updates every placement, while placement order can remain local to each
collection.

Graph workspaces use all available space; presentation controls start
collapsed. Domain entities and field metadata need visibly distinct styling
without adding arbitrary theme colors.

### 5.2 Universal Cards

The universal-card references are:

- [universal card - 1x](<./src/universal card - 1x.png>);
- [universal card - 1x - title](<./src/universal card - 1x - title.png>);
- [Universal card - 2x](<./src/Universal card - 2x.png>);
- [Universal card - 2x - title](<./src/Universal card - 2x - title.png>);
- [universal card - 4x](<./src/universal card - 4x.png>);
- [universal card - 4x - title](<./src/universal card - 4x - title.png>).

A universal card is a rectangular, reusable content region with black fill and
a `1px` outline. It has these invariant parts:

1. An adaptive two-digit ordinal at the upper left, inset exactly `10px`
   horizontally and `10px` vertically in the untitled metric reference.
2. A four-dot drag handle at the upper right. Each visible dot is a `4x4px`
   circle (`r=2px`) using `--decorative-dot` at rest. Dot centers form an `8px`
   by `8px` grid. As a deliberate midpoint between the source-layer offsets and
   raster bounds, position the right-column dot boxes at `right: 8px` and the
   left-column boxes at `right: 16px`; the upper row uses `top: 6px` and the
   lower row `top: 14px`. The four marks share a larger accessible hit area.
3. An optional title on the same header line, placed after the ordinal, using
   accent-colored Consolas Bold at approximately `20-24px`.
4. When a title exists, a horizontal 80%-white divider below a header about
   `54px` high. Untitled cards do not reserve an empty title header.
5. A content body that uses approximately `30-40px` horizontal padding when it
   contains normal settings or metrics. Deliberately edge-aligned graphs may
   use a narrower documented inset.

At the reference content width, `1x`, `2x` and `4x` cards are approximately
`375px`, `790px` and `1610px` wide and `166px` high for the base single-row
variant. Height is a content-driven minimum, not a maximum. A card MUST grow or
scroll internally according to its content contract; it must not clip controls
to preserve the reference height.

For the `790x166px` untitled metric-card reference, the exact component-local
ledger is:

| Element | Reference measurement |
| --- | --- |
| Card | `width: 790px; height: 166px; background: #000000; border: 1px solid #FFFFFF` |
| Ordinal | `left: 10px; top: 10px; 14px Consolas Bold; rgba(255,255,255,.80)` |
| Metric title | `left: 37px; top: 36px; 24px Consolas Bold; color: --accent` |
| Metric value | same `left: 37px`; `top: 89px`; `24px Consolas Bold; color: #FFFFFF` |
| Progress track | full card width; border-box `height: 9px`; attached to `bottom: 0`; `1px #FFFFFF` outline |
| Progress fill | `height: 9px`; accent width proportional to the clamped percentage |

At `50%`, the reference fill is approximately `392px` inside the `790px`
bordered track. The `37px` text inset, `10px` ordinal inset, dot grid and `9px`
progress height remain component-local when a card moves or the main layout
reflows.

Cards placed directly on the page use a 100%-white outline. Cards placed inside
another bordered section use an 80%-white outline, and all further nested card
outlines remain at 80%. A title divider is always inside the card and therefore
uses `--line-inner` at 80%-white. A top-level titled card consequently has a
100%-white outer border and an 80%-white divider; when the card itself is
nested, both its outer border and its divider remain at 80%.

The simple drag-mark variant uses four filled `#D9D9D9` circles. The outlined
variant used by nested Settings cards preserves the same `4px` mark footprint
but renders the source's inner circle at `r=1.5px`, `fill: #D9D9D9`, with an
80%-white stroke. Hover changes either variant's visible dots to `#FFFFFF`.

The drag handle means the card is reorderable. During dragging, a placeholder
with the same `1x`, `2x` or `4x` span shows the exact future geometry and the
rest of the grid reflows live. Drop persists order, recomputes ordinals and
preserves the result across reload and login. If a card is not reorderable, the
four-dot handle MUST be omitted rather than shown disabled without explanation.

### 5.3 Dashboard

The visual reference is [example dashboard](<./src/example dashboard.png>).
Every service dashboard MUST begin with these four operator-health cards:

| Card | Required information | Preferred visualization |
| --- | --- | --- |
| CPU Usage | Current percentage and logical core count | Accent progress line when percentage is known |
| RAM Usage | Current percentage and used/total capacity with unit | Accent progress line |
| Disk Usage | Current percentage and service-usable occupied/total capacity for the relevant service volume, calculated from `bavail` | Accent progress line |
| Uptime | Explicit active duration of the current service instance, never host uptime | Text; no meaningless progress line |

Disk telemetry MUST query the filesystem that contains the service's
authoritative persistent data, not an unrelated container overlay or host root
filesystem. For a POSIX `statvfs` result, calculate the displayed values from
blocks available to the unprivileged service identity:

```text
total_bytes = f_blocks * f_frsize
available_bytes = f_bavail * f_frsize
used_bytes = total_bytes - available_bytes
usage_percent = used_bytes / total_bytes * 100
```

`f_bfree` MUST NOT replace `f_bavail`: blocks reserved for a privileged user are
not writable by the service and therefore count as unavailable in its
Dashboard. Guard a zero or invalid `f_blocks`, clamp only the rendered
percentage to `0-100%`, preserve the raw diagnostic internally and render an
explicit unavailable/stale state instead of a fabricated value.

Uptime is measured with a monotonic clock from the start of the currently
running application/service process. It resets when that service process,
container or deployed instance restarts, even if the host did not reboot. Host
boot age, `/proc/uptime`, reverse-proxy uptime, database uptime and Updater
uptime MUST NOT be substituted. In a multi-process service, the Dashboard uses
the uptime reported by the active operator-facing service/API instance and
labels any separately shown worker uptime explicitly.

At the reference desktop width, CPU and RAM form the first two `2x` cards; Disk
and Uptime form the next two `2x` cards. Additional service-specific cards may
use `4x`, `2x` or `1x` spans below them. This row arrangement may collapse on a
narrow container but the logical order remains CPU, RAM, Disk, Uptime, then
service-specific information.

With the sidebar fixed open on the `1919x1034px` export, exact global card
coordinates are:

| Reference item | Left | Top | Width | Height |
| --- | ---: | ---: | ---: | ---: |
| CPU Usage (`01`) | `280px` | `151px` | `790px` | `166px` |
| RAM Usage (`02`) | `1100px` | `151px` | `790px` | `166px` |
| Disk Usage (`03`) | `280px` | `347px` | `790px` | `166px` |
| Uptime (`04`) | `1100px` | `347px` | `790px` | `166px` |
| Optional full-width card (`05`) | `280px` | `543px` | `1610px` | `166px` |
| Optional `1x` card (`06`) | `280px` | `739px` | `375px` | `166px` |
| Optional `1x` card (`07`) | `695px` | `739px` | `375px` | `166px` |

The `2x` column origins differ by `820px`: `790px` width plus a `30px` gap.
Successive dashboard row origins differ by `196px`: `166px` height plus a
`30px` gap. The two shown `1x` origins differ by `415px`: `375px` width plus a
`40px` nested gap. CPU/RAM/Disk/Uptime are semantic examples attached to the
required operator-health cards; the coordinate system is not a route-specific
absolute-position implementation.

A dashboard contains information that is important immediately on entry,
requires continuous observation or supports a frequent operator decision. It
MUST NOT become a catalogue of values available elsewhere. Titles use accent,
metric values use Consolas Bold and units remain visible. Unknown, stale and
unavailable data use explicit text and MUST NOT be rendered as `0`.

All dashboard cards are reorderable unless a documented safety reason fixes a
card. Order persists across reload and login, and ordinals always reflect the
current order. The rule in section 6.1 that combines collection-bar metrics
does not apply to dashboard cards.

### 5.4 Confirmation And Notices

Deletion, revocation, deny-listing and restore operations require a custom
confirmation that states:

- which resource is affected;
- whether the effect is local or global;
- what remains installed or stored elsewhere;
- whether identity data is revoked or denied;
- whether and how the operation can be reversed.

Native browser `confirm()` and `alert()` are not acceptable finished UI.

The notice stack is fixed `18px` from the top and right, with width
`min(410px, calc(100vw - 36px))`. Show at most five notices. Success,
information and error use their semantic borders and explicit text. Success and
information may dismiss after `4.5s`; errors remain about `8s`. Every accepted
mutation shows pending feedback and a final outcome.

### 5.5 Settings Information Architecture

The references are [example settings main](<./src/example settings main.png>),
the [Appearance card crop](<./src/example - settings - appearance/example - settings - appearance - 1.png>) and
[Appearance on the source canvas](<./src/example - settings - appearance/example - settings - appearance.png>),
the [basic Security card](<./src/example - settings - securite/example - settings - securite - basic.png>),
the [advanced Security card](<./src/example - settings - securite/example - settings - securite - advanced.png>),
[Backup](<./src/example - settings - backups/example - settings - backups.png>), [Updates](<./src/example - settings - updates/example - settings - updates.png>) and
[Logs](./src/example-logs.png). The connected-service references are
[Gryphon Connection before binding](<./src/example - settings - gryphon/example - settings - gryphon - not connected.png>),
[Gryphon Connection after binding](<./src/example - settings - gryphon/example - settings - gryphon - сonnected.png>),
[Wyverne Connection before binding](<./src/example - settings - wyvern/example - settings - wyvern connection - dont connected.png>),
[Wyverne Connection after binding](<./src/example - settings - wyvern/example - settings - wyvern connection - connected.png>) and
[Wyverne Connection error](<./src/example - settings - wyvern/example - settings - wyvern connection - error.png>).
The Backup, Updates, Logs and connected-service card examples are embedded and
measured in [section 10.5](#105-settings-templates); the Appearance and Security
crops are specified below. Their states, controls and ownership boundaries are
defined in [Service Agents: UI And Operator Workflows](./PART_10_SERVICE_AGENTS_UI_AND_OPERATOR_WORKFLOWS.md).

Settings is a primary destination and every service provides these full-width
`4x` sections:

1. Appearance.
2. Security.
3. Backup.
4. Updates.
5. Logs.

Additional sections follow according to service responsibilities. Sections use
the universal titled-card anatomy, may be reordered by their four-dot handle,
persist order and recompute their two-digit ordinals. Each section contains
small named groups. Security, persistence and external behavior controls
include a concise consequence or recovery hint.

The supplied Settings main template has these exact global measurements at the
reference viewport. Its Security coordinates describe the basic two-group card;
the Volt variant grows to fit its additional groups:

| Element | Reference geometry or text origin |
| --- | --- |
| Page title | `left: 280px; top: 15px; font-size: 80px` |
| Appearance section | `left: 280px; top: 153px; width: 1610px; height: 401px` |
| Appearance header divider | horizontal `1px` 80%-white line at `top: 208px` |
| Appearance ordinal `01` | `left: 294px; top: 175px; font-size: 14px` |
| Appearance title | `left: 319px; top: 168px; font-size: 24px` |
| Color correction heading | `left: 319px; top: 236px; font-size: 20px` |
| Color correction description | `left: 319px; top: 269px; font-size: 14px` |
| Security section | `left: 280px; top: 581px; width: 1610px; height: 418px` |
| Security header divider | horizontal `1px` 80%-white line at `top: 636px` |
| Security ordinal `02` | `left: 294px; top: 603px; font-size: 14px` |
| Security title | `left: 319px; top: 596px; font-size: 24px` |
| Changing Access Key heading | `left: 319px; top: 664px; font-size: 20px` |
| Changing Access Key description | `left: 319px; top: 697px; font-size: 14px` |
| Access Key overlay invoker | `left: 319px; top: 735px; width: 326px; height: 40px` |
| Access Key invoker label | measured at `left: 392px; top: 748px; font-size: 14px` |
| Control-plane connection heading | `left: 319px; top: 823px; font-size: 20px` |
| Control-plane URL control | `left: 317px; top: 858px; width: 326px; height: 40px` |
| Control-plane URL value | `left: 332px; top: 871px; font-size: 14px` |
| Control-plane reachability row | `left: 665px; top: 858px; width: 1185px; height: 39px` |
| Control-plane reachability label | `left: 682px; top: 871px; font-size: 14px` |
| Reachability status text | right-side text origin measured at `left: 1644px; top: 871px` |
| Reachability square | `left: 1812px; top: 868px; width: 18px; height: 18px` |
| Control-plane-token rotation invoker | `left: 317px; top: 915px; width: 1532px; height: 40px` |
| Control-plane-token action label | measured at `left: 903px; top: 927px; font-size: 14px` |

The Access Key and control-plane-token rectangles are command/invoker controls in the
current security contract, even if an early source layer named them inputs.
They open the empty, focus-trapped overlays defined below and MUST NOT expose a
persisted secret inline. Positions are derived from section-local offsets in
production so reordered Settings sections retain the same internal geometry.

Ordinary settings apply immediately after the operator commits a control: a
toggle's change, a select's change or a validated text field's blur/Enter. This
does not mean sending every incomplete keystroke. There is no page-level Save
button. A pending state appears without moving the control; success becomes the
new confirmed value; failure restores the prior confirmed value and exposes a
recovery action.

Accent color is the sole exception. It previews immediately but persists only
after `Apply color`, as defined in section 2.1.

#### Appearance

The two Appearance images show the same card: one tight crop and one on a
magenta source canvas. The magenta area is outside the card and is not a Shell
background or theme token. With the fixed `250px` sidebar at the reference
viewport, the black, square-cornered card is `1610x401px`, with a `55px`
header, white outer border and `#CCCCCC` header divider. Its body has two
visible groups in this order:

1. **Color correction** — the description reads “Changes preview immediately
   and apply to both authenticated views and sign-in.” A `40x40px` swatch frame
   contains a `24x24px` color square. A `326x40px` hex field, `Reset color` and
   `Apply color` follow on the same row with `20px` gaps at desktop width.
2. **Left menu position** — the description reads “Reveal the Sidebar from the
   edge or keep it fixed on wide screens.” The labeled checkbox selects
   “Auto open and hide sidebar on mouse hover”; checked means auto-hide and
   unchecked means fixed-open. The change persists when the toggle succeeds;
   failure restores the previous value.

The second heading starts about `64px` below the color row. The checkbox frame
is `20x20px` with a `10x10px` white selected mark and at least a `40px` labeled
target (`44px` for coarse pointers). On narrower screens, the four color
controls wrap in their original order and the card grows to fit. Error text
also grows the card; `401px` is the baseline reference height, not a clipping
limit. Service-specific preferences, such as Mastermind's Activity timezone,
belong in separate Settings cards so they do not extend Appearance.

In the reference Appearance section, the color row uses:

| Element | Exact global geometry |
| --- | --- |
| Swatch frame | `left: 322px; top: 307px; width: 40px; height: 40px` |
| Color swatch | `left: 330px; top: 315px; width: 24px; height: 24px` |
| Hex field | `left: 382px; top: 307px; width: 326px; height: 40px` |
| Hex text | `left: 401px; top: 320px; font-size: 14px` |
| Reset color | `left: 728px; top: 307px; width: 123px; height: 40px` |
| Reset label | `left: 747px; top: 320px; font-size: 14px` |
| Apply color | `left: 871px; top: 307px; width: 123px; height: 40px` |
| Apply label | `left: 890px; top: 320px; font-size: 14px` |
| Sidebar-mode heading | `left: 319px; top: 411px; font-size: 20px` |
| Sidebar-mode description | `left: 319px; top: 444px; font-size: 14px` |
| Checkbox frame | `left: 322px; top: 482px; width: 20px; height: 20px` |
| Checkbox selected mark | `left: 327px; top: 487px; width: 10px; height: 10px` |
| Checkbox label | `left: 354px; top: 486px; font-size: 14px` |

The color field accepts exactly `#RRGGBB`, normalizes case for display, rejects
invalid or incomplete input without changing the persisted token and previews
only a valid value. `Reset color` previews `#00A8FF`; only `Apply color` commits
the preview. Black, white, hover, success and danger are not editable.

#### Security And Control-Plane Connection

The [basic Security card](<./src/example - settings - securite/example - settings - securite - basic.png>)
contains two groups: Access Key rotation and the service's actual external
connection. The first group has a `326x40px` overlay action. The connection
group has a `326x40px` URL control beside a full-width, `40px` public status
row, then one full-width, `40px` token action. At the reference width the
basic card is `1610x418px`; the groups are separated by about `46px` after
the first action. The
[Access Key overlay](<./src/example - settings - securite/example - settings - securite - change overlay window.png>)
has a `620px` maximum width, `55px` title row, `24px` body inset, three
empty masked fields and a right-aligned submit action. Its title is `Security`.

Chronos and Mastermind use the basic variant with `Connection with Kernel`.
Kernel also uses the basic layout, but its second group is `Connection with
Volt`: it edits only the Volt URL and the write-only `VOLT_KERNEL_TOKEN` used
by Kernel to resolve `volt://` values. Kernel does not display a connection to
itself. The [advanced Security reference](<./src/example - settings - securite/example - settings - securite - advanced.png>)
shows Volt's two separate connection groups beneath Access Key. The implemented
Volt card adds `Trash retention` immediately after Access Key, making four
groups in order: Access Key, `Trash retention`, `Connection with Kernel` for
the outbound `KERNEL_SERVICE_TOKEN` used to query Register, and `Volt - Kernel
secure channel` for the inbound `VOLT_KERNEL_TOKEN` accepted by Volt's resolver.
These are independent credentials. The inbound channel shows `Volt internal
resolver` and its token configuration state; it has no second editable Kernel
URL, even though the reference uses a URL-shaped field for this row.

The Volt retention group states that its period applies to entities already in
trash and that shortening it may permanently delete older entities immediately.
It has one `Retention, days` numeric field beside `Save`. Only whole numbers
from 1 to 365 are accepted. `Save` is unavailable while the value is unchanged
or a save is pending. A shorter period requires confirmation before applying
it to existing trash; the result reports any entries permanently deleted.

The Access Key is changed only in a custom overlay containing the current key,
the new key and confirmation of the new key. All fields begin empty. The action
checks the current key, requires two exactly matching explicitly supplied new
entries, rotates the server-side verifier atomically and revokes every other
active browser session. It performs no length, composition, character-set,
strength, entropy, breached-password, example-value or placeholder-value check
and does not trim or normalize either entry.
The current field uses `autocomplete="current-password"`; both new-key fields
use `autocomplete="new-password"`. The UI never reveals either stored verifier
or current key.

Each outbound control-plane connection group contains:

- an editable control-plane base URL or authority URL;
- the resolved public control-plane identity or role when available;
- explicit reachability using the shared semantic status pattern;
- a full-width action to rotate the secure control-plane access token.

The control-plane URL is non-secret. The `.env` value is an initial first-start seed;
after initialization, the authenticated server-side setting is authoritative.
A committed URL is normalized and validated before atomic activation. If the
new control plane cannot be validated, the previous confirmed endpoint remains active
and the failure is shown.

The control-plane token is a write-only secret. Its overlay accepts a replacement but
never preloads, echoes or returns the current token. The server stores it in the
approved secret boundary. An outbound replacement is validated against its selected
control plane and activated atomically only after success; failed validation keeps
the previous credential. Rotation is audited without the secret value.
Volt validates a replacement outbound `KERNEL_SERVICE_TOKEN` against Kernel
Register at the displayed URL before activating either a new URL or token;
the stored value is encrypted, omitted from
logical backups, and never returned to the browser. Rotation of Volt's inbound
`VOLT_KERNEL_TOKEN` changes only the credential checked by its resolver.

#### Backup

`Create and download snapshot` starts one pending-safe operation that creates a
fresh logical ZIP archive and begins its same-origin download as soon as the
archive is ready. It does not create an invisible server backup and require a
second unrelated download action. The final notice reports filename, creation
time and failure recovery without exposing archive contents.

`Restore snapshot` opens the custom restore overlay. A button inside invokes
the native local file picker. After selection, the overlay shows sanitized
filename, declared format/version and bounded size, then requires the restore
confirmation defined in section 5.4. Validation, progress, success and rollback
failure stay in that overlay. Detailed archive and transaction requirements are
defined in [Part 03](./PART_03_BACKUP_AND_RECOVERY.md).

Backup-agent-aware services append the local agent status and contextual
initialization/repair action defined by the service-agent UI guide. The owning
service's Backup card is the sole operator editor for its automatic backup
schedule. The central
storage/fleet panel may observe those values but MUST NOT offer another
schedule editor or competing run button. Archive and dedicated-mirror
policies remain separate, scoped to the owning service and persisted in its
logical backup. Applied agent state is shown independently from saved intent.
Initialize uses the common [section 10.9 overlay](#109-service-initialization-overlays).

#### Service Connection Cards

Every application consuming the messaging gateway uses the exact card title
`Gryphon Connection`; `Bot connection` is a retired title, including in
navigation labels, accessible names and embedded operator documentation.
Every application consuming the LLM gateway uses the requested display title
`Wyverne Connection`. These display labels do not rename executable, API,
repository or configuration identifiers.

The Gryphon card has one `Gryphon adapter binding` group. It shows local agent and
applied-connection reachability, the applied adapter alias or `none`, and one
`Link Gryphon function` / `Change Gryphon function` action. That action opens
the adapter-selection overlay; choosing a ready, paired adapter applies its verified
Telegram account to this service immediately. Each service has one selected adapter,
and the same adapter can be selected again to restore a revoked service binding.
Adapter registration, the one-time Telegram `/link CODE` pairing, and shared
Gryphon version checks/updates use `sudo updater tui`; these controls are
absent from service Settings. The service card never issues another `/link`.
Neptune retains its scoped Initialize workflow. The `Wyverne Connection` card
in Laboratory and Mastermind now shows one Adapter-binding group with local
gateway and active-Adapter status, a safe active name and one link/change action.
The action opens this service's Adapter-choice overlay. Wyvern installation,
client enrollment, shared release checks/updates and Adapter administration
run through `sudo updater tui`; they have no competing controls in these cards.
Laboratory keeps its original visual language for the card and overlay.
Function linking and revocation follow the [Part 10 state matrix](./PART_10_SERVICE_AGENTS_UI_AND_OPERATOR_WORKFLOWS.md).

#### Updates

The Updates section shows the installed version plus reachability of the local
updater and approved release registry. `Check for updates` opens a custom
overlay and starts verified discovery. The overlay distinguishes checking,
up-to-date, confirmed update available, offline/last-known-good and verification
failure.

If a platform is updated only by an external package manager or administrator,
the Updates section still exists and names that authoritative mechanism,
installed version and last verification time. It omits or disables local Apply
with an explicit explanation; it MUST NOT simulate a local updater.

When a newer confirmed version exists, the same overlay shows its version,
publication information, release notes, compatibility and backup readiness,
then exposes the explicit update-initiation button. Merely discovering a
release never starts installation. Detailed trust, rollback and machine-state
requirements are defined in [Part 05](./PART_05_CI_RELEASES_AND_LOCAL_UPDATES.md).
The application update path uses the browser overlay. Updater, Neptune,
Gryphon and Wyvern release checks and installs run only in `sudo updater tui`
on the host; service Settings provide no update action for these shared
components.

The complete universal update component, its measured geometry and all six
embedded reference images are defined in
[section 10.8](#108-update-dialog-templates). This browser-dialog contract
applies to each application's own release flow.
The backup gate, live job lifecycle and first-transition exception are defined
in [Part 05 sections 34–35](./PART_05_CI_RELEASES_AND_LOCAL_UPDATES.md#34-operator-update-ui).

#### Logs

The Logs section is a bounded real-time stream with columns for type, body and
local time. Information/success labels use `#62FF8C`; error/denied labels use
`#F83D3D`; every outcome is also written as text. New rows merge without
changing column geometry, unbounded client history is never accumulated and
the view pauses or resynchronizes safely when hidden or disconnected.

`Download archived logs` creates and downloads a timestamped ZIP while keeping
Settings open. Detailed retention, redaction, pagination and archive rules are
defined in [Part 02](./PART_02_OBSERVABILITY_AUDIT_AND_LOG_EXPORT.md).

Use the [section 10.5.2 Logs ledger](#1052-logs-card). The recorder preference,
cursor semantics and archive delivery are defined in Part 02. The optional
service-revision logging checkbox changes future diagnostic recording, not
mandatory security auditing, and is not merely a filter on this table.

### 5.6 Search

Search is a rectangular toolbar unit, not a floating rounded box. The component
uses the canonical structure `search icon / input / clear action`; products MUST
NOT replace it with a browser-native field whose geometry, cancel control or
rounded corners vary by platform.

#### 5.6.1 Query And Result Behavior

For a complete bounded collection, filtering is client-side and updates after
every input change without an Apply action. The searchable copy of the query is
trimmed at both ends and compared case-insensitively using a stable locale; the
text displayed in the input is not trimmed, rewritten or case-folded. Matching
uses substring containment, not prefix-only or fuzzy matching.

For record collections, the search index contains the primary title, every
grouping/project label, every field key and values explicitly classified as
non-secret. Secret values MUST NOT enter the search index, browser search
history, telemetry or diagnostic output. An active collection scope and the
query compose with logical AND: search narrows the current scope and never
silently broadens it.

An empty query restores the current scope and its canonical order. A no-match
state remains below the command bar, reports zero results in the collection
information unit and does not hide page-level actions. Search and clear actions
do not create audit events or success notices.

#### 5.6.2 Exact Geometry And Typography

The canonical search unit has the following geometry:

```css
.collection-search {
  min-width: 0;
  min-height: 40px;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) 32px;
  align-items: center;
  gap: 12px;
  padding: 0 12px;
  border: 1px solid var(--line-inner);
  border-radius: 0;
  background: var(--black);
  color: var(--white-80);
}

.collection-search input {
  width: 100%;
  min-width: 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: var(--white);
}
```

The leading search icon is `18x18px`, uses no fill and uses the current
secondary-text color with a `1.8px` round-capped, round-joined stroke. The
input inherits the canonical `14px` Consolas stack and `400` weight. Placeholder
text uses `--white-80`; implementations MUST set it explicitly rather than
accept a user-agent placeholder color.

Measured from the inner edge of the border, the inline sequence is exactly:
`12px` inset, `18px` icon, `12px` gap, flexible input, `12px` gap, `32px`
clear-action box, `12px` inset. The clear track is permanently reserved, so
showing or hiding the action never changes input width, moves text or reflows
the command bar. The desktop command-bar track containing the search unit is
`minmax(240px, 1fr)`; the search unit itself remains shrink-safe through
`min-width: 0`.

#### 5.6.3 Color And Interaction States

| State or element | Exact treatment |
| --- | --- |
| Resting surface | `#000000` background; `1px` `--line-inner` border (`rgb(255 255 255 / 80%)`, rendered `#CCCCCC` on black) |
| Query text | `#FFFFFF` |
| Search icon and placeholder | `--white-80` |
| Field hover | Retain resting colors; use the proportional non-layout hover growth from section 3.1 with a centered origin and `160ms ease` transition |
| Field focus-within | Border becomes `--accent`; the same non-layout growth applies; the inner input does not draw a second outline |
| Clear action at rest | Transparent `32x32px` box; cross uses `--white-80` |
| Clear action hover/focus | Cross and `1px` inset outline use `--accent`; background becomes `#111111`; geometry is unchanged |

`prefers-reduced-motion: reduce` removes the growth transition while retaining
the border, color and focus distinctions. The field's focus treatment MUST be
visible even though the inner input has no independent outline.

#### 5.6.4 Clear Action And Keyboard Contract

Every editable search field contains a dedicated clear action in the reserved
`32x32px` inline-end track, inside the field border. It uses the shared
close/cross SVG rather than a text letter. While the query is empty, the action
uses `visibility: hidden` and `opacity: 0`, is disabled, has no pointer events,
is absent from the tab order and is hidden from accessibility APIs; its grid
track remains present. While the query is non-empty, it becomes visible,
enabled and keyboard reachable.

Pointer or keyboard activation clears the complete query, emits the same
filter update as ordinary input, restores the unfiltered current scope and
returns focus to the input on the next animation frame. Pressing `Escape` while
the query is non-empty performs the same action and prevents the browser's
competing default. The clear action has a localized accessible name such as
`Clear search`. The input is `type="search"`, has a view-specific accessible
name and hides the browser's native search-cancel decoration so only one clear
action is exposed.

The search field belongs to the collection command bar defined in section 6.
It MUST NOT scroll away while the collection below it continues scrolling.

### 5.7 Documentation View

Documentation is a normal application view, not a modal. It is a bounded
workspace below the shared page header, not an unbounded document that delegates
scrolling to `body`, the shell or the browser viewport. On desktop it uses a
`220px` documentation-navigation column, a `30px` inter-column gap and a
flexible article column capped at `1120px`.

The canonical desktop composition is shown in
[documentation](./src/documentation.png) and specified in
section 10.7. Product identity, article copy and the raster's missing accent
states are placeholders; the shared shell, palette and interaction rules in
this document still apply.

#### 5.7.1 Viewport Ownership And Workspace Height

The Documentation workspace owns all scrolling inside the view. While this
view is active, the page-level surface MUST fit the available block size and
MUST NOT grow the browser document merely because the operator guide is long.
Use the actual shell dimensions rather than a hard-coded screen height:

```css
.documentation-page {
  height: calc(
    100dvh
    - var(--page-header-height)
    - var(--page-content-padding-block-start)
    - var(--page-content-padding-block-end)
  );
  min-height: 0;
  overflow: hidden;
}
```

Declare a `100vh` fallback immediately before the `100dvh` value for browsers
without dynamic-viewport-unit support. In the canonical desktop shell,
`--page-header-height` is `123px`, page-content top padding is `28px` and bottom
padding is `40px`, producing `calc(100dvh - 191px)`. At the canonical narrow
shell, the header is `96px` and page-content padding is `20px` on both block
edges, producing `calc(100dvh - 136px)`. If a product legitimately changes a
shell token, it MUST derive the Documentation height from that token; it MUST
NOT preserve `191px` or `136px` as unrelated magic numbers.

Every grid/flex ancestor between the sized workspace and its scroll regions
uses `min-height: 0`; inline tracks use `min-width: 0`. Missing either rule may
make an overflow child enlarge the grid instead of scrolling. The outer
Documentation grid uses `overflow: hidden` and never becomes a third scroll
owner.

#### 5.7.2 Exactly Two Independent Scroll Regions

The workspace contains exactly two vertical scroll regions:

1. **Documentation navigation region.** It contains the search field, group
   headings and section destinations.
2. **Documentation article region.** It contains the guide header, all visible
   sections, notes, lists, code blocks and tables.

Both regions use `overflow-y: auto`, `min-height: 0`,
`overscroll-behavior: contain` and hidden visual scrollbars. They scroll
independently:

- wheel, trackpad, touch or keyboard input over/focused in the navigation moves
  only the navigation region;
- the same input over/focused in the article moves only the article region;
- scrolling the article never moves the search field, group headings or
  section destinations;
- reaching the beginning or end of either region does not chain the gesture to
  `body`, the page surface or the other region;
- changing primary application destinations still uses normal shell
  navigation and is not trapped by the Documentation workspace.

The scrollbars are visually suppressed in both engine families without
disabling scrolling:

```css
.documentation-nav,
.documentation-content {
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: none;
}

.documentation-nav::-webkit-scrollbar,
.documentation-content::-webkit-scrollbar {
  display: none;
  width: 0;
  height: 0;
}
```

Do not use `overflow: hidden` on either inner region, cancel wheel/touch events,
remove the content from the accessibility tree or create a transparent overlay
to conceal a native scrollbar. A hidden visual scrollbar is acceptable here
only because wheel, trackpad, touch, Page Up/Down, Home/End and arrow-key
scrolling remain available. Each region has an accessible name; the article
region is programmatically focusable when its contents do not otherwise
provide a reliable keyboard entry point.

#### 5.7.3 Documentation Navigation And Search

The left region is `220px` wide on desktop and has no outer card. Its inner
stack uses `20px` vertical gaps and at least `30px` bottom padding so the final
destination can scroll clear of the region edge. Search is the first item and
uses the canonical `220x40px` control. It filters immediately without submit or
network navigation.

Search normalization trims the query and compares case-insensitively against,
at minimum, each section's visible title, concise summary, indexed keywords and
rendered body text. Search metadata augments real copy; it MUST NOT be the only
place an important operator term exists. The clear behavior follows section
5.6. Empty groups are omitted. A no-result query leaves the search field
available, renders an explicit no-results message in the article region and
does not collapse the workspace.

Group headings use muted/80%-white Consolas Bold. A heading has `8px` block
margin in the reference stack. Section destinations are full-column controls,
approximately `36px` high, with `7px` block padding, left-aligned text and a
`1px` nested separator on the block end. They do not scale, change width or
change height on hover/focus. Hover, keyboard focus and the current-section
state use the configured accent.

The navigation region itself is not `position: sticky`: independence is
created by the two bounded overflow owners. Making the entire column sticky
inside a page-scrolling document is not an equivalent implementation, because
the browser page still moves and scroll ownership becomes viewport-dependent.
The search and groups remain stationary while the operator scrolls the article
because only the right region's `scrollTop` changes.

#### 5.7.4 Article Region And Long-Form Structure

The article region is a black top-level surface with a `1px` white outline,
`1120px` maximum width and `24px 32px 64px` padding. It stretches to the full
workspace height and scrolls internally. The guide content inside it may be any
length; the scroll surface does not grow the outer page.

The guide header uses `30px` bottom padding and a `1px` nested divider. Its
kicker identifies the current product, runtime/document version and operator
guide without exposing filesystem paths, private repository coordinates or
secret-bearing identifiers. The guide title is `36px/44px` Space Grotesk Bold,
with `8px` vertical separation from the kicker in the reference layout. The
introductory paragraph describes the guide scope rather than a marketing claim.

All matching sections are rendered in one continuous semantic document. A
section uses a stable unique fragment identifier, `30px` block padding,
`30px` scroll margin and a `1px` nested divider. The last visible section omits
the trailing divider. Section headings use `22px` accent text in the compact
long-form template; nested headings are `16px` and begin after approximately
`26px`. A concise section summary may precede its body and uses approximately
`22px` bottom separation. Body text remains `14px/22px` or an equivalent
`1.7` line height.

Lists use a `24px` inline-start indentation and `8px` item gap. Inline code has
a `1px` nested outline, `1px 4px` inset and hover-surface fill. Code blocks use
a `1px` nested outline, `14px` padding and their own horizontal overflow only
when the code cannot wrap. Tables collapse borders, use the full available
article width and `8px` cell padding; at narrow widths the table, not the page,
may become horizontally scrollable. Notes use a rectangular hover surface,
`2px` accent left rule and `14px` padding. Semantic warning, success and failure
meaning also uses text/icon treatment and never color alone.

#### 5.7.5 Section Navigation, Filtering And Scroll State

Activating a section destination scrolls the **article region only**. It MUST
NOT call a behavior that also scrolls the browser document or the navigation
region. Calculate the destination relative to the article scroll owner, or use
fragment navigation proven to select the correct overflow ancestor. Preserve a
`30px` top reading offset. Smooth scrolling is allowed only when reduced motion
is not requested; reduced-motion mode jumps immediately.

The destination remains keyboard operable and exposes the target relationship.
After keyboard activation, focus either remains on the destination with the
target announced through the current-section state, or moves to a focusable
target heading without losing reading order. Browser history and fragment URL
updates are optional, but back/forward behavior MUST be coherent if they are
implemented.

Manual and programmatic scrolling of the article region MUST continuously keep
the table-of-contents current-section state synchronized with the section at
the reading position. Exactly one visible section destination is current. The
canonical activation line is `30px` below the article owner's block-start: the
current section is the last visible topic whose block-start has reached or
crossed that line. Before the first topic reaches it, the first visible topic is
current; at the article's maximum scroll offset, the final visible topic is
current. This state updates after wheel, trackpad, touch, keyboard and scripted
scrolling, and after filtering, resize or scroll restoration. Synchronization
changes only the destination's accent/current semantics (for example
`aria-current="location"`); it MUST NOT move the navigation region or page,
steal focus, or initiate another article scroll.

Changing or clearing the search query resets the article region to
`scrollTop = 0` before displaying the new result set. This prevents a retained
deep scroll offset from producing an apparently blank filtered guide. The
navigation region MAY preserve its own scroll position when still valid; it
must clamp that value after groups disappear. Leaving and reopening the view
resets both regions unless the product explicitly documents per-view scroll
restoration.

#### 5.7.6 Responsive Contract

Above approximately `1000px`, the two regions are side by side. The grid is
`width: 100%`, capped at `1610px` and centered in the page-content insets. Extra
width remains after the readable article maximum rather than stretching prose.

At approximately `1000px` and below, navigation stacks above the article, but
the two-scroll-region contract remains. Use one column with a bounded
navigation row and `minmax(0, 1fr)` article row; a canonical split is
`minmax(160px, 34%) minmax(0, 1fr)`. The navigation region scrolls within the
first row and the article region scrolls within the second. Do not revert to a
single page scrollbar merely because the regions are stacked.

At `720px` and below, use the narrow shell height calculation above, reduce
article padding to `20px` horizontally and at least `48px` at the bottom, and
use a navigation row no smaller than `150px` unless the viewport itself cannot
provide that height. The global sidebar follows its standard modal-overlay
contract. Neither Documentation region may introduce horizontal page scrolling.

If the available block size is exceptionally short, preserve the search
control, at least one visible destination row and a usable article viewport;
allow each inner region to scroll rather than imposing a page minimum height.
Viewport resize, zoom, mobile browser chrome and virtual-keyboard changes clamp
both `scrollTop` values to their new valid ranges without leaving a blank zone.

#### 5.7.7 Verification And Content Synchronization

Services may change article content and domain examples, but not the shared
layout, search behavior, typography hierarchy or responsive contract.

The Documentation view is a versioned operator surface, not a manually updated
afterthought. A change to an operator-visible workflow, navigation destination,
setting, action, permission, limit, status, error, backup/restore procedure or
update behavior MUST update the corresponding internal article in the same
outgoing revision. Renamed and removed behavior must update or remove stale
terms, anchors, screenshots and instructions.

Before every push, the Documentation impact check MUST finish as `PASS` or as a
reasoned `N/A` under the central pre-push gate. For an affected change, `PASS`
requires:

- article content that matches the outgoing implementation and names defaults,
  prerequisites, consequences, failure states and recovery where relevant;
- synchronized navigation order, article identifiers, heading/search index and
  cross-links;
- a successful documentation build/render and broken-link check;
- a search check proving that the changed topic is discoverable by its current
  UI label and important operator terminology;
- removal or explicit versioning of instructions that no longer apply.

Internal Documentation content and service technical documentation have
different audiences. Updating one does not satisfy the required review of the
other; [Part 06](./PART_06_UNIFIED_ACCEPTANCE_CHECKLIST.md#411-mandatory-pre-push-integrity-and-documentation-gate)
defines both pre-push checks.

## 6. Sticky Collection Command Bars

Any page or menu that filters, creates, summarizes or changes a collection has
one command bar immediately above that collection. Search MUST NOT be rendered
as a list item, placed below the first records or separated from related
commands by an unrelated panel.

### 6.1 Content And Order

When present, controls appear in this left-to-right order:

1. Search or filter input.
2. Collection information, such as item count, active revision, checksum,
   selection count or synchronization state.
3. Primary collection action, normally create or add.
4. Secondary collection actions, such as history, import, export or bulk edit.

Above the responsive breakpoints in section 6.2, search, information and
actions share one horizontal line and one visual height. Do not put a create
button at the bottom of a long list when it is a page-level action. Row-specific
actions remain inside their own rows.

If several metrics are required, combine them inside one information unit
rather than turning each number into a separate card. The most important
primary action stays visible without opening an overflow menu. This rule is
limited to a collection command bar; it does not combine the mandatory CPU,
RAM, Disk and Uptime dashboard cards defined in section 5.3.

### 6.2 Reference Geometry

The proven desktop geometry is:

```css
.collection-command-bar {
  position: sticky;
  top: 0;
  z-index: 20;
  min-height: 60px;
  margin: -30px -30px 14px;
  padding: 10px 30px;
  border-bottom: 1px solid var(--line-outer);
  background: var(--black);
  display: grid;
  grid-template-columns:
    minmax(240px, 1fr)
    minmax(250px, auto)
    auto
    auto;
  align-items: stretch;
  gap: 12px;
}

.collection-list {
  margin-top: 14px;
}
```

The negative inline and block-start margins cancel the canonical `30px` page
padding, while the command bar's own `30px` inline padding realigns its content
with the page. The search component's complete internal geometry is defined in
section 5.6. Base command-bar controls are at least `40px` high.

If the information unit has a primary value and subordinate digest or count,
use two columns with `4px 14px` gaps and let the subordinate line span both
columns. The primary value uses the accent color; labels and secondary values
are muted.

At viewport widths of `1000px` or less, the canonical four-track bar becomes
two columns: `minmax(240px, 1fr) minmax(250px, auto)`. Auto-placement may form a
second controlled row, but search remains first. At `720px` or less, it becomes
one column, uses `margin: -16px -16px 14px` and `padding: 8px 16px`; the search
unit fills the available track. These responsive changes do not alter the
search unit's `40px` minimum height, `12px` internal insets/gaps, `18px` icon or
`32px` clear-action track.

### 6.3 Sticky Behavior

The command bar is attached to the top of the list's scrolling context:

```css
.collection-command-bar {
  position: sticky;
  top: var(--collection-sticky-offset, 0px);
  z-index: 20;
  background: var(--black);
}
```

- The sticky offset equals the height of any persistent application header
  inside the same scrolling container. Do not guess a viewport offset when an
  ancestor is the actual scroll owner.
- The bar remains visible from the first row to the final row.
- Its opaque background prevents list text from showing through.
- Add bottom padding or the existing `14px` list gap so content never touches
  the bar while scrolling.
- Sticky behavior MUST be tested inside the real overflow ancestor. An
  ancestor with an accidental `overflow: hidden`, transform or insufficient
  height can silently break it.
- Focus, autocomplete and dropdown menus from the bar render above list rows
  but below global dialogs and notices.
- Filtering preserves scroll only when the current position remains valid;
  otherwise return the list to its first result.

Above `1000px` the canonical four units stay on one line. At and below the
breakpoints specified in section 6.2, the complete bar reflows into two and then
one column. A product may hide non-essential secondary metadata or shorten
secondary actions to accessible icon buttons, but the bar remains one sticky
unit, search stays first and the primary action never moves below the
collection.

### 6.4 Behavioral Rules

- Filtering is immediate for a bounded local dataset; remote filtering is
  debounced, cancellable and announces loading and result count.
- The count describes the filtered set and, when useful, also the total, for
  example `18 of 240`.
- Clearing search restores the canonical order.
- Reordering is disabled while a filter changes the visible order unless the
  product defines an unambiguous filtered-reorder contract.
- Search input does not create audit events. Create, import, bulk edit and
  order persistence do.
- Empty and error states render below the command bar, so recovery controls
  remain available.
- The bar receives a semantic search landmark or toolbar label, and every
  control remains keyboard reachable.

## 7. Embedded Node-Canvas Editors

A node canvas is appropriate when spatial relationships, directional links,
ordered processing or containment communicate more than a table can. It is
not a replacement for an ordinary form, list or dependency report.

The reference architecture is a reusable node-editor framework embedded by a
host application in a restricted visual-only profile. The host owns identity,
authorization, persistence, revision history and notifications. The editor
owns world-coordinate interaction, graph editing and serialization.

### 7.1 Layered Architecture

Keep these boundaries separate:

| Layer | Responsibility |
| --- | --- |
| Project model | Versioned schema, stable IDs, geometry, membership, connections and annotations |
| Command/history layer | Atomic mutations, undo/redo, copy/paste, duplicate and delete |
| Type and node registry | Allowed node definitions, parameters, ports and compatibility |
| Canvas UI | Rendering, selection, pan/zoom, drag, resize, library, inspector and overlays |
| Embed adapter | Mount/destroy lifecycle, mode, theme tokens and host callbacks |
| Host application | Authentication, API loading/saving, checksums, revisions, restore and audit |
| Optional runtime | Scheduling, execution, assets, timeline and telemetry only when the product executes graphs |

The saved project remains data, never serialized DOM. At minimum it contains
format and schema versions, metadata, settings, viewport, background, nodes,
containers, groups, connections and annotations. Optional presets and assets
are included only when enabled. Every reference uses a stable ID rather than a
screen label or array index.

### 7.2 What To Keep And What To Remove

For a visual architecture or topology editor, retain:

- world-coordinate pan, cursor-anchored zoom, fit-all, fit-selection and return
  to origin;
- an optional hierarchical grid and snapping for nodes, containers and groups;
- selection, marquee selection, multi-element movement, resize and keyboard
  editing shortcuts;
- a library containing only allowed domain node types, empty containers and
  approved presets;
- typed or decorative connections, explicit routing and arrow direction when
  relationships need them;
- containers for visible ordered membership and groups for loose spatial
  organization;
- text and geometric annotations;
- inspector, context menu, minimap and visibility toggles when they support the
  actual use case;
- schema validation, unresolved-node handling, canonical serialization and
  viewport culling;
- host callbacks for save, project-change reason and lifecycle cleanup.

Remove or disable in a visual-only embedding:

- run, stop, queue, execution status and backend selection;
- scheduler, worker, GPU and host-execution adapters;
- timeline, frame controls and streaming/backpressure settings;
- resource telemetry and runtime dashboards;
- generic executable node packs that are outside the host domain;
- asset import and media preview when the map does not use media;
- standalone multi-project tabs, filesystem open/save and export UI when the
  host API owns one authoritative project;
- machine-control APIs, plugin installation and any path that executes dynamic
  code.

If the shared schema requires optional execution or timeline fields, keep
inert validated defaults in serialized data while removing their UI and runtime
side effects. Do not create a divergent private schema merely to hide controls.

### 7.3 Embedding Contract

The host initializes the editor only after loading and validating the project.
It supplies:

- `embedded-edit` or `embedded-readonly` mode;
- `visual-only` capability when execution is forbidden;
- an allow-list of domain node definitions;
- whether the framework's generic node library is registered;
- theme tokens compatible with the host shell;
- save and project-change callbacks.

The reference visual profile registers one descriptive text-node family,
disables the generic node pack and enables visual-only mode. A registry may
still require a no-op implementation for structural validation; the editor
MUST make it unreachable because UI hiding alone is not an authorization
boundary.

Mount and destroy are paired. Destroy cancels listeners, observers, telemetry,
animation and pending work. Recreating an editor without cleanup is a memory
and input-handler leak.

### 7.4 Canvas Navigation And Editing

- Wheel zoom is anchored under the pointer and clamped. The demonstrated
  editor uses a broad `0.05` to `8` range.
- Hold Space and drag, or use the middle button, to pan.
- Fit commands use all visible graph bounds plus approximately `96px` padding.
- Origin returns the viewport center to world origin without changing domain
  data.
- Double-clicking empty canvas may open the library at the pointer. A keyboard
  shortcut offers the same action.
- Marquee drag selects. Shift adds or removes items. Dragging any selected item
  moves the selection as one transaction.
- Copy, cut, paste, duplicate, delete, bypass and undo/redo operate through the
  command layer, so internal connections and history remain consistent.
- Interactive fields stop pointer propagation; editing text must not begin a
  node drag.
- Right-click opens an element or connection menu at the pointer. Menus are
  clamped to the viewport and close after a command.
- Off-screen top-level elements are culled with a roughly `300px` screen-space
  safety margin. Selected and actively dragged elements are never culled.

Viewport movement is presentation state but may still be persisted so the map
reopens where the operator left it. It should use a slower save debounce than
structural edits.

### 7.5 Nodes, Containers, Groups And Connections

A node contains stable type ID and version, position, size, label, parameters,
ports, visual state and optional parent IDs. Rendering resolves its definition
from the registry. Unknown definitions remain visible as unresolved nodes with
their raw state preserved; never discard data merely because a plugin is
temporarily absent.

A container owns an ordered list of node IDs and aggregate input/output ports.
An embedded Open Node host MUST make every supported node definition that it
exposes in its library movable into a Container and back to the top level.
Containment changes layout, ordering and boundary routing; it MUST NOT reduce
the node's represented information or functional capability. The contained
renderer MUST preserve:

- a recognizable version of the node's visual identity, hierarchy, color and
  state;
- the primary content, values, validation state and meaningful port context;
- every operator action and editable control available on the full node,
  including file Open, Download and Upload/Replace actions where applicable;
- attached assets and all serialized node state without conversion or loss.

A compact layout MAY reflow controls or expose them through an explicit
contained-node expansion affordance, but it MUST keep them reachable without
temporarily removing the node from the Container. Replacing the real contained
view with a generic parameter summary is not conformant when that hides visual
or functional behavior. Moving a node into a Container, saving, reloading and
moving it back out MUST be a lossless round trip. An unresolved third-party
definition may remain visibly unresolved and non-insertable, but it is not a
supported library node for purposes of this requirement.

Dropping a compatible top-level node into it:

1. verifies the node definition declares container compatibility;
2. calculates insertion position from the pointer and visible slot midpoint;
3. removes the node from a spatial group;
4. sets the parent-container reference and inserts the ID once;
5. removes computational connections that cannot remain valid through the
   container boundary while preserving decorative relationships;
6. records the operation as one undoable transaction.

Because removing connections can lose semantic information, a general-purpose
editor SHOULD preview or confirm that effect when more than trivial visual
links are attached.

Contained nodes are displayed in a fixed-height compact card and can be
reordered with a live insertion line. The container's port positions track the
first and last visible slots. Collapsing a container hides its list but retains
membership and order.

A group is spatial rather than sequential. Membership is recalculated from
complete containment; when groups overlap, the smallest containing group wins.
Contained nodes are excluded because their container is the top-level spatial
member. Moving a group moves its current members together.

Connections store endpoints by element and port ID. Decorative connections use
normalized anchors so resizing preserves attachment. Computational connections
validate direction, kind, multiplicity and type compatibility before commit.

### 7.6 Proportional Compact-Node Geometry

Changing a node from top-level rendering to a contained preview MUST preserve
the proportion devoted to its primary content. Do not blindly apply the normal
three-column `inputs / parameters / outputs` layout to a text-dominant node.

The demonstrated geometry is:

- top-level text node: `360px` outer width and `30px` horizontal body inset,
  leaving about 83% for text;
- default container: `280px` outer width with `9px` list padding;
- contained card: approximately `262px` outer width;
- compact text body: one flexible column with `22px` horizontal inset, again
  leaving about 83% for text.

The portable rule is:

```text
content_ratio = editable_content_width / node_card_width
abs(compact_ratio - full_ratio) <= allowed_tolerance
```

Use a tolerance no larger than `0.12` in a geometry test. The field must then
scale continuously when the container is resized.

```css
.compact-node.is-text .compact-node-body {
  grid-template-columns: minmax(0, 1fr);
  padding-inline: 22px;
}

.compact-node.is-text .port-summary {
  display: none;
}

.compact-node.is-text .primary-parameter {
  width: 100%;
}
```

Hiding repeated per-node port labels is appropriate when the container already
represents sequential input/output and the text field is the dominant content.
For a node whose ports carry essential meaning, place compact port indicators
as non-sizing overlays or reserve a proportional, bounded inset; never let two
fixed side columns consume most of a narrowing card.

### 7.7 Persistence, Revisions And Concurrency

The host loads one canonical project, displays revision and checksum metadata,
and listens for change reasons. Structural changes may save after roughly one
second of inactivity; viewport-only changes use a longer debounce.

Only one save runs at a time. If another change occurs during the request, set
a queued flag and serialize the newest complete project after the active save
finishes. This prevents an older response from overwriting a newer edit.

Each accepted save creates an immutable revision with actor, reason, timestamp
and content checksum. Restore creates a new revision from a selected source; it
does not move the active pointer backward or erase later history. The UI shows
`Modified`, `Saving`, `Saved` and `Save failed` explicitly.

For multiple simultaneous editors, add optimistic concurrency through a base
revision or ETag. A debounce queue alone prevents local overlap but not
last-writer-wins loss between browsers.

### 7.8 Canvas Verification

- [ ] Visual-only mode has no reachable execution path.
- [ ] Only allow-listed node definitions appear in the library.
- [ ] Invalid schema, duplicate IDs and dangling references are rejected.
- [ ] Cursor-anchored zoom preserves the world point under the pointer.
- [ ] Selection, copy/paste and undo preserve internal connections.
- [ ] Container insertion and reorder preserve unique membership.
- [ ] Every supported library node can move into and out of a Container, and a
      save/reload round trip preserves its visual identity, complete state,
      controls, actions and attached assets.
- [ ] A contained text field keeps the full-node width ratio within `0.12` and
      follows container resizing.
- [ ] Text editing never starts drag or canvas pan.
- [ ] Autosave serializes overlapping changes and reports failure.
- [ ] Revision restore produces a new checksummed revision.
- [ ] Off-screen culling does not remove selected or dragged items.
- [ ] Destroying and remounting does not duplicate listeners or observers.

### 7.9 Browser-Backed Document Nodes

A visual canvas may need a second, non-executable node family whose purpose is
to attach source material to the diagram. Keep this node distinct from the
descriptive text node: text parameters belong to the graph model, while a
document node owns an asset reference and explicit file actions.

The reference profile supports four document families:

| Family | Accepted representation | Open behavior |
| --- | --- | --- |
| PDF | A file with a PDF signature and `.pdf` name | Open a short-lived `blob:` URL with the fixed `application/pdf` MIME type |
| Markdown | Valid non-empty UTF-8 text without null bytes and a `.md` name | Open as `text/plain;charset=utf-8`; do not add an application-specific renderer |
| Word document | A valid OOXML ZIP package with `.docx`, `[Content_Types].xml` and `word/document.xml` | Hand the fixed DOCX MIME type to the browser; the browser may open, delegate or download according to installed capabilities |
| Native graph project | A UTF-8 JSON document using the supported graph format and schema version | Parse and validate it, then open it in a separate editor tab without replacing the authoritative host project |

Do not promise that every browser renders every office format inline. The
portable contract is that **Open** delegates to the browser or an existing
editor capability, while **Download** always produces the original bytes with
a safe filename. A separate PDF, Markdown or office reader is unnecessary.

#### Node Definition And Visual Contract

Use a declarative capability tag such as `browser-document` instead of
hard-coding a host-specific node type inside the shared renderer. A recommended
definition has:

- one optional generic input and output when visual relationships are useful;
- one `file` parameter that stores an asset ID, not a platform path;
- an `accept` allow-list for PDF, Markdown, DOCX and the configured native
  graph-project suffixes;
- preview-sized default geometry, because file identity and three actions need
  more vertical room than a scalar parameter;
- no side effects and no reachable execution behavior in a visual-only host;
- container compatibility enabled only when the compact contained-node renderer
  preserves the same attached-file identity, type and size presentation and
  exposes Open, Download and Upload/Replace without clipping or substituting a
  generic parameter summary.

The node body has two states:

```text
EMPTY                           ATTACHED
+--------------------------+    +--------------------------+
| +  Attach a document     |    | FILE  architecture.pdf  |
|    PDF · MD · DOCX · ... |    |       PDF · 820 KB       |
| [ Upload ]               |    | [Open][Download][Replace]|
+--------------------------+    +--------------------------+
```

The filename is the primary label and is ellipsized with its full value in a
tooltip. The second line shows normalized type and size. Actions wrap rather
than overflow at the minimum width. Drag-and-drop and the Upload button invoke
the same import transaction. Read-only mode keeps Open and Download available
but disables Upload and Replace.

#### Import And Persistence Transaction

Treat import as one atomic command:

1. Enforce the byte limit before reading the file.
2. Read the browser `File` once. Copy `name`, `type` and `size` explicitly;
   these properties may live on the prototype and disappear during object
   spread.
3. Detect and validate the real content independently of the browser-supplied
   MIME type.
4. Compute a cryptographic checksum over the original bytes.
5. Create an asset reference with stable ID, safe original name, normalized
   MIME type, byte size, checksum and storage mode.
6. Persist the bytes and reference before assigning the asset ID to the node.
7. Replace the node's previous asset reference in the same graph mutation.
8. Remove the previous asset only when no other node references it.
9. Trigger normal autosave and show a visible success or validation message.

An asset registry that returns bytes from `import()` but retains only the
reference is incomplete: reload will leave a convincing node with a missing
file. Test persistence across a real host save and browser reload.

For small, portable diagrams, bytes may be embedded as canonical base64 inside
the versioned project. The demonstrated bounded profile uses a `4 MiB` per-file
limit and an `8 MiB` serialized-project limit. Base64 adds roughly one third to
the byte count, so the project limit must include that expansion plus graph
metadata. For larger assets, use content-addressed host storage and keep only a
checksummed, authorization-scoped reference in the project. Never silently
fall back from durable storage to an in-memory object URL.

Embedded storage simplifies backup and revision restore but duplicates bytes
across immutable revisions. Content-addressed storage reduces that duplication
but requires reference counting, garbage collection, authorization and backup
coverage. Choose the mode deliberately and document its recovery behavior.

#### Browser Open And Download Lifecycle

For an embedded asset, decode only after the operator presses Open or Download.
Create a `Blob` with a MIME type selected from the validated format enum, never
from mutable project metadata. Opening uses a new browser tab with no opener
relationship. Download uses an anchor with the `download` attribute and a
filename stripped of path separators and control characters.

Object URLs are capabilities and consume browser memory. Do not create them
during node render or retain them in serialized metadata. Revoke a download URL
immediately after dispatch. Keep an Open URL only long enough for the new tab to
load, then revoke it; also revoke all outstanding URLs on editor destruction.

Native graph projects are different from documents: decode JSON, validate the
format and supported schema again, create a new editor tab, and only then load
the project. Never replace the current authoritative graph before validation,
and do not execute imported nodes merely because their definitions exist.

#### Security Validation

The UI `accept` attribute is a convenience, not a security boundary. Repeat
validation at the authoritative save or upload endpoint:

- allow-list storage modes and reject remote HTTP assets unless the product has
  a separately designed fetch policy;
- require canonical base64 when bytes are embedded;
- compare decoded length with declared size and enforce both file and whole-
  project limits;
- require and recompute SHA-256, then reject a missing or mismatched checksum;
- bind each format enum to one fixed MIME type and allowed filename suffix;
- check `%PDF-` for PDF;
- decode Markdown with fatal UTF-8 validation and reject null bytes;
- verify ZIP magic and required OOXML members for DOCX;
- parse graph JSON and require both supported format and schema versions;
- reject HTML, SVG, JavaScript and arbitrary `data:` or remote URLs in this
  node profile.

Fixed MIME mapping is essential. Opening attacker-controlled bytes as
`text/html` from a same-origin `blob:` URL can turn a document feature into a
script-execution path. Content Security Policy remains defense in depth, not a
substitute for file validation.

#### Document-Node Verification

- [ ] The library exposes descriptive and document node families separately.
- [ ] Upload button and file drop use one validation/import function.
- [ ] PDF, UTF-8 Markdown, real DOCX and supported graph JSON are accepted.
- [ ] Renamed arbitrary ZIP, HTML, malformed JSON and over-limit files are
      rejected with visible errors.
- [ ] The attached filename, type, size, Open, Download and Replace survive
      host save and full browser reload.
- [ ] Moving an attached document node into or out of a container preserves its
      visual identity, original bytes and every file action; the compact card
      remains usable at the minimum container width.
- [ ] Downloaded bytes and checksum equal the imported file.
- [ ] Graph Open creates a separate validated editor tab.
- [ ] Replace removes an unreferenced old asset but preserves shared assets.
- [ ] Read-only mode disables mutation and retains safe Open/Download.
- [ ] No object URL is serialized; every created URL is eventually revoked.
- [ ] Server validation rejects forged MIME, size, checksum and storage mode.

## 8. Dependency Correlation Graphs

A dependency correlation graph answers a different question from an editable
node canvas. The canvas is an authoring surface; the correlation graph is a
derived projection of authoritative records. Operators move nodes to inspect
the layout, but dragging does not rewrite the underlying relationships.

### 8.1 Bipartite Data Model

The implemented pattern is a bipartite graph:

- entity nodes represent domain records or fixed overview blocks;
- property nodes represent reusable attributes from a shared library;
- an undirected visual edge connects a property to every entity where that
  property is placed;
- entity-to-entity and property-to-property edges are not generated.

The derivation algorithm:

1. Build the valid entity set from fixed blocks and current domain records.
2. Build a property map from the shared library.
3. Add property records found in placements even if the library is temporarily
   incomplete, without replacing the canonical instance.
4. For each valid entity, de-duplicate its placed property IDs.
5. Emit one edge from the namespaced property node ID to that entity ID.
6. Keep library properties with degree zero so the graph can expose unused
   definitions.

IDs for different node families MUST be namespaced before entering one map.
Labels are presentation only and may repeat.

### 8.2 Correlation Score

The displayed percentage measures reuse of properties across entities, not
graph density in the general graph-theory sense.

For `P` property nodes, `E` entity nodes and `c(p)` distinct entities using
property `p`:

```text
score = 100 / P * sum(max(0, c(p) - 1) / (E - 1))
```

Return zero when there are no properties or fewer than two entities. A
property used by only one entity contributes zero. A property used by every
entity contributes one before the final percentage conversion. Round the
result to two decimals and compute it on the server from de-duplicated stable
IDs; the client calculation is only a display fallback.

### 8.3 Persisted Structure

The reusable state consists of:

| Structure | Meaning |
| --- | --- |
| Description map | Text keyed by entity/block ID |
| Placement map | Ordered property records keyed by entity/block ID |
| Property library | Canonical reusable property records |
| Graph settings | Presentation and force parameters |

The server creates defaults when no state exists and merges missing graph
settings on read and write. The reference boundary rejects more than 5,000
library records or more than 10,000 placement-map keys. Those storage limits do
not imply that a browser can animate that many nodes.

The browser caches the same state locally for immediate continuity and queues a
server update about `350ms` after changes. Server state wins when it contains
authoritative property data; a non-empty local state may seed an empty server.
For a multi-user system, replace this implicit merge with revisioned optimistic
concurrency and an explicit conflict path.

### 8.4 Visual Composition

- The graph fills a bordered work area with height
  `calc(100vh - 78px)` and minimum height `520px`.
- The Canvas 2D element fills the area, disables browser touch gestures and
  uses grab/grabbing cursors.
- The backing bitmap uses device pixel ratio capped at `2` to preserve clarity
  without unbounded GPU memory.
- Background is the configured dark surface.
- Links are straight, use a 50%-white visualization stroke and render at `0.72`
  global alpha.
- Entity circles use the accent color by default. Property circles use white.
  Empty color overrides mean “follow the current theme”.
- A node's radius is the configured base multiplied by connection growth:
  `1 + min(0.25, sqrt(degree) * 0.06)`. Highly connected nodes are therefore at
  most 25% larger.
- Labels use an `11px` monospace screen-space size and start just to the right
  of the circle. Label opacity is `1 - text_fade`.
- The graph score is fixed `14px` from the top and left, accent-colored,
  `18px`, bold and non-interactive.
- A two-item legend identifies the node families by text and color.

Labels currently have no collision avoidance, wrapping or truncation. A port
to dense production data SHOULD add hover detail, bounded labels and a
decluttering strategy rather than drawing thousands of overlapping strings.

### 8.5 Control Panel

The control panel is an overlay at `top: 12px; right: 12px`, width
`min(280px, calc(100% - 24px))` and maximum height
`calc(100% - 24px)`. It uses a middle border, `12px` padding and gap, 94%-dark
translucent fill, `8px` backdrop blur and internal scrolling with a hidden
visual scrollbar.

It starts collapsed. Only a full-width Expand/Collapse button remains visible;
display controls, force controls and legend are hidden. Expanded sections use
`10px` top padding, a structural divider and `8px` internal gaps. At narrow
widths the panel maximum width reduces to `260px`.

Every range control displays its current numeric output and updates the graph
immediately. Color controls include Reset, which clears the override and
returns to the live theme rather than copying today's theme hex value.

### 8.6 Settings And Defaults

| Setting | Default | UI range and step | Actual effect |
| --- | ---: | --- | --- |
| Property color | Theme white | Color plus reset | Fill of property nodes; empty value tracks theme |
| Entity color | Theme accent | Color plus reset | Fill of entity nodes; empty value tracks theme |
| Text fade | `0.15` | `0-1`, step `0.05` | Constant label opacity is `1 - value`; `1` hides labels |
| Node size | `6` | `2-18`, step `1` | Base world-space circle radius before degree growth |
| Link thickness | `1` | `0.5-6`, step `0.5` | Screen-space line width |
| Animate | enabled | Checkbox | Enables or pauses force integration |
| Center force | `0.006` | `0-0.05`, step `0.001` | Pull toward world origin on each step |
| Repel force | `1800` | `0-3000`, step `50` | Pairwise inverse-square repulsion |
| Link force | `0.025` | `0-0.15`, step `0.005` | Spring correction toward desired distance |
| Link distance | `150` | `30-300`, step `5` | Desired world-space edge length |

“Text fade” is not a zoom threshold in the reference algorithm; it is a direct
opacity control. Name it `Label opacity` or implement true zoom-dependent fade
in a new system so the label matches behavior.

UI range attributes are not server validation. Persisted settings MUST use a
typed schema that rejects non-finite numbers, clamps or rejects values outside
the documented ranges and ignores unknown fields deliberately.

### 8.7 Initial Layout And Force Simulation

Initial positions are deterministic from stable IDs. Two independent hashes
select polar angle and a radius beginning at `80` and growing with the square
root of node count, capped by a `360`-unit spread contribution. Rebuilding the
graph reuses current position and velocity for IDs already present, reducing
visual jumps.

Each animation step applies:

1. Pairwise inverse-square repulsion with a minimum squared distance of `64`.
2. A spring on every link proportional to
   `(current_distance - desired_distance) * link_force`.
3. Center force proportional to distance from origin.
4. Velocity damping by `0.82`.
5. Position integration for every node except the node currently dragged.

Dragging writes the pointer's world position directly and zeroes velocity.
After release, the node is not pinned; forces may move it again. If persistent
manual layout is required, add explicit pinned coordinates to the authoritative
presentation state rather than confusing temporary drag position with saved
domain relationships.

### 8.8 Navigation And Hit Testing

- Pointer down uses reverse paint order and selects a node within its visual
  radius or at least a `12px` screen-space hit radius.
- Dragging a hit node moves it. Dragging empty space pans by client-pixel delta.
- Wheel zoom is clamped from `0.25` to `4`.
- Double-click resets pan and zoom to `{x: 0, y: 0, scale: 1}`.
- ResizeObserver rebuilds the backing bitmap and redraws at the new size.

The reference correlation view zooms around the canvas center. A new
implementation SHOULD use cursor-anchored zoom for consistency with the
authoring canvas, unless centered zoom is an intentional product rule.

The derived graph currently has no keyboard node navigation, selection state,
tooltip or open-details action. If it becomes more than a passive visualization,
provide an accessible parallel table, keyboard traversal or a semantic list of
relationships. Canvas pixels alone do not form an accessibility tree.

### 8.9 Performance And Lifecycle

Pairwise repulsion is `O(N^2)` per animated frame. It is suitable only for a
bounded moderate graph. Storage limits in the thousands are far above a safe
interactive force-layout limit.

A scalable port MUST:

- define a separately measured render/animation node cap;
- move layout to a worker or use a Barnes-Hut/quadtree approximation above the
  small-graph threshold;
- stop requesting frames when the view is hidden;
- use invalidation-based drawing when animation is disabled;
- avoid rebuilding data for presentation-only changes;
- cap label work and consider level-of-detail rendering by zoom;
- cancel animation and ResizeObserver on teardown.

The reference loop skips physics while the view is inactive but continues
requesting and drawing frames. Treat that as an optimization gap, not a pattern
to reproduce.

### 8.10 Dependency Graph Verification

- [ ] Node families and IDs cannot collide.
- [ ] Duplicate placement does not create duplicate edges.
- [ ] Invalid or deleted entities do not leave dangling edges.
- [ ] Degree and the correlation score use unique entity/property pairs.
- [ ] Server and client score agree for empty, single-use, partially shared and
      fully shared fixtures.
- [ ] All settings load defaults, persist, reset to theme and validate ranges.
- [ ] Deterministic initial positions are stable across reloads.
- [ ] Pan, zoom, drag, reset and high-DPI resize behave correctly.
- [ ] Animation off produces no physics movement and no unnecessary redraw
      loop.
- [ ] The measured graph cap keeps frame time within the product budget.
- [ ] A non-canvas accessible relationship representation is available.

## 9. Responsive And Accessibility Rules

Responsive behavior is based on available component width, not a user-agent
string. The primary desktop acceptance views are approximately `1919x1030`
(the supplied exports are `1919x1034`) and `1920x1080`, each with the sidebar
fixed open and fully hidden. Both states MUST be free of overlap, clipped text,
unexpected horizontal scroll and reordered reading content.

- At full reference width with the `250px` sidebar open, the main content has
  exactly `1610px` between its `30px` horizontal insets and therefore
  produces the canonical `4x`, `2x` and `1x` card widths.
- Closing the sidebar gives the extra width to the main grid. Cards expand or
  reflow through normal layout; they do not retain stale absolute coordinates.
- Below the reference content width, card tracks are fluid. When a `2x` pair
  cannot preserve readable content, it becomes one column before controls or
  values collide. At approximately `1000px`, multi-column work areas normally
  become one column.
- At `720px` and below, the sidebar becomes an explicit overlay opened by a
  labeled menu control. Main content no longer reserves `250px`.
- Forms and dense list rows collapse before text overlaps. Action order remains
  primary then secondary, and a destructive action never moves into the place
  of a routine primary action without clear labeling.
- Grid and flex children that contain text use `min-width: 0`. Fixed-format
  controls use `minmax()`, `aspect-ratio`, explicit bounds and deliberate
  overflow handling.
- A page title may shrink within its documented clamp but never overlaps the
  sidebar, divider, close action or first content row.
- Hover growth and focus outlines are included in overflow tests at every grid
  edge. Transform origins direct growth inward.
- Hide a visual scrollbar only when wheel, touch and keyboard scrolling remain
  available and the scroll position is not essential information.
- Every icon-only command, including the four-dot drag handle, has an accessible
  name and at least the platform's minimum hit target.
- Native interactive elements remain keyboard reachable. Reorderable rows and
  cards have a keyboard alternative that announces position changes.
- Status is expressed through text as well as color or animation. Green/red
  reachability, progress lines and blinking indicators are never the sole
  source of meaning.
- Reduced-motion mode disables non-essential scale, fade, sidebar movement and
  physics movement while preserving immediate state changes and focus.
- Contrast is rechecked after every valid accent preview and before persistence;
  an unusable accent is rejected with an explanation rather than saved.

Visual regression coverage MUST include the linked reference templates,
open/hidden sidebar transitions, all universal-card spans, both hover variants,
keyboard focus, context-menu edge clamping, overlay focus/viewport behavior and
Settings pending/error states.

## 10. Reference Template Catalogue

This catalogue makes every supplied image independently actionable. Dimensions
below are source-PNG dimensions. Shared tokens and behavior from sections 1-9
remain normative even when they are not repeated in every entry.

### 10.1 Shell, Navigation And Authentication Templates

#### [Example of left menu and main page side by side, base layer of main page, name of main page](<./src/Example of left menu and main page side by side, base layer of main page, name of main page.png>)

- Source canvas: `1919x1034px`.
- Purpose: canonical desktop shell with fixed-open sidebar and otherwise empty
  main workspace. It is a page-construction template, not a dashboard mockup.
- Sidebar: `250px` including its right `1px` white border. Main content begins at
  `x=250`.
- Main header: exactly `123px` high at the reference canvas with a level-one
  white bottom divider. The title starts at `left: 280px; top: 15px`, giving a
  `30px` main inset.
- Title: actual page name, accent `#00A8FF` by default, Space Grotesk Bold,
  `80px` in a measured `783x76px` reference box, one line where possible.
- Main body: black with no decorative frame. First content starts at the same
  `30px` horizontal inset and approximately `30px` below the header divider.
- Behavior: fixed-open, auto-hide and mobile-overlay sidebar modes use the same
  DOM/navigation order. When the sidebar hides, the main header divider and
  body expand to the left; the title and content recalculate from the new main
  region rather than retaining `x=280` as a fixed screen coordinate.
- Verification: compare open and hidden states at `1919x1034` and `1920x1080`;
  no seam, double border, stale blank column or horizontal scrollbar is allowed.

#### [example Left Menu](<./src/example Left Menu.png>)

- Source canvas: `250x1033px`; it represents the complete expanded sidebar.
- Background: `#000000`. The standalone crop omits the right boundary, while
  the combined page exports render it at `x=250`; production always uses the
  canonical `width: 250px; border-right: 1px` border-box contract.
- Brand zone: actual service icon in a `192x192px` box at `left: 31px; top: 6px`.
  The service name uses `42px` accent Space Grotesk Bold in a `170x76px` box
  centered on `x=125px` with `top: 175px`.
- Primary navigation begins with the active `221x42px` row at
  `left: 18px; top: 285px`. Labels start at `left: 31px`; adaptive ordinals at
  `left: 209px`; both use `14px` Consolas Bold. Exact row text origins are in
  section 4.2.
- Active row: `1px` accent rectangle, accent label and an external left arrow
  with rectangular base. The arrow points at the row center and must not change
  the row's measured width. The base is `4x22px` at `left: -2px; top: 295px`;
  the triangle is `12x5.77px` at `left: 0`, centered around `top: 306px`.
- Inactive row: transparent reserved border, white/80%-white text, black fill.
  Pointer hover applies the shared Hover 1/2 contract without moving adjacent
  rows.
- Reorder: all primary rows, including Settings, may move; drop preview is an
  accent before/after line. Ordinals recompute sequentially and order persists.
  The legacy `01, 02, 04, 05, 06, 07` values visible in the PNG are not valid
  production numbering.
- Bottom group: Documentation and Logout are left aligned, unnumbered, unboxed,
  unscaled and non-draggable. Their only pointer-hover color change is accent.
- Overflow: if translated off-screen in auto-hide mode, no focusable hidden
  navigation remains accidentally reachable; revealing it restores normal
  keyboard order.

#### [example Log in page](<./src/example Log in page.png>)

- Source canvas: `1919x1034px`; background is uninterrupted `#000000`.
- The combined brand and authentication panel is centered. The bordered panel
  is exactly `560x268px` at `left: 680px; top: 444px`, matching
  `min(560px, calc(100vw - 48px))` on narrow screens.
- Brand: actual service name in accent `72px` Space Grotesk Bold; actual service
  icon to its right in a `100x100px` box. Exact painted example bounds are in
  section 4.1.
  Both form one accessible brand heading/group despite separate visual items.
- Panel: level-one `1px` white outline, square corners, black fill, no shadow.
  Inner horizontal inset is approximately `24px`.
- Reachability block: compact bordered status at the top-left of the panel.
  It is `255x50px` at `left: 705px; top: 466px`. Reachable uses `#62FF8C`
  text/square and an 80%-semantic `#4ECC70` nested border with one smooth
  two-second fade cycle. Unreachable uses danger red and a static square.
- Form: exactly one empty masked Access Key control followed by one full-width
  `Enter service` button. The field is `511x31px` at `left: 705px; top: 578px`;
  the button is `511x50px` at `left: 705px; top: 635px`. Both use nested
  80%-white borders at rest.
- Interaction: Enter and button submit the same operation; pending disables
  duplicate submission without size change; rejection preserves the panel and
  never changes reachability state.
- Responsive: below `608px`, panel and brand fit within `24px` viewport insets;
  icon may reduce, but the Access Key control and button remain full width.

### 10.2 Hover-State Templates

#### [example - hover - no hover](<./src/example - hover - no hover.png>)

- Source canvas and base control box: `375x166px`, corresponding to a reference
  `1x` untitled universal card.
- Fill: `#000000`; outer border: `1px` structural white at the appropriate
  hierarchy level.
- Ordinal: two digits at `left: 10px; top: 10px`, `14px` Consolas Bold and
  80%-white.
- Drag handle: four `4x4px` `#D9D9D9` dots in the exact two-by-two geometry from
  section 5.2. The visible mark does not reduce the card's content width;
  content padding reserves its hit target.
- This rest state contains no accent merely because the card is reorderable.

#### [example - hover - hover 1](<./src/example - hover - hover 1.png>)

- Source canvas: `380x169px`. It shows the normal pointer-hover control box
  used by the historical mockup. Its dimensions are not the normative output of
  the current proportional-growth formula.
- Fill changes exactly to `#111111`; the element border becomes `#00A8FF` or
  the configured accent.
- Existing non-interactive content color is preserved; the four-dot handle
  remains white. Accent is carried primarily by fill/border in this variant.
- Production growth uses the short-side formula in section 3.1 and a `160ms`
  eased transform. For a `375x166px` card the computed box is approximately
  `383.3x174.3px`; it is composited and never updates grid width or height.
- At a grid boundary, transform origin turns inward so the accent border and
  content remain visible.

#### [example - hover - hover 2](<./src/example - hover - hover 2.png>)

- Source canvas: `388x177px`. In this historical mockup the inner card is
  `380x169px` at `left: 4px; top: 4px`; production keeps this visual anatomy but
  applies it around the formula-derived Hover 1 box.
- Fill is `#111111`; the element border and outer `1px` outline are accent,
  separated visually by approximately `3px` of black.
- The interactive label or ordinal becomes accent; the drag dots remain white.
- Use this as the keyboard-focus minimum and for an intentionally emphasized
  hover target. The outline is an overlay and MUST NOT enlarge layout bounds.
- Pressing either hover variant uses the canonical `scale(.985)`/`60ms` feedback;
  reduced-motion retains the color and outline changes without scaling.

### 10.3 Universal Card Templates

#### [universal card - 1x](<./src/universal card - 1x.png>)

- Source size: `375x166px`.
- Untitled `1x` anatomy: ordinal upper left, four-dot handle upper right, no
  header divider and one uninterrupted body.
- Use for a compact metric, status, action group or short summary that remains
  understandable at the narrowest desktop card width.
- Content must wrap or simplify before it overlaps the ordinal/handle reserve.

#### [universal card - 1x - title](<./src/universal card - 1x - title.png>)

- Source size: `375x166px`.
- The horizontal divider occupies source row `y=54px`. Ordinal appears first,
  accent title follows on the same baseline, and the handle remains at the
  upper right.
- A `1px` divider spans the full inner width below the header and uses the
  inner `--line-inner` token at 80%-white. The outer card border is independently
  100% white at top level or 80% when the entire card is nested.
- Title truncation is a last resort: prefer a shorter product label, then a
  bounded two-line header that increases card height consistently.

#### [Universal card - 2x](<./src/Universal card - 2x.png>)

- Source size: `790x166px`, derived from two `1x` tracks plus a `40px` nested
  gap in the reference hierarchy.
- Untitled anatomy and interactions are identical to `1x`; additional width
  is for richer values, small charts, paired controls or longer status text.
- Do not center a narrow `1x` composition inside it. Its content grid should
  deliberately use or bound the available width.

#### [Universal card - 2x - title](<./src/Universal card - 2x - title.png>)

- Source size: `790x166px`.
- Uses the same exact source divider at `y=54px`, full-width divider,
  ordinal/title baseline and top-right handle as the titled `1x` card.
- Header actions, when needed, appear before the drag handle and do not replace
  it. Focus and hover targets remain visually distinct.

#### [universal card - 4x](<./src/universal card - 4x.png>)

- Source size: `1610x166px`, the full reference main-content width.
- Untitled full-width region for timelines, tables, graphs or composite status
  whose structure supplies its own internal heading.
- It spans both primary `2x` groups and therefore participates as one reorder
  item. Its placeholder must also span the complete grid width.
- Wide content still needs a maximum readable line length or internal columns;
  width is not permission to create a single unbounded text line.

#### [universal card - 4x - title](<./src/universal card - 4x - title.png>)

- Source size: `1610x166px`.
- Canonical full-width settings/collection section: adaptive ordinal, accent
  title, top-right handle and full-width divider at source `y=54px`.
- In the supplied top-level `4x` titled template the outer border is
  `#FFFFFF` and the inner divider is `#CCCCCC`, directly demonstrating the
  two-level hierarchy.
- Body height expands for content. A `166px` source file illustrates the minimum
  anatomy, not a maximum settings-section height.
- When this card is nested inside another bordered workspace, its border and
  divider both use 80%-white; descendants do not introduce a third opacity.

### 10.4 Dashboard Template

#### [example dashboard](<./src/example dashboard.png>)

- Source canvas: `1919x1034px`; sidebar and page header follow section 10.1.
- Main card region begins at `left: 280px; top: 151px` and has an exact
  `1610px` `4x` width.
- Row 1: CPU Usage and RAM Usage, each `790x166px`, with a
  `30px` primary gap.
- Row 2: Disk Usage and Uptime in the same geometry, separated from row 1 by
  `30px`.
- Row 3: one optional `4x` card, separated by `30px`.
- Row 4: example optional `1x` cards demonstrating narrow spans and a `40px`
  nested gap. Empty example cards mean available extension positions, not
  required blank UI.
- Exact global coordinates for every shown card are defined in section 5.3 and
  are normative visual-regression fixtures for this viewport.
- Every card shows an adaptive ordinal and four-dot handle. Metric titles use
  accent Consolas Bold; values use white Consolas Bold; labels and units remain
  textual.
- CPU, RAM and Disk use a bottom progress line with accent completed portion and
  structural remaining portion. Clamp display to `0-100%` while preserving an
  explicit over-limit diagnostic if the source can exceed its contract.
- Disk percentage and used capacity use `f_bavail` for the relevant service
  data filesystem exactly as specified in section 5.3; they do not use
  `f_bfree` or an unrelated container/host filesystem.
- Uptime has no progress line because it has no meaningful fixed maximum. It is
  the current service-instance uptime and resets on a service/container restart;
  it is never the host's boot uptime.
- Refreshes update text and progress without resizing cards. Stale or failed
  telemetry is named and timestamped; it is not displayed as a healthy zero.

### 10.5 Settings Templates

The card exports below define the Settings visual targets. The newer Security,
Gryphon and Wyverne crops linked in sections 5.5, 10.5.5 and 10.5.6 take
precedence over older settings canvases for those cards. Their ordinals are examples;
actual values follow the persisted card order. Application names, versions,
adapter usernames, provider names and routes inside the PNGs are illustrative.
The explicit `Gryphon Connection` and `Wyverne Connection` display labels
are required where those components are consumed.

The operator-approved schedule location is now the owning service's Backup
card. Its checkbox, interval and remote-run action are functional controls,
not deprecated placeholders. Central storage retains identity, quota, access
and observation responsibilities but no competing schedule authoring surface.

#### [example settings main](<./src/example settings main.png>)

- Source canvas: `1919x1034px`; fixed-open sidebar, `settings` page title and
  `123px` page header follow the shell template.
- Full-width sections begin at `x=280`, end at design coordinate `x=1890` and
  use the exact `1610px` reference width. Appearance is
  `left: 280px; top: 153px; width: 1610px; height: 401px`; Security is
  `left: 280px; top: 581px; width: 1610px; height: 418px`.
- Section header specifies an 80%-white divider at local `y=55px`; the raster
  appears at `y=54px`, which is the accepted one-pixel border tolerance. The
  adaptive ordinal starts at `left: 14px` relative to the card and the accent
  title at `left: 39px`. The complete global ledger is in section 5.5.
- The two Appearance references show the same `401px` baseline card. Its two
  groups and exact control coordinates are defined in section 5.5. Color
  correction places a swatch, hex field, Reset and Apply actions on one
  controlled row at desktop width; they wrap in that order before collision.
- Accent changes preview immediately. Only Apply persists. Sidebar-mode toggle
  persists immediately and updates the shell after the setting succeeds.
- Security body separates Access Key rotation from control-plane connection with clear
  headings and consequence text. Buttons open overlays; they do not expose
  secret inputs inline in the permanent page.
- The sentence `Changing the operator password...` in the legacy PNG means
  changing the Access Key. A separate operator password does not exist and the
  legacy term MUST NOT ship.
- Control-plane connection shows URL, public identity/status and reachability without
  exposing the token. Token rotation uses one full-width action.
- Settings sections carrying a four-dot handle are reorderable and persist their
  new order; ordinals recompute after drop.

#### 10.5.1 Shared Settings Card Ledger

| Element | Required desktop value |
| --- | --- |
| Outer card | Full available `4x` width; `1610px` at the reference shell width; content-driven height |
| Background / corners | `#000000`; radius `0`; no gradient or decorative shadow |
| Borders / divider | `1px`; white for a standalone top-level card, `#CCCCCC` for nested borders; never compound opacity |
| Header | `55px` including divider; ordinal at local `x=14px`, title at `x=39px` |
| Ordinal | `14px/22px` Consolas Regular, secondary white; recomputed after reorder |
| Card title | `24px/29px` Consolas Bold, configured accent (baseline `#00A8FF`) |
| Group heading | `20px/24px` Consolas Bold, primary `#FFFFFF` |
| Body / labels / controls | `14px/22px` Consolas Regular; Bold only for emphasis/important values |
| Secondary copy | `--white-80`, rendered `#CCCCCC`; never opacity applied to the complete card |
| Body insets | Reference `39px` left and about `33px` right; approximately `27–30px` from header divider to first heading |
| Text/action rhythm | `8px` heading-to-copy gap, `20px` copy-to-action gap; ordinarily `38–48px` between semantic groups, with the Appearance color-row-to-heading gap measured separately in section 5.5 |
| Ordinary action | `326x40px`, black fill, nested border, `18px` inline padding; longer labels grow/wrap without truncation |
| Status row | Full content width, `40px` minimum height, `16px` inline padding, `12px` text-to-indicator gap |
| Status indicator | `18x18px` square; `#62FF8C` healthy, `#F83D3D` failed, neutral secondary white for unknown/stale |
| Paired status rows | `12px` vertical gap |
| Checkbox | `20x20px` visual square with `1px` nested border; at least `40px` labeled target, `44px` on a coarse pointer |
| Numeric interval input | `80x40px`, `8px` inline padding, centered `14px` monospace digits; visible label |
| Reorder handle | Four approximately `3px` dots in a `2x2` grid, `3px` gap; visual group about `9x9px`, inset `8–12px` from upper right |

The entire reorder target is at least `40x40px` (touch `44x44px`); its
invisible hit region must not intercept a neighboring action. Dots use the
shared decorative-dot token at rest and white on interaction. Dragging and
keyboard reorder follow section 3.2 and persist only card order.

Source raster heights are fixtures for the pictured content, not fixed-height
containers. Initialize, pending state, a second backup pipeline, error details
and long labels expand the card. Approximate `52px` headers and `39px`
rows in cropped exports normalize to the shared `55px`/`40px` tokens.
The compact `57x28px` interval field pictured below normalizes to the
accessible `80x40px` control; its adjacent command may stretch with the group.
These are explicit corrections, not unexplained layout drift.

Use the shared hover/focus rules: `#111111` fill, accent border/focus outline,
`160ms` transition and `60ms` press feedback. Pending controls preserve
their size with `0.45` opacity and a reason/progressive label. Reduced motion
removes transforms/animation but preserves all state distinctions. A dim green
pixel in a capture is not a new status token. Reachability never means that
enrollment, functional binding or the latest backup also succeeded.

Below `1000px`, command bands wrap before collisions. At `720px` and below,
use `20px` body insets; at `420px` use `16px`. Buttons fill their available
track, paired fields/actions stack in reading order, status text wraps before
the indicator, and headers reserve the handle's hit area. Keep `14px` body
text, visible focus and no page-level horizontal scroll at 200% zoom.

#### 10.5.2 Logs Card

![Logs card with recording preference, live events and archive download](./src/example-logs.png)

Source canvas: `1614x728px`. The outer card is `1594x713px` at crop
`(11,6)`; its narrower width is a capture of a fluid card, not a second size
token. The table is `1516x460px` at `(50,165)`, its header divider at
`y=201px`. The `207x40px` download action begins at `(1359,88)`;
`Load older events` is approximately `169x40px` at `(50,641)`.
The checkbox's visible `20px` square starts at `(54,122)`.

The command band places the description and recorder preference on the left,
with archive download on the right. The table follows with `16px` separation;
older-page loading is `16px` below it. Keep its viewport bounded to
`460px` with internal vertical scrolling; the header remains visible.
Use columns TYPE, BODY and TIME: `68px minmax(0, 1fr) 166px` inside
`16px` inline table insets at desktop, with a `36px` header and `25px`
minimum row step. Multi-line outcomes grow only that row. A long type such as
`NOT-MODIFIED` may wrap at its semantic separator; it cannot overlap BODY.
TIME is right-aligned in `dd.mm.yyyy hh:mm:ss`; BODY receives flexible width.
Data rows have no horizontal separators. On narrow screens TIME moves below
the body with a label; outcome remains visible.

The list is newest-first. Incoming events preserve a reader's scroll anchor;
load-more appends older records and preserves the current position. Stable
event IDs deduplicate reconnects. Show loading, no events, no older events,
permission denied and stale/offline distinctly. The recorder checkbox changes
future routine revision-request logging, not table filtering or mandatory
security/error auditing. Its preference persists and survives logical restore.
Download exports retained authorized logs, not just the currently visible page.
Detailed data/security rules are in
[Part 02 section 12](./PART_02_OBSERVABILITY_AUDIT_AND_LOG_EXPORT.md#12-web-log-view-and-download-contract).
The captured white title is not a separate palette: use the configured card
title accent consistently.

#### 10.5.3 Backup Card

![Backup card reference with separate archive and mirror status](./src/example%20-%20settings%20-%20backups/example%20-%20settings%20-%20backups%20-%20advanced.png)

Use the reference layout while retaining each service's actual snapshot scope,
restore flow and theme. Laboratory retains its original editorial palette.
The card has no manual Saturn transfer or Neptune update action.

Groups appear in this order:

1. `Manual snapshot`: actual logical scope/exclusions and
   `Create and download snapshot`. Volt also offers `Download personal.volt`.
2. `Automatic backup to <storage>`: explanation, agent status, separate
   observed status for each available pipeline, one schedule enable and
   interval control, then contextual Link/Repair or Unlink action.
3. `Restore snapshot`: description and `Browse local snapshot archive`,
   opening the restore overlay and native picker. The reference labels this
   group `System snapshot`; the service card names the restore action explicitly.

The connected state shows a red `Unlink Neptune agent` button. Confirmation
starts a service-scoped Updater job: Neptune stops new archive and mirror work,
waits for accepted transfers, asks Saturn to revoke that service's producer,
mirror and reader credentials, then removes only that service's registration.
The shared daemon and other services remain connected; saved Saturn archives
remain available. During `unlinking`, Link is blocked and Unlink offers retry
if the previous job failed; Updater serializes lifecycle jobs. Reconnection
requires a fresh setup code.

Initialization is shown when the agent is absent or this service is not
enrolled. Its completion exposes editable scheduling; an offline agent does
not masquerade as absent. Healthy reachability, profile completeness, schedule
saved/applied and last successful remote commitment are distinct observations.
For Volt and Mastermind, show separate named archive and mirror status groups.
One checkbox and one hourly interval change both schedules atomically; each
pipeline keeps its own execution state and last successful commitment.

The checkbox persists enabled state on explicit change. Interval is integer
hours with `min=1`, `step=1` and the advertised server maximum, if any;
the default is `24`. Commit valid edits on Enter or blur once, not on every
digit. Reject blank, zero, negative, fractional and overflow values; never
silently clamp them. A failed save restores the last confirmed control value
and retains an inline explanation. Disable duplicate commits while pending.

Automatic backup is initially off for a genuinely new profile; imported
profiles preserve their actual values. Enabling or changing interval does not
start a backup immediately. Show desired/applied policy, next run, last success and
current job/error near the controls without exposing credentials. Central
storage no longer owns editable schedule controls. Neptune release checks and
updates are available only through `sudo updater tui` on the host. Semantics and handover are
in [Part 10 section 2](./PART_10_SERVICE_AGENTS_UI_AND_OPERATOR_WORKFLOWS.md#2-backup-and-neptune-panel).

#### 10.5.4 Updates Card

![Updates card reference for the application release](<./src/example - settings - updates/example - settings - updates.png>)

The card contains only the application release action and its status. The
removed Updater version block does not reserve space; card height follows its
content.

`Update pipeline` describes release discovery and the local executor.
Application version appears first, its value in accent. Show update-helper
and registry reachability as separate rows. The first check action targets the
application. Updater release checks and self-updates use `sudo updater tui` on
the host; the service GUI has no separate Updater version or update controls.
An unavailable observation is not a fabricated version or healthy zero. The
application action opens the [section 10.8 update overlay](#108-update-dialog-templates)
and downloads the full ZIP before submitting the update.

#### 10.5.5 Gryphon Connection Before And After Binding

![Gryphon Connection before a service function is linked](<./src/example - settings - gryphon/example - settings - gryphon - not connected.png>)

![Gryphon Connection after a service function is linked](<./src/example - settings - gryphon/example - settings - gryphon - сonnected.png>)

Both cards have one `Gryphon adapter binding` group, two full-width `40px` status
rows, the applied connection name, and one `326x40px` action. A ready agent
and an absent applied connection show `Link Gryphon function`; a connected
service shows `Change Gryphon function`. The selected adapter's safe alias is
visible without exposing its API token or Telegram identity secrets. The
permanent card has no registration, Telegram pairing, version or unlink action.

The [unconnected selection overlay](<./src/example - settings - gryphon/example - settings - gryphon - connection choice overlay - not connected.png>)
lists ready adapters paired through Gryphon, or points the operator to
`sudo updater tui` when none are available. Selecting an adapter applies its
already verified Telegram account to this service without another code or
confirmation step. One adapter is selected per service; other service bindings
are independent. The
[connected overlay](<./src/example - settings - gryphon/example - settings - gryphon - connection choice overlay - connected.png>)
highlights the active adapter, shows non-secret adapter details alongside the
list, and offers `Unlink all adapters`. A selected adapter that is no longer ready
may be shown for context but cannot be applied until ready. Re-selecting a
ready active adapter can restore a revoked service binding. Unlink requires
confirmation and removes this service's binding only; shared adapters and other
services remain connected. The desktop overlay is about `760px` wide with a
`55px` title row and approximately `52px` adapter rows; its list and detail panes
stack on narrow screens. Adapter registration, `/link CODE`, and shared version
management remain in Updater TUI.

#### 10.5.6 Wyverne Connection

![Wyverne Connection before binding](<./src/example - settings - wyvern/example - settings - wyvern connection - dont connected.png>)

![Wyverne Connection after binding](<./src/example - settings - wyvern/example - settings - wyvern connection - connected.png>)

![Wyverne Connection error state](<./src/example - settings - wyvern/example - settings - wyvern connection - error.png>)

The state crops are each `1610x426px`; the source
[settings canvas](<./src/example - settings - wyvern/example - settings - wyvern.png>)
places the card beside its Adapter-choice overlays. The implemented Mastermind
card follows that geometry with one `Wyverne adapter binding` group: a short
provider-ownership explanation, two full-width status rows for local Wyvern
reachability and active-Adapter readiness, the safe active Adapter name or
`none`, then one `Link Wyverne function` / `Change Wyverne function` action.
The action is `326x40px` at the reference width. Waiting, unavailable and
ready observations remain distinct. A missing gateway or failed Adapter shows
the concrete error and preserves any last-known selection. The second row must
not imply that merely opening Settings has sent a provider request. No release
check or provider probe runs when the card or choice window opens.

Laboratory uses the same information and binding flow inside its original
editorial Settings card. Its existing section heading, Space Grotesk type,
surface colors, semantic status colors and native dialog treatment remain
authoritative there; the black Mastermind canvas is not a Laboratory theme.

The [unconnected choice overlay](<./src/example - settings - wyvern/example - setting -wyvern - connection choice overlay - not connected.png>)
lists only Adapters registered in Wyvern, granted to this client and compatible
with the selected function's required capabilities. If the service has several
functions, an explicit function selector scopes the list; changing one binding
preserves the others. An empty list points the operator to `sudo updater tui`
for Adapter configuration or client enrollment. A formerly selected but
unavailable choice may remain visible for context and cannot be applied. The
[connected choice overlay](<./src/example - settings - wyvern/example - setting -wyvern - connection choice overlay - connected.png>)
marks the active selection and shows only safe, non-secret configuration details
for that function. Selecting a new choice asks for binding confirmation, then
saves this service's choice without a release check or provider request.
Its `Unlink all adapters` action, after confirmation, clears only this service's
function bindings; it never deletes a shared Adapter, revokes another client or
removes provider credentials. A choice applies the intended service function
with the observed binding revision and stable operation ID. Conflicts require
refresh and explicit review; failed writes preserve the previous binding.
The desktop source is `773x716px`; the implemented window is about `760px`
wide with a `55px` title row and `52px` choices. Its list and details use two
columns on desktop and stack on narrow screens. Laboratory uses the same
structure with its own surface, type and accent colors.

The title is `Wyverne Connection`; the gateway's executable and API identity
remain `wyvern`. The images' claims that Gryphon owns LLM connections and that
every displayed connection is already applied are copy errors: Wyvern owns
provider connections, and the list contains this client's permitted choices.
The illustrated provider and Adapter names are sample data, not defaults.
Consumer Settings must not expose provider keys, another client's bindings or
the host-admin socket.

This card and overlay are implemented in Laboratory and Mastermind. The former
Gateway, Client connection, Allowed Adapter and Wyvern version groups and their
installation, management and release-check buttons are absent. Shared Wyvern
release checks and updates happen in Updater TUI without choosing a service;
Updater reads Kernel Register through its own machine connection and uses the
Wyvern URL saved in root TUI only when Kernel is unavailable. First installation
needs no service choice; a consuming installer may ensure Wyvern and link its
own client automatically. Consumer Settings only choose permitted Adapters and save
their own function bindings.

#### 10.5.7 Card Acceptance

Compare all applicable crops and full-shell views at `1919x1034`, `1920x1080`,
`1000px`, `720px`, `420px`, `360px`, 200% zoom and coarse-pointer
input. Check header, insets, group rhythm, status squares, button targets and
before/after expansion against the measured ledgers; allow only documented
crop and accessible-control corrections.
Exercise reorder persistence, keyboard activation/focus, long identities,
multiline log types/errors, live list anchoring, disabled/pending states,
schedule validation/revision conflicts, empty/partial bindings and all
initialization outcomes. The functional matrix is in Part 10 and Part 06.

### 10.6 Context Menu Template

#### [example context menu](<./src/example context menu.png>)

- Source size: `155x197px`; it illustrates a compact eight-command menu.
- Background is `#FFFFFF`; text is `#000000`; the highlighted command uses the
  configured accent. Anti-aliased grays in the PNG are rendering artifacts, not
  additional palette tokens.
- Text uses compact Consolas Regular/Bold as required by command emphasis.
  Numbers and labels align consistently; localized production menus need not
  display numeric prefixes unless numbers are meaningful shortcuts.
- Rows use `22px` line height with list origin `left: 16px; top: 9px` and
  `21px` list-item indentation. Hover does not resize rows or the menu.
- The example command list is non-normative. Authorization determines whether
  download, delete, rename, share or other actions are present and enabled.
- Pointer hover, keyboard focus and current selection use accent without
  changing the inverted white surface. Destructive meaning must still be named;
  accent hover does not convert a destructive command into a safe action.

### 10.7 Documentation View Template

#### [documentation](./src/documentation.png)

The raster is a reference implementation of the universal Documentation view,
not a source of product terminology. Its identity, version, breadcrumb, section
names and article copy are illustrative and MUST be replaced with the adopting
application's real, versioned operator documentation. No name shown in the
raster becomes a reusable product or content requirement.

**Shell and outer workspace**

- Source canvas: `1661x1033px`. Any dark matte, crop, shadow or browser capture
  edge belongs to screenshot presentation and is not an application surface.
- The shared desktop header is `123px` high. The content area uses `28px` top,
  `30px` inline and `40px` bottom padding. The page title follows the standard
  desktop display role: Space Grotesk Bold, up to `80px`, at the shared title
  origin and in the configured accent.
- The Documentation workspace is `width: 100%`, `max-width: 1610px`, centered
  inside the content insets and sized to the remaining viewport height. In the
  canonical desktop shell its block size is `calc(100dvh - 191px)`, preceded by
  a `100vh` fallback. The `191px` is derived from `123 + 28 + 40`; an adopting
  shell recomputes the expression from its own shared tokens.
- The workspace uses `min-height: 0`, `overflow: hidden` and never becomes a
  page-level scrollbar. Every flex/grid ancestor on the path to the two inner
  scroll regions also uses `min-height: 0`; flexible inline tracks use
  `min-width: 0`.
- On desktop the workspace grid is `220px minmax(0, 1fr)` with a `30px` gap and
  `align-items: stretch`. The article column is capped at `1120px`; surplus
  inline space remains outside the article rather than lengthening prose.
- Hiding the global sidebar only releases shell width. It does not change the
  `220px` documentation-navigation width, `30px` gap, `1120px` article maximum
  or any internal scroll ownership. Showing it again reflows the grid without
  restoring a stale horizontal offset.

**Exactly two scroll owners**

- The first scroll owner is the complete documentation-navigation region:
  search, group headings and section destinations. The second is the complete
  article region: guide header, all matching sections, notes, lists, code and
  tables. There is no third Documentation scrollbar on the grid, page body,
  shell or browser document.
- Both regions stretch to the workspace block size and set `min-height: 0`,
  `overflow-y: auto` and `overscroll-behavior: contain`. Scrolling one MUST NOT
  alter the other's `scrollTop`. Reaching either boundary MUST NOT chain the
  remaining wheel/touch delta to the page or the other region.
- Both visual scrollbars are hidden while their scrolling capability remains
  intact. Use `scrollbar-width: none` for Firefox and a `::-webkit-scrollbar`
  rule with `display: none; width: 0; height: 0` for Chromium/WebKit. Do not
  hide overflow, intercept normal wheel/touch input or cover a scrollbar with
  an overlay.
- Pointer-wheel and touch input belong to the region under the pointer. Page
  Up/Down, Home/End and arrow-key input belong to the focused region. Each
  region therefore has an accessible name; the article owner is focusable when
  its contents do not provide a dependable keyboard entry point. Hidden
  scrollbars do not remove visible focus treatment or keyboard operability.
- The search field and navigation sections remain visually stationary when the
  article is scrolled because the left `scrollTop` is unchanged. Conversely,
  scrolling a long navigation index does not move the guide header or article.
  `position: sticky` on the left column is neither required nor an equivalent
  substitute for the two-owner model.

**Navigation region**

- The desktop region is exactly `220px` wide and has no enclosing card or outer
  outline. Its inner stack is a grid with `20px` row gap and `30px` bottom
  padding, allowing the last destination to clear the viewport edge.
- Search is `220x40px`, black, with a `1px #CCCCCC` nested outline and `12px`
  horizontal inset. Placeholder text is not its accessible name. A non-empty
  query reserves room for the clear cross defined in section 5.6; input, clear,
  loading and no-result states do not change the control's dimensions.
- Filtering is immediate and local to the rendered documentation set. It uses a
  trimmed, case-insensitive query over visible title, summary, keywords and body
  text. A query change or clear resets only the article scroll owner to
  `scrollTop = 0`; the navigation position may remain only if it is clamped to
  the new range.
- Group headings use Consolas Bold in the nested 80%-white tone with `8px`
  block margins. Destination labels use Consolas Regular, fill the `220px`
  column, have `min-height: 36px`, `7px` block padding and a `1px #CCCCCC`
  block-end separator. Hover, focus and current-section states use accent and
  `#111111` hover fill without moving, scaling or resizing a row.
- Navigation order follows the information architecture, not primary-sidebar
  numbering. Empty groups are omitted. If no section matches, the search remains
  operable and the article owner renders a bordered no-result message with
  `30px` padding rather than collapsing either grid track.

**Article region**

- The article owner is black with a `1px` top-level white outline,
  `max-width: 1120px` and `24px 32px 64px` padding. It stretches to the bounded
  workspace height. The inner semantic document grows to any required length
  and is scrolled inside this owner; it MUST NOT increase page height.
- The guide header has `30px` bottom padding and a `1px #CCCCCC` block-end
  divider. Its kicker is `14px/22px` Consolas in accent. The guide title is
  `36px/44px` Space Grotesk Bold with `8px` vertical separation. The scope
  paragraph is `14px/22px` Consolas in the secondary text color.
- Every visible topic is an `article` or equivalent semantic section with one
  stable unique fragment identifier, `30px` block padding, `30px`
  `scroll-margin-top` and a `1px #CCCCCC` trailing divider. The final visible
  section omits the divider. Level-two topic headings are `22px` Bold in accent;
  nested headings are `16px` Bold with approximately `26px` top margin. Summary
  copy has `22px` bottom separation; body copy uses `14px/22px` or an equivalent
  `1.7` line height.
- Lists use `24px` inline-start padding and `8px` item gap. Inline code uses a
  `1px #CCCCCC` outline, `1px 4px` padding and `#111111` fill. Code blocks use a
  `1px` nested outline and `14px` padding, with horizontal scrolling only where
  wrapping would corrupt code. Tables fill the article width, collapse borders
  and use `8px` cell padding; at narrow widths the table wrapper, never the
  page, may scroll horizontally.
- Notes use a rectangular `#111111` surface, `2px` accent inline-start rule and
  `14px` padding. Success, warning and failure meaning supplements color with
  explicit text or an icon. Links, copy actions and interactive examples expose
  pointer, keyboard, success and failure states; clipboard failure retains a
  manual-selection fallback.
- The kicker or breadcrumb identifies the current application, document version
  and guide context without exposing filesystem paths, private repository
  coordinates, credentials or secret-bearing identifiers. Actionable ancestors
  are keyboard operable and use textual separators instead of decorative-image
  separators.

**Navigation and state mechanics**

- Activating a destination calculates its position relative to the article
  owner and scrolls that owner only, leaving page and navigation offsets
  unchanged. The target rests `30px` below the article owner's top edge. Smooth
  movement is optional; reduced-motion preference always uses an immediate jump.
- Article scrolling continuously synchronizes exactly one current destination
  with the reading position. Use a line `30px` below the article owner's top:
  select the last visible topic whose block-start has crossed it, the first
  visible topic before any crossing, and the final visible topic at maximum
  scroll. Apply accent and current semantics without moving the navigation/page,
  changing focus or triggering a feedback scroll.
- Keyboard activation either retains focus in the navigation while exposing the
  current target state, or moves focus to the target heading without breaking
  reading order. If fragment URLs/history are implemented, back and forward
  restore a coherent target inside the same article scroll owner.
- Filtering renders all matching topics in one continuous semantic document,
  preserving document order and stable identifiers. Clearing restores the full
  document at article offset zero. Reopening the view resets both owners unless
  an explicitly documented per-view restoration policy is implemented.

**Responsive geometry**

- Above approximately `1000px`, the two owners are side by side. At and below
  that breakpoint the grid becomes one column with two bounded rows:
  `minmax(160px, 34%) minmax(0, 1fr)`. Navigation occupies and scrolls inside
  the first row; article occupies and scrolls inside the second. Stacking MUST
  NOT merge them into one page scrollbar.
- At `720px` and below, the shared header is `96px`, page content uses `20px`
  block padding and workspace height is `calc(100dvh - 136px)` with `100vh`
  fallback. Rows become `minmax(150px, 34%) minmax(0, 1fr)`. Article padding is
  `20px 20px 48px`; its guide title is `30px/38px`. The global sidebar follows
  its modal-overlay contract and introduces no horizontal page overflow.
- On exceptionally short viewports, preserve the search, at least one navigation
  row and a usable article viewport. Both owners absorb overflow internally.
  Resize, zoom, mobile browser chrome and virtual-keyboard changes clamp stale
  offsets into the new valid ranges rather than leaving blank space.

**Required visual and interaction proof**

- Capture desktop sidebar-open and sidebar-hidden states at `1919x1034` and
  `1920x1080`, plus representative `1000px`, `720px` and short-height cases.
- In each state, independently drive the left owner to its end and the right
  owner to a middle/deep section with mouse/trackpad, keyboard and touch where
  supported. Assert that the other owner and page offset remain unchanged and
  that neither scrollbar is visually present.
- Verify search hit, clear and no-result states; destination navigation with the
  `30px` reading offset; current-destination synchronization during pointer,
  touch, keyboard and scripted article scrolling; first/last-topic boundary
  behavior; reduced motion; focus visibility; 200% zoom; long labels; long
  code/table content; and the last navigation/article item clearing its bottom
  inset without clipping.

### 10.8 Update Dialog Templates

This is the browser update component for an application's own release. Its
composition, controls and state transitions apply to that release flow. Shared
Updater, Neptune, Gryphon and Wyvern release checks and installs use the host
TUI; their service cards do not open this dialog. The application name and
installed/target versions are data; no product name, historical version, host,
job ID or repository shown in a raster becomes part of this reusable contract.

These six PNGs define the visual baseline together with sections 2, 3.1 and
3.3. [Part 05 section 34](./PART_05_CI_RELEASES_AND_LOCAL_UPDATES.md#34-operator-update-ui)
defines functionality. A screenshot is a composition fixture, not evidence that
its old status text or every pictured action remains correct.

#### 10.8.1 Palette And Typography

| Role | Required value |
| --- | --- |
| Dialog, panels and resting controls | True black `#000000`; no gradient, texture or decorative shadow |
| Primary text and outer dialog border | `#FFFFFF` |
| Labels, explanatory text, dividers and all nested outlines | `--white-80`, rendered as `#CCCCCC` on black |
| Hover/focus fill | `#111111` |
| Links, focus and active progress | Configured `--accent`, baseline `#00A8FF` |
| Verified success | `#62FF8C`, always accompanied by outcome text |
| Failure, consequential confirmation and rollback control | `#F83D3D`, always accompanied by action/outcome text |
| Backdrop | `rgba(0,0,0,.35)` and `9px` backdrop blur; black fallback where blur is unavailable |
| All dialog text | Consolas, then the monospace fallbacks from section 2.2; Regular `400` or Bold `700` only |
| Dialog and warning title | `24px/29px`, Bold, primary white |
| Discovery heading | `16px/20px`, Bold, primary white |
| Warning question identifying target/version | `18px/27px`, Regular |
| Metadata, explanation, links, status and button labels | `14px/22px`; metadata values and machine state Bold, labels Regular |
| Tracking and corners | `letter-spacing: 0`; `border-radius: 0` |

The cyan link hue sampled in the historical raster is an example accent;
links MUST use the application's configured accent. Raster title-glyph shapes
do not override the font-role rules: a dialog title uses the interface font,
not the display font reserved for service/page names. Raster subpixel fringes
and outer dark capture matte are not additional palette tokens.

An application with an explicitly approved alternative visual identity maps
these semantic roles to its documented theme. It retains the same information
order, target identity, backup gate, action semantics, progress and recovery.
Theme adaptation is not permission to omit a screen or introduce a second
update experience. Its theme mapping and visual fixtures belong in its local
documentation; this universal Part does not enumerate product exceptions.

#### 10.8.2 Geometry And Spacing Ledger

All CSS measurements use border-box. Coordinates below are relative to the
outer dialog border after removing screenshot crop/matte. Allow `1px` raster
rounding; do not reproduce differences in crop origin as separate layouts.

| Element | Canonical desktop measurement |
| --- | --- |
| Entry button | `326x40px`; centered label, `1px` structural border |
| Main overlay | Approximately `760px` wide with a `1px` outer white border; height grows for discovery, job and recovery content (current status export `766x752px`) |
| Header | `55px` high including lower `1px` nested divider; title inset `20px` inline |
| Close button | `40x40px`, approximately `12px` from the inner right edge and `7px` from the header top; centered cross |
| Body | `24px` padding on all sides; content starts at local `x=25px` after the outer border |
| Metadata grid | `140px minmax(0, 1fr)`, `16px` column gap, `5px` row gap and `22px` line height |
| Discovery panel | `710px` reference width, `203px` minimum height; local `x=25px, y=191px`; nested `1px` outline |
| Discovery panel spacing | `36px 18px 18px` padding; heading-to-summary gap `14px`; subsequent text/link groups separated by `12px` |
| Gap before Discovery | Approximately `36px` after the three-row metadata group; additional real metadata expands normal flow |
| Discovery action row | `18px` below the panel, aligned right; `12px` between buttons |
| Check-again / install buttons | `40px` high with `18px` inline padding; example widths about `122px` / `146px`, content-sized for the real version |
| Job panel | Full `710px` content width, `38px` after the action row, `18px` padding; same metadata grid |
| Job message | `18px` after the metadata rows; wraps in `14px/22px` text |
| Required progress track | `6px` high, full available width, `12px` block margins, square ends |
| Rollback action | Disclosure or action below the retained job; show only when the authoritative job permits recovery |
| Warning dialog | `620px` wide, baseline `268px` minimum height; content height grows for save/error states |
| Warning header/body | Same `55px` header and `40px` close button; `24px` body padding |
| Warning content | Question, `12px` gap, explanation, `16px` gap, right-aligned actions; `12px` action gap |
| Warning buttons | `40px` high, `18px` inline padding; baseline widths about `85px` cancel and `230px` consequential action |

The retained job card grows for its progress track, measured-value label, long
messages and recovery input. A former fixed height is not a clipping boundary.
The Discovery baseline assumes one summary line, two explanation lines and one
release-notes link. Additional content grows its panel in normal flow.

The entry-button crop does not fix every Settings card's action width. A
documented full-width parent-card variant stretches that same `40px` button
without changing its typography, border, states or behavior.

Use the shared hover/focus/pressed treatment from section 3.1: `160ms`
hover/focus transitions, a non-layout focus outline and `60ms`
`scale(.985)` press feedback. Reserve space for the transform so adjacent
buttons and focus rings do not collide. Disabled/pending controls remain at
their original size and `0.45` opacity; a nearby explanation names the reason.
Danger controls retain their danger meaning during interaction.

#### 10.8.3 Composition And Responsive Interaction

The main dialog always reads in this order:

1. `Updates` title, component identity where needed, and Close.
2. Installed version, local update-helper reachability/version and registry
   reachability as separate observations. The target component's installed
   version MUST NOT be replaced by the helper's version.
3. Bordered `Discovery` panel: result, concise compatibility/provenance
   explanation, and an approved `Release notes` link when available.
4. Right-aligned `Check again` and conditional `Install <version>`.
5. Bordered job panel, only when a job exists for this component: `Job`,
   `State`, message, progress and any permitted recovery action.

Technical provenance detail belongs in a secondary details area when needed;
do not fill the primary workflow with internal paths, tokens or commands.
Long versions/job IDs wrap within the value column without moving the close
control or creating page-level horizontal scrolling.

The dialog opens centered. Width is `min(760px, calc(100vw - 16px))`;
height is `min(702px, calc(100dvh - 16px))`, with a `100vh` fallback.
Keep the header visible and make the body the vertical scroll owner. The
warning uses `min(620px, calc(100vw - 16px))` and viewport-bounded auto height.
Do not collapse the main dialog just because there is no update/job.

At `600px` viewport width and below, body padding becomes `16px`, metadata
uses `120px minmax(0, 1fr)` with a `12px` gap, and action rows wrap before
collision. At `420px` and below, metadata becomes labeled single-column
pairs with `4px` label/value and `12px` pair gaps; actions stack at full
width in the same reading order. Controls remain at least `40px` high and
expand to `44px` touch targets on coarse-pointer devices. Text wraps and
controls grow vertically when necessary; font sizes do not shrink to fit.

Only the topmost dialog owns focus. Opening the backup warning makes the
underlying update dialog inert; cancel returns to discovery with the chosen
candidate intact. Escape or Close before submission cancels the local flow,
not an already accepted host operation. Closing a running job view keeps the
job alive and leaves a visible Settings entry for reopening its progress.
Backdrop clicks MUST NOT discard a pending save or submission. Reopen, reload,
resize and a virtual keyboard must keep the close control reachable and
recover status without moving keyboard focus on every poll.

#### 10.8.4 Entry Button Reference

![Updates card with discovery action](<./src/example - settings - updates/example - settings - updates - ok.png>)

The current card shows the installed application version, local Updater and
Kernel Register reachability, and the application's **Check for updates**
action. Activation opens the dialog and starts discovery once. It never
installs a release. Shared-agent version controls are absent from this card.

#### 10.8.5 Available Release Reference

![Update dialog with an available release and retained job](<./src/example - settings - updates/example - settings - updates - overlay - status.png>)

Preserve the metadata/Discovery/actions hierarchy. The reference also shows
a retained completed job; omit that group when no job exists. `Check again`
performs a new check; `Install <version>` identifies the exact selected candidate and opens
the warning for an application update. Example identities and versions are
replaced by actual data.

#### 10.8.6 Backup Warning Reference

![Mandatory saved-backup warning before an application update](<./src/example - settings - updates/example - settings - updates - overlay - backup overlay.png>)

The reference export is `627x275px`. Preserve the prominent target/version
question, explanation, neutral Cancel and consequential action. Use
`Install <application> update` as a generic title pattern;
capitalization follows the actual display name.

`Create backup and install` is explicit consent to the named target and starts
one sequence: create the full ZIP, send it to the browser, then submit the update.
With a native save API, wait for the write and close to succeed. With an ordinary
browser download, start the download and continue automatically without a second
checkbox, file selection or Install action. A download request does not prove
that the operator retained the file; the UI must not claim that it does.
The native save picker remains native. Show `Creating backup...`,
`Saving backup...` or the actual failure as appropriate. These states expand
the warning in normal flow and never squeeze its text into the baseline height.

#### 10.8.7 Running Job Reference

The [current status overlay](<./src/example - settings - updates/example - settings - updates - overlay - status.png>)
establishes the retained job group's layout. During a running job, show the
actual job state, the saved-copy recovery explanation and the progress track:

- Use measured progress only when a valid total is available; otherwise show an
  indeterminate track and the current phase in text.
- Disable check/install mutations during the accepted operation; retain target
  information. A second click cannot start another update.
- Show or enable rollback only when the authoritative job allows it and the
  current operation has reached a safe terminal/recovery boundary.

An indeterminate track uses accent and no fabricated numeric percentage.
The remaining track uses `--white-80`; determinate fill uses accent, the bounded
measured ratio and a visible unit/total.
Reduced motion stops travel animation while retaining the track and explicit
pending text. The progress element has an accessible name and omits
`aria-valuenow` when the total is unknown. State changes use a polite live
region; actionable errors are announced once without reading every poll aloud.

#### 10.8.8 Completed Job And Recheck Reference

![Update dialog after a completed installation and fresh version check](<./src/example - settings - updates/example - settings - updates - overlay - status.png>)

The installed row shows the verified running version, the completed job remains
inspectable, and a fresh check determines whether another candidate exists.
`No newer compatible release` is shown only if that check succeeds with no
candidate. A newer intervening release may produce another install offer.

Keep completion and discovery outcomes separate. A failed recheck does not
turn the completed installation into a failed job. A failed or rolled-back job
never receives green success treatment just because its progress mode is
`complete` or its numeric ratio is `1/1`. A retained rollback action requires
the original saved ZIP and the current server authorization.

#### 10.8.9 Initially Up-To-Date Reference

The no-update state uses the same Discovery group as the
[status overlay](<./src/example - settings - updates/example - settings - updates - overlay - status.png>).
Only `Check again` remains in the action row. If no job exists, omit the entire
job/progress/rollback card;
do not fabricate a completed operation or show an empty bordered placeholder.
An offline, unauthorized, incompatible or failed check is a separate outcome,
never this no-update state.

#### 10.8.10 Visual And Interaction Acceptance

Capture entry, available, warning, running, completed and up-to-date states,
plus checking, cancelled/failed save, expired receipt, determinate/indeterminate progress,
reconnecting, rejected install, rollback success and rollback failure.
Compare at `1919x1034` and `1920x1080`, then `600px`, `420px`,
`360px`, a short `640x360` viewport, 200% zoom and a coarse pointer.

At desktop, compare both the full shell and a crop aligned to the dialog
border. Assert the ledger's geometry within `1px` rather than matching export
matte or subpixel font colors. Mask only variable data and explicitly identified
historical deltas, not incorrect padding, fonts, controls or missing progress.
Exercise keyboard focus/return, Escape, native picker cancellation, reduced
motion, long names/versions/errors and reopening an active job. Verify the
separate shared-component release flow through the root TUI.
The functional gate is
[Part 06 section 39.1](./PART_06_UNIFIED_ACCEPTANCE_CHECKLIST.md#391-universal-update-workflow-acceptance).

### 10.9 Service Initialization Overlays

The applicable `Initialize` actions in the automatic-backup group use one
overlay family. Gryphon Connection uses the adapter-selection overlay described
in section 10.5.5; Wyverne Connection uses the Adapter-choice overlay in
section 10.5.6. Their installation and enrollment instructions lead to the
root TUI. This is a specification for
states absent from the static card PNGs; its visual basis is the update warning
and running-job panels in section 10.8. It does not introduce another theme.
Component-specific fields and postconditions are defined in
[Part 10 section 8](./PART_10_SERVICE_AGENTS_UI_AND_OPERATOR_WORKFLOWS.md#8-initialize-overlay-workflow).

#### 10.9.1 Geometry And Field Layout

| Element | Required value |
| --- | --- |
| Form dialog | `620px` desktop width, `268px` minimum height, auto content height |
| Viewport bound | Width `min(620px, calc(100vw - 16px))`; max-height `calc(100dvh - 16px)` with `100vh` fallback |
| Header | `55px` including `1px` divider; title `20px` from left |
| Title | `Initialize <component>`, `24px/29px` Consolas Bold, primary white |
| Close | `40x40px`, approximately `12px` right and `7px` top inset; accessible `Close initialization` name |
| Body | `24px` padding; `20px` between semantic form groups |
| Labels | `14px/22px` Consolas Bold; `8px` before their control |
| Input/select | Full content width, `40px` minimum height, `12px` inline padding, `14px/22px` Consolas Regular |
| Help/error | `14px/22px`, `8px` after the control; secondary white/help or danger/error |
| Footer | `24px` above actions, right-aligned, `12px` gap; neutral Cancel then Initialize |
| Action | `40px` minimum height, `18px` inline padding, content width; at least `112px` for Initialize |
| Status panel | `1px` nested outline, `18px` padding, `24px` separation from form/context |
| Status metadata | `140px minmax(0,1fr)`, `16px` column gap, `5px` row gap |
| Progress | Same `6px` track, `12px` block margins and measured/indeterminate rules as updates |

Use true black, white, nested `#CCCCCC`, configured accent, `#62FF8C`
success and `#F83D3D` danger. Borders are `1px`, corners square.
Initialize is a normal outlined action, not a red destructive button; unlink,
revocation and destructive repair use danger with consequence text.
Hover/focus/pending, reduced motion and approved theme mappings are inherited
from sections 3.1 and 10.8, including `0.45` disabled-control opacity.

Header remains visible; the body is the scroll owner for long forms, jobs and
errors. At `600px` and below use `16px` body padding. At `420px` and below
stack footer actions at full width and metadata as labeled pairs. Coarse
pointers receive `44px` targets. Never shrink text or hide a required action
to fit the baseline height.

#### 10.9.2 Open, Input And Validation

Clicking Initialize opens and centers the dialog and performs only read-only
preflight. Show component, owning service, install/reuse intent and any shared
impact. Opening, selecting a field, pressing Escape or closing before explicit
submission must not install, enroll, bind, save a secret or enable scheduling.

Use the smallest fields needed for the scoped operation. Non-secret service
identity/profile is resolved server-side and displayed read-only. A backup
setup code is an empty masked input; the protocol's length/expiry applies to
that code only, not to the application's Access Key. Other component forms
must not display a fake setup-code field merely to match its geometry.

Sensitive values start empty, are never prefilled from a read API, and are
excluded from URLs, browser persistence, diagnostics and analytics. Use
`autocomplete="off"`, disable spellcheck and autocapitalization for opaque
codes, and treat paste as input data. A keyboard-operable temporary reveal
control may be used without changing field width. The clear action follows
the shared input contract. Provider and adapter tokens do not belong in ordinary
consumer initialization forms.

Required/invalid fields show an inline explanation associated with the control.
Focus the first invalid field after submission; do not expose a raw transport
body. Missing permission, unavailable installer, expired code, incompatible
agent, profile mismatch and no allowed Adapter are distinct conditions.
Disable only affected actions and preserve non-secret input on a retry.

#### 10.9.3 Submit, Progress And Result

Explicit Initialize validates the selected scope and submits one typed action
with a stable request ID. Prevent double clicks and Enter/submit duplication.
Accepted work changes the form to observation: lock configuration fields,
replace Cancel with Close, keep the target context and show Job, State,
message and progress in the update-style panel. Do not fabricate a job before
the server accepts it; show `Submitting...` while acknowledgement is pending.

Install, reuse, enrollment and verification are separate observable phases.
Display backend-reported state, mapping it to explanatory UI text where useful;
phase ordinals are not measured percentages. Successful submission or socket
reachability alone is not initialization success.

Closing the active dialog does not cancel the host job. Keep a visible
`Initialization in progress`/`View progress` entry in the originating
card. Reopen/reload/authenticated reconnect finds the same request/job;
an uncertain acknowledgement is resolved before any retry. Do not restore
secret fields from persistence. Cancelled preflight/save, terminal outcomes
and teardown clear transient sensitive input.

On verified completion, refresh the card's component health, service
registration and expected functional/profile state. Show a stable success
result with an explicit Done/Close action rather than auto-dismissing it.
For backup initialization this unlocks schedule editing; it does not enable
automatic backup or run a backup by itself. For a gateway it enables the
next separately authorized binding step.

On failure, keep the dialog open with the stage, sanitized cause and a safe
retry or repair action. If the shared agent was installed but enrollment
failed, show that partial state and reuse the installation on retry; never
delete another consumer's configuration. Repair declares the intended profile
and affected scope before confirmation. A terminal result does not require the
browser to remain open for execution.

Only the topmost dialog traps focus. On close, return focus to its actual
invoker (or the corresponding card action if the card was re-rendered).
Backdrop clicks cannot discard a populated sensitive form or pretend to
cancel an accepted operation. Keyboard, screen-reader announcements, stale
state, reduced motion and error recovery follow the update-dialog contract.


## 11. Saturn Shared Link: An Operator-Requested Interface Case Study

### 11.1 Private Case And Mandatory Operator Authorization

**This is a private, operator-requested case. Similar changes MUST be made
only in response to a direct, explicit request from the operator for the
affected interface.** A designer, developer or automated agent MUST NOT use
this example as standing permission to redesign other system elements.

The operator requested this comparison on 2026-10-05 as a substantial example
that a programmer and designer can study together. The operator explicitly
restricted its application to directly requested changes. Requesting this
documentation does not authorize implementation changes elsewhere.

This section describes Saturn's actual and legacy public shared-link layouts
and explains the design reasoning that can inform a separately authorized
change. It is not a replacement for sections 1-10, a new system-wide theme or
a mandate to convert other services to the current Saturn appearance.

In particular, the current shared-link page uses a light palette, tinted file
categories, body typography and shadows that depart from the operational
interface defined earlier in this Part. Those differences are recorded here
as observations of this particular implementation. They do not become general
exceptions to the black surface, five-hue palette, font roles or no-shadow
rules. The material-divergence protocol still applies to other affected
interfaces; an operator request for one page does not authorize another page.

Before using this case to change another element, record the direct operator
request, the named screen/component, intended audience, permitted differences
and acceptance conditions. A broad request to improve code, unify components,
fix a bug or follow this document MUST NOT be interpreted as an implicit
request for this visual redesign. Without that request, preserve the existing
interface and applicable standard.

### 11.2 What Is Being Compared

The comparison concerns the **recipient's public shared-link page**, not the
owner's authenticated Shared management screen. A recipient arrives through
one link to view, browse or download the content that its owner allowed.
That task differs from creating links, editing permissions or operating the
storage service.

In the inspected Saturn implementation both presentations are available:

| Presentation | Route shape | Implementation |
| --- | --- | --- |
| Current/default | `/s/<token>` | `PublicShareView`, `.share-public-view--client` and `.share-client-*` |
| Preserved legacy | `/s/<token>?legacy=1` | The `legacyMode` branch of `PublicShareView`, `.share-public-*`, `.share-browser-*` and `.share-password-*` |

`legacy=1` selects a presentation branch for the same shared-link capability.
It is not a different permission level, data store or authentication mechanism.
It is also unrelated to the separate migration of old hash-only share tokens
in Saturn's owner interface. Removing the query selects the current layout;
changing it cannot unlock a protected link or grant download permission.

The source observations below were checked on 2026-10-05 against:

- [PublicShareView and its shared interaction handlers](../saturn/apps/web/src/app.tsx);
- [legacy and current layout styles](../saturn/apps/web/src/styles.css);
- [public metadata, unlock, content, package and thumbnail client calls](../saturn/apps/web/src/api.ts);
- [public-share API and response handling](../saturn/apps/api/src/share.controller.ts);
- [server authorization and thumbnail-source scoping](../saturn/packages/shares/src/share.service.ts);
- [thumbnail rendering and cache](../saturn/packages/shares/src/thumbnail.service.ts);
- [layout and permission regression cases](../saturn/apps/web/src/app.test.tsx).

These are implementation references in the integration workspace, not public
links for recipients. Product-specific routes, labels and CSS names illustrate
the case; another service retains its own domain language and public API.

### 11.3 Comparable Visual Evidence

The following captures use the same synthetic six-item folder, permissions,
expiration date, configured blue accent and browser environment. Desktop
captures are `1919x1034`; the mobile capture uses a `390px` viewport. Names,
sizes, dates and image/PDF/video preview graphics are fixtures, not real
operator data. The preview graphics stand in for generated thumbnails.

**These screenshots are illustrative case-study evidence, not additional
normative templates under section 1.1.** They establish what changed in the
observed implementation. Their incidental pixels and sample values MUST NOT
be treated as new global design tokens.

| State | Legacy | Current |
| --- | --- | --- |
| Opened shared folder | ![Legacy opened share: centered dark panel and a compact file table](./src/saturn-shared-case-study/legacy-opened.png) | ![Current opened share: content heading, primary action and thumbnail grid](./src/saturn-shared-case-study/current-opened.png) |
| Password-protected link | ![Legacy password gate: compact password form and service reachability](./src/saturn-shared-case-study/legacy-locked.png) | ![Current password gate: Saturn wordmark, protection explanation and Continue action](./src/saturn-shared-case-study/current-locked.png) |

The [current mobile capture](./src/saturn-shared-case-study/current-mobile.png)
shows the same content in a single column. Both opened desktop captures contain
the same six items: the legacy table requires internal scrolling to reveal
the final row, while the current page gives each item a visual tile and grows
in normal page flow. This is a layout tradeoff, not evidence of different data.

### 11.4 The Change In Reading And Decision Order

The legacy page places the service presentation first. Its large heading is
`saturn shared link`. Inside a compact outer frame the reader encounters a
Gateway mode notice and browser-copy limitation, then expiration and service
reachability, then the file table and the full-width bulk action at the bottom.

The current page separates service identity from content identity. A compact
top bar identifies Saturn and summarizes access. The main heading names the
actual shared object, such as `Project materials`; item count and total size
provide context, and the main allowed action appears beside that heading.
The content collection follows immediately. The browser-copy explanation is
still available under `About access` after the collection.

```text
Legacy opened page                 Current opened page

Large generic service heading      Compact brand + access + expiry
Outer framed panel                 Actual shared object name + summary
  Gateway notice                   Primary allowed action beside heading
  Browser-copy explanation         Navigation/sorting toolbar
  Expiry + service reachability     File/folder tiles with visual identity
  Fixed-height file table          Secondary access explanation
  Bulk action below the table      Small service attribution
```

This arrangement lets a recipient answer four questions in order: What was
shared? What may I do? Which item do I need? How do I act on it? The service
remains identifiable without consuming the main content heading.

The intended benefit is a clearer first encounter for an occasional recipient.
This is a design interpretation supported by the composition; it is not a
measured claim about conversion, usability-test results or task completion
time. The dense legacy table can still be useful for repeated name/size
comparison. A separately requested redesign must choose according to its
actual audience and task rather than assume that tiles always improve a table.

### 11.5 Difference Ledger And Transfer Reasoning

The final column is a design question for a **separately and directly
operator-requested** change. It is not permission to apply that change now.

| Area | Legacy implementation | Current implementation | Reasoning to consider in an authorized change |
| --- | --- | --- | --- |
| Page identity | Generic large `saturn shared link` heading | Small service brand; actual file/folder name is the main heading | Give the user's object the main semantic heading; keep service identity in a separate role. |
| Layout model | Centered composition, approximately `684px` wide, containing one strongly outlined panel | Full-page shell with a sticky top bar and a centered content region capped at `1380px` | Choose the working width from the content task; avoid inheriting an authentication-panel width for a collection. |
| Information order | Gateway explanation precedes the collection | Object summary and primary action precede the collection; longer explanation follows it | Separate information needed to act from supporting detail while preserving access-critical information. |
| Primary command | Large outlined action below the table, with byte size inside its label | Filled action beside the object heading; size is separate metadata | Separate the command verb from a changing value and keep the command close to its scope. |
| Permission language | `View only Gateway`, `Browse Gateway`, `Download only Gateway` | `View only`, `Browse only`, `Download allowed` | Express what the recipient may do without requiring knowledge of internal infrastructure. |
| Expiration language | `Shared link expires:` and a date or `none` | `Available until …` or `No expiration` in the desktop top bar | Use a reader-oriented sentence for the same backend fact; avoid ambiguous missing-value language. |
| Collection form | Compact Name/Size/action table inside a `262px` scroll area | Responsive grid of independent file/folder articles | Tiles favor recognition and visual media; tables favor dense comparison. Neither is universally preferred. |
| File recognition | File name and size; no visual preview | Type icon plus name/size; images, PDFs and videos can show a thumbnail | Add visual recognition when it helps choose content; retain a useful fallback for other types or failures. |
| Per-item command | Small arrow icon for Open or Download | Explicit `Open` or `Download` text link | Name actions visibly when symbols may be unfamiliar; retain a resource-specific accessible name. |
| Folder navigation | Clickable folder name and a Back action above the table | Clickable folder visual area and Back in the collection toolbar | Make navigation targets distinct from file downloads; do not imply that every tile has the same click behavior. |
| Service status | A persistent framed `Service Reachability` label and colored square in both locked/opened layouts | Healthy reachability is quiet; degraded health produces a contextual service message | Show an operational condition when it affects the recipient's next step; do not confuse health with access authorization. |
| Password gate | Small technical form with `Please enter shared link password:`, a placeholder and `Enter` | Branded gate with a lock illustration, protection heading, sender-password explanation, visible label and `Continue` | Explain the situation and where the required input comes from before asking for it. |
| Visual hierarchy | Black/white/accent, strong nested frames and monospace content | Warm light surface, dark ink, restrained separators, filled primary action and visual tiles | Hierarchy can be expressed through role, size, spacing and contrast; the specific palette change remains private to this case. |
| Supporting explanation | Full browser-copy warning always occupies the first panel | `About access` disclosure after the collection | Move secondary explanation without concealing the current permission or promising technical restrictions that do not exist. |
| Attribution | The large generic title carries the service identity | Compact brand at the top and `Shared via Saturn` at the bottom | Keep attribution proportionate to its purpose; do not add a marketing hero to a working page. |

### 11.6 Opened State: Component Anatomy And Actual Behavior

The current opened page has five layers. They are compositional roles rather
than another service's required CSS component names.

1. **Service and access bar.** The sticky dark bar contains the Saturn planet
   and wordmark, the access label and, on desktop, the expiration sentence.
   It introduces the service without an owner sidebar, Settings controls or
   privileged navigation. Neither current nor legacy public layouts include
   the owner's authenticated shell.
2. **Object heading and primary action.** A small `Shared folder`/`Shared file`
   qualifier precedes the resource name. The summary and action form one
   meaningful group; the action is derived from resource type and permission.
3. **Collection toolbar.** The left side describes the collection or provides
   Back when inside a folder. Name and Size sorting stay on the right on
   desktop and reflow on a narrow screen. The handlers and sort state are
   shared with legacy; sorting is not a new permission or backend feature.
4. **File/folder collection.** Each article has a visual area, a metadata area
   and an allowed file action. An unsupported preview retains the type icon.
   A failed thumbnail is hidden while the icon, name, size and action remain.
5. **Secondary detail and feedback.** `About access`, contextual errors and a
   small footer follow the collection. A service failure is also shown before
   the toolbar when the reachability check reports degradation.

The current tile is not a universal clickable card. A folder's visual area is
a button that enters that folder. A file's thumbnail is passive; the explicit
Open/Download link performs its action. Hover can highlight an article even
when its surface itself is not a click target. A derivative implementation
must specify hit areas honestly instead of making a visual hover imply an
unimplemented preview, modal or download.

The permission-to-action mapping in the normal valid modes is:

| Resource/mode | Recipient wording | Main command | Item actions |
| --- | --- | --- | --- |
| File / `view` | `View only` | `Open file` | `Open`; server inline-content policy still applies |
| File / `download` | `Download allowed` | `Download` | `Download` |
| Folder / `download_folder` | `Download allowed` | `Download all`, temporarily `Preparing…` while preparing the package | Folder navigation and permitted child-file downloads |
| Folder / `browse` | `Browse only` | Disabled `Download unavailable` | Folder navigation and permitted thumbnails; original-file download links are absent |

`Download all` prepares the server package before starting its download.
The new layout does not replace this process with a cosmetic link or make
client-side ZIP generation an assumed requirement. Failed preparation reports
that the package could not be prepared within its limits.

In the inspected implementation the main heading, bulk byte summary and folder
package action remain scoped to the shared root. The item count reflects the
currently listed entries. A nested-folder view has Back but no full textual
breadcrumb, and the bulk package does not become a package of only that nested
folder. Those details must be understood before using the example to design
scope labels in another interface.

### 11.7 Protected State: Explain Before Requesting Input

The legacy protected composition is approximately `255px` wide. Its outlined
password form is `170px` high in the normal state, with an absolutely positioned
prompt, a `28px` input and a `35px` Enter button. A service-reachability block
is always placed beneath it. The input has an accessible label, but that label
is visually hidden; the visible explanation is the compact prompt.

The current protected composition uses a shell capped at `480px`. The Saturn
wordmark is centered above a distinct light card. Inside the card a small lock
illustration and `Private shared link` qualifier introduce the state, followed
by `This link is protected` and an explanation to enter the password provided
by the sender. The form has a visible Password label, an input and a full-width
Continue button. Input and button are at least `46px` high in this implementation.

The form uses normal document flow: additional explanation and an error can
occupy their own space. This avoids coupling every message to a fixed absolute
vertical coordinate. The reading sequence is:

```text
Service identity
Reason for the gate
Where the required password comes from
Visible input label and field
Continue / Checking…
Local error, if present
Small service attribution
```

Both layouts use the same password-unlock handler and the link password,
not the owner's Access Key. The field is masked; submission becomes pending;
the handler clears the entered password after either success or rejection.
A rejected password and a rate-limit response have different messages.
Successful unlock loads the allowed folder content through the same public
capability. The illustration and wording improve explanation; they do not add
a security mechanism or prove a new encryption guarantee.

The form's behavior remains part of the acceptance contract even when its
appearance changes: visible labels supplement placeholders, pending state
prevents duplicate submission, errors are associated with the current task,
and a user can submit with the keyboard. Never replace server rate limiting
or password validation with a visual lock state.

### 11.8 Private Visual Vocabulary And Concrete Measurements

These values describe the current Saturn implementation, not mandatory tokens
for other elements. They are supplied so a designer and programmer can discuss
actual relationships rather than use vague terms such as “more modern”.

| Role | Legacy | Current case |
| --- | --- | --- |
| Page surface | `#000000` | `--share-client-bg: #f3f1eb` |
| Panel/tile surface | Black within strong white frames | `--share-client-panel: #fffef9` |
| Main text | White | `--share-client-ink: #171714` |
| Secondary text | 80%-white | `--share-client-muted: #6d6b63` |
| Neutral separators | White or nested `#CCCCCC` | `--share-client-line: #d8d4c9` |
| Soft interaction surface | `#111111` | `--share-client-soft: #eae6dc` |
| Accent | Configured accent directly | Local dark-on-light blend: 48% configured accent and 52% dark ink; the dark top bar uses a lighter accent blend |
| Body and controls | Primarily Consolas | Space Grotesk for most text and controls; Consolas retained for compact size/count metadata |
| Heading | Generic service heading up to `80px` | Object heading `clamp(38px, 5vw, 64px)`; separate `25px` desktop brand |
| Opened layout | `684px` maximum composition; `583px` minimum panel height | `1380px` maximum content region, `48px` top inset, `20-64px` responsive horizontal inset |
| Collection | `262px` internal table viewport | `auto-fill` grid with `230px` minimum tracks and `16px` gaps; a single item has a bounded `260-420px` track on desktop |
| Visual area | No thumbnail region | `148px` desktop visual height; type icons are `58px`; thumbnails fill the reserved area |
| Main action | Outlined full-width control at panel bottom | Filled dark control, at least `154px` wide and `46px` high |
| Protected composition | `255px` shell; compact fixed-position form | `480px` shell; card padding approximately `42px`; normal-flow form |
| Tile emphasis | Table/name/icon control states | Accent border, `translateY(-2px)` and a small shadow on hover/focus-within |

The current design retains rectangular surfaces and thin borders, but uses
fewer enclosing frames. It also introduces category-specific muted tints for
folders, images, video, audio, PDF and archives. A PDF tint is a type cue, not
an error state; greenish image tint is not proof that a file is safe. Error
messages remain explicit text. Media pixels naturally retain their own colors.

The current card shadows, pastel category hues, negative display letter
spacing and expanded Space Grotesk roles depart from earlier sections of this
Part. They must stay explicit in any authorized design brief. Copying only the
colors would miss the information hierarchy; copying the whole CSS would also
copy local exceptions and dimensions without proving that they suit the next
task. No automatic replacement of global theme variables is authorized here.

### 11.9 Added Preview Capability And Preserved Security Boundary

The redesign includes a genuine capability addition: the current collection
can request image, PDF and video thumbnails. Legacy does not render those
requests. Production thumbnail generation is separate from the synthetic
preview graphics in section 11.3: it generates bounded WebP images, caches
them by content identity and keeps a type-icon fallback when rendering fails
or a source is unsupported or too large.

Preview delivery is a data-access surface. The thumbnail service obtains the
source through shared-link authorization before returning cached or generated
output. It checks the resource belongs to the file capability or lies within
the allowed shared folder. A browse-only link can receive the permitted
thumbnail without receiving permission to download the original file; preview
access is not counted as an original-file download claim.

An authorized derivative that adds previews must therefore include backend
permission checks, revocation/expiration behavior, size and generation-time
limits, safe media rendering and cache isolation. A public object-store URL
or previously cached bitmap must not bypass authorization. A visual preview
can disclose content, so its allowed information must be part of the requested
scope rather than assumed to be harmless decoration.

Other core contracts are shared by both layouts: the capability token,
password session, allowed subtree, mode restrictions, expiry, revocation,
classification checks, limits and content/package endpoints remain server
responsibilities. The current page changes how those facts are presented;
it does not authorize clients to enforce them on their own.

`View only` still cannot guarantee that pixels or bytes already delivered to
a browser cannot be copied. The explanation survives under About access.
Neither the wording, hiding Download nor switching to legacy may be marketed
as impossible-copy protection. The footer's secure-sharing attribution must
not be read as a new end-to-end encryption promise.

### 11.10 Responsive Behavior And Limits Of The Observed Version

At `720px` and below, the current header becomes more compact, the object
heading and primary action stack, the action uses full width, toolbar groups
stack and the tile collection becomes one column. Tile visuals become `132px`
high; the protected card uses smaller padding. The layout grows through page
scrolling rather than retaining the legacy table's fixed-height inner viewport.

The useful relationship is preserved reading/action order with different
space allocation. It is not a requirement to shrink a desktop screenshot
uniformly. Another authorized interface should select breakpoints from its
content, not copy `720px` or a tile width without measurement.

The current implementation also has limits which are **not** recommendations:

- The expiration sentence is hidden on mobile by CSS, without an alternative
  expiry location on that page. An authorized derivative should preserve
  access-relevant expiry information in a compact visible location.
- A long tile name is ellipsized and supplied through a `title` attribute.
  That is not a complete touch or keyboard mechanism for reading the full
  name. Define an accessible full-name treatment when the task requires it.
- Folder navigation retains a root heading and Back instead of a complete
  breadcrumb. Specify object, current location and bulk-action scope clearly
  where deeper navigation makes them ambiguous.
- File thumbnails are not a click-to-preview interaction. Do not advertise
  one unless a corresponding action is implemented and authorized.
- The current small sort and per-file action targets need explicit keyboard,
  touch and focus review. A `46px` main button alone does not establish that
  every target satisfies the accessibility contract.
- Decorative hover transforms, shadows and color changes do not establish
  accessibility compliance. Reduced-motion behavior, visible focus, contrast,
  zoom, screen-reader names and error recovery require separate verification.
- The observed unavailable state says `404 / Shared link not found`; the
  comparison does not claim richer diagnostics for every server failure.
  Do not expose a confidential reason simply to make an error more detailed.

These observations keep the case honest: an appealing composition is not an
automatic acceptance certificate for every state. This documentation change
does not itself authorize correcting or redesigning those runtime details.

### 11.11 Joint Designer And Programmer Workflow For A Requested Change

Use this workflow only after the direct operator request described in 11.1.
The goal is to transfer the reasoning into a concrete, reviewable result,
with a named scope and verified behavior.

1. **Write the requested scope.** Identify the exact element and audience,
   record the operator's request and list accepted visual/behavioral changes.
   Determine whether the existing operator standard still applies or whether
   the request explicitly permits a private departure. Do not infer permission
   from the appearance of Saturn's public share page.
2. **Describe the user's task and existing constraints.** State the object,
   allowed next action, information needed to choose it and permission boundary.
   Measure useful density and repeated comparison needs before selecting a
   table, list, tile grid or form. Retain suitable existing structures.
3. **Prepare an information-order comparison.** Draw the old and proposed
   reading sequence. Identify which content moves, which remains visible and
   which becomes optional detail. Name the purpose of each change. Do not use
   adjectives such as “premium” as a substitute for those decisions.
4. **Define component roles and all relevant states.** Supply object heading,
   service identity, access summary, primary/local actions, content collection,
   gate, supporting detail and errors where applicable. For each control define
   hit area, label, pending/disabled behavior and keyboard action. Include empty,
   locked, loading, failed and unavailable states before acceptance.
5. **Specify the private visual contract.** Document palette, font roles,
   widths, spacing, media ratios, border hierarchy and emphasis as semantic
   tokens. List any approved departure from the central standard explicitly.
   Keep one screen's variables scoped to its root instead of changing every
   control in the service through broad selectors.
6. **Map behavior to the existing domain model.** Translate current permission
   states into truthful labels and actions. Reuse validated handlers where
   possible; implement a backend capability when a requested preview or other
   action needs one. Do not fabricate new data, infer hidden permissions or
   make a visual switch bypass authorization.
7. **Compare matching fixtures.** Render old/proposed states with the same
   names, counts, sizes, rights and error conditions. Include long names,
   missing previews, one item, many items and a nested location. A prettier
   fixture must not hide a lost action, omitted status or changed action scope.
8. **Verify and record the result.** Check the acceptance list below, record
   actual implementation limits and update the affected documentation. If a
   temporary legacy branch is retained, define its purpose and removal owner
   separately; this Saturn example does not mandate duplicate UIs forever.

The designer's handoff should contain the comparison, component/state layouts,
token roles, responsive changes and a clear account of permitted exceptions.
The programmer's handoff should contain the action/permission mapping,
data/API dependencies, preview fallback, state transitions and reproducible
verification. Both should share the same scope and labels.

### 11.12 Conditional Examples In Other System Elements

The following are discussion examples for a future direct request, not a
backlog, approval or instruction to change these elements now.

| If the operator explicitly requests a change to… | Reasoning that may transfer | Domain-specific boundary to retain |
| --- | --- | --- |
| A public document or media view | Let the actual document title lead; separate service branding, permission and a clear allowed action; preview content with an explicit fallback. | Document access, redaction, expiry and copy limitations remain server-controlled. |
| A recipient upload page | Explain the destination and accepted input before the form; keep upload state and errors next to the action. | Upload-only access does not grant browse/download; quotas, type/size policy and validation remain effective. |
| A requested connection form | Explain what is being connected, what value is required and where it comes from; distinguish test, pending and completed states. | Credential handling, validation and any separately required confirmation remain intact. |
| A report or restore-candidate view | Make the report/candidate the object heading; separate main action from supporting history and technical detail. | A consequential restore or apply action retains scope, evidence and the applicable confirmation requirements. |
| An operator collection | Clarify object/action hierarchy and command labels while preserving useful density. | The black operational theme and dense table may remain the correct contract; this case grants no light-theme or tile conversion. |

A domain-specific task can benefit from the reasoning without needing every
visual treatment in Saturn. Even that adaptation is implemented only within
the operator's explicitly requested scope.

### 11.13 Acceptance Checklist For An Authorized Derivative

- [ ] A direct operator request names the affected interface; this case study
      is not used as substitute authorization.
- [ ] Audience, task, permitted changes and any central-standard departure are
      documented before implementation.
- [ ] Actual object identity, current scope and allowed primary action are
      understandable without learning internal service terminology.
- [ ] Service branding, metadata, supporting explanation and task content have
      distinct roles; important permissions and expiry remain discoverable.
- [ ] Main/local action names map truthfully to resource type, mode and backend
      behavior, including pending, disabled and forbidden states.
- [ ] Navigation targets, passive media and download/open actions have explicit
      hit areas and do not rely on hover to imply behavior.
- [ ] Empty, loading, locked, rejected-input, rate-limit, media-failure and
      unavailable states are designed and verified where applicable.
- [ ] A preview addition has authorized source access, scope checks, fallback,
      resource budgets and cache behavior; hiding an original download does
      not silently broaden preview permission.
- [ ] Server authentication, authorization, expiry, revocation and limits pass
      unchanged or intentionally expanded domain tests; visual variants cannot
      bypass them.
- [ ] Matching old/new desktop and narrow fixtures demonstrate preserved useful
      content and actions, with long names, many items and nested locations.
- [ ] Keyboard, screen-reader names, focus visibility, contrast, target sizes,
      reduced motion and zoom are verified separately from screenshots.
- [ ] Product claims remain accurate; browser-delivered content is not promised
      to be impossible to copy, and decorative security cues imply no new guarantee.
- [ ] A documented private style remains scoped to the approved element.
      Unrequested screens and global tokens retain their applicable contract.
- [ ] Known implementation limits and any retained legacy presentation are
      recorded honestly; the example is not declared a universal replacement.

**Authorization boundary:** studying or referencing this section is permitted;
performing a similar redesign requires the operator's direct request for that
particular element. No automatic or proactive system-wide adoption is authorized.
