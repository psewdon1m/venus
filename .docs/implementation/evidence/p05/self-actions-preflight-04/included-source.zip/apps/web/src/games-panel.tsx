import {useCallback,useEffect,useRef,useState} from 'react';
import type {ActionConsentState,GameView,Locale,PairCondition,PairInvitation,PrivatePrompt,RoomView,SelfPreferences} from '@venus/contracts';
import {ApiError,SessionApi} from './api.js';
import {freshPreparation} from './game-setup.js';
import {gameCopy,gameError} from './game-copy.js';
import {scopePrivate,type PrivateState,type ChatView} from './private-state.js';
import {AuthBoundary,retryAllowed,type AuthToken,type RetryContext,type RetryKind,type RetryOperation,type RetryScope} from './game-operations.js';
import {acceptGame,gameFrame,privateCleared,terminalRound,validChat,validCondition,validGame} from './game-state.js';
import {OwnControls,type OwnAction} from './game-controls.js';
type Availability={available:boolean;requested_rounds:number;draft_rev:number;recheck_required_at_start:true};
type Grant=RetryContext['grants'][number];
const empty=():PrivateState=>({invitation:null,prompt:null,action:null,condition:null,chat:null});
const modes=['questions','truth_or_dare','yes_but'] as const;
function grants(data:PrivateState):Grant[] {
 const result:Grant[]=[],i=data.invitation,a=data.action,p=data.prompt,h=data.chat;
 if(i) result.push({kind:'invitation',offer:i.offer_id,proposal:i.proposal_revision,deadline:Date.parse(i.expires_at)});
 if(a) {const deadline=Math.min(Date.parse(a.expires_at),p?Date.parse(p.expires_at):Infinity);result.push({kind:'action',offer:a.offer_id,proposal:a.proposal_revision,deadline},{kind:'condition',offer:a.offer_id,proposal:a.proposal_revision,deadline});}
 if(p&&h) result.push({kind:'chat',offer:p.offer_id,proposal:p.proposal_revision,deadline:Math.min(Date.parse(p.expires_at),Date.parse(h.expires_at))});
 return result;
}
export function GamesPanel({api,room,prefs,locale,connection,frame,refreshRoom,onError}:{api:SessionApi;room:RoomView;prefs:SelfPreferences;locale:Locale;connection:'checking'|'ready'|'offline';frame:unknown;refreshRoom:()=>Promise<void>;onError:(error:unknown)=>void}) {
 const c=gameCopy(locale),base=`/api/v1/rooms/${room.room_id}/game`,host=room.members.some(m=>m.id===prefs.owner_member_id&&m.role==='host');
 const [boundary]=useState(()=>new AuthBoundary(room.room_id,prefs.owner_member_id,connection==='ready'));
 const authToken=boundary.bind(room.room_id,prefs.owner_member_id,connection==='ready');
 const [controls]=useState(()=>new OwnControls()),[,controlsChanged]=useState(0);
 const [gameRecord,setGame]=useState<{scope:AuthToken;value:GameView}|null>(null),[privateRecord,setPrivate]=useState<{scope:AuthToken;value:PrivateState}|null>(null),[availabilityRecord,setAvailability]=useState<{scope:AuthToken;session:string;value:Availability}|null>(null);
 const game=gameRecord&&boundary.sameIdentity(gameRecord.scope)?gameRecord.value:null,privateData=privateRecord&&boundary.sameTransport(privateRecord.scope)?privateRecord.value:empty();
 const incomingControl=gameFrame(frame,room.room_id),newControl=incomingControl&&frame&&typeof frame==='object'&&'room_rev' in frame&&typeof frame.room_rev==='number'&&frame.room_rev>=room.room_rev&&(!game||incomingControl.session_id!==game.session_id||incomingControl.game_rev>=game.game_rev)?incomingControl:game;
 controls.bind({auth:authToken,game:newControl,roomRev:room.room_rev,memberPresent:room.members.some(m=>m.id===prefs.owner_member_id)});
 if(privateCleared(frame,room.room_id,prefs.owner_member_id))controls.revokeRound(frame);
 const controlToken=controls.token();
 const availability=availabilityRecord&&boundary.sameIdentity(availabilityRecord.scope)&&availabilityRecord.session===game?.session_id&&availabilityRecord.value.draft_rev===game.game_rev?availabilityRecord.value:null;
 const [mode,setMode]=useState<GameView['mode']>('questions'),[rounds,setRounds]=useState(20),[players,setPlayers]=useState<string[]>(()=>room.members.map(m=>m.id));
 const [pending,setPending]=useState(false),[safetyPending,setSafetyPending]=useState(false),[error,setError]=useState(''),[retry,setRetry]=useState<number|null>(null),[condition,setCondition]=useState(''),[text,setText]=useState('');
 const gameRef=useRef<GameView|null>(null),epoch=useRef(0),operations=useRef(0),inFlight=useRef(false),alive=useRef(true),roomStream=useRef(-1),ordinaryLock=useRef(false),retired=useRef(new Set<string>());
 const privateRef=useRef<PrivateState>(empty()),vault=useRef(boundary.vault),gameScope=useRef<AuthToken|null>(null),privateScope=useRef<AuthToken|null>(null),wall=useRef(0);
 const scopeRef=useRef(''),onErrorRef=useRef(onError),refreshRef=useRef(refreshRoom),lockState=useRef<boolean|null>(null);
 useEffect(()=>{onErrorRef.current=onError;refreshRef.current=refreshRoom;},[onError,refreshRoom]);
 const publishPrivate=useCallback((value:PrivateState,token=boundary.current)=>{if(!boundary.sameTransport(token)) return;privateScope.current=token;privateRef.current=value;setPrivate({scope:token,value});const entry=boundary.vault.active;if(entry&&!['setup','public'].includes(entry.scope.kind)&&!retryAllowed(entry.scope,{...boundary.current,session:gameRef.current?.session_id??null,round:gameRef.current?.current_round?.round_id??null,grants:grants(value)},Math.max(wall.current,Date.now()))) {boundary.vault.clear();setRetry(null);}},[boundary,setRetry,setPrivate]);
 const clear=useCallback(()=>{epoch.current++;publishPrivate(empty());setText('');setCondition('');vault.current.clear();setRetry(null);},[publishPrivate,setText,setCondition,setRetry]);
 const update=useCallback((value:unknown,token:AuthToken)=>{
  if(!boundary.sameIdentity(token)||!validGame(value)) return false;
  const same=boundary.sameIdentity(gameScope.current);if(!same) {retired.current.clear();lockState.current=null;roomStream.current=-1;}if(retired.current.has(value.session_id)) return false;const old=same?gameRef.current:null,next=acceptGame(old,value);if(next===old&&old!==value) return false;
  if(old?.session_id!==value.session_id) {if(old) retired.current.add(old.session_id);clear();}
  gameRef.current=next;gameScope.current=token;controls.updateGame(next);if(next) setGame({scope:token,value:next});
  if(next) {const locked=['active','paused'].includes(next.state);if(lockState.current!==locked) {lockState.current=locked;void refreshRef.current().catch(e=>onErrorRef.current(e));}}
  return true;
 },[clear,boundary,controls,setGame]);
 const sync=useCallback(async()=>{
  if(inFlight.current||!alive.current||!boundary.sameTransport(authToken)) return;inFlight.current=true;let token=epoch.current;
  try {
   const current=await api.request<GameView>(base+'/current');if(!alive.current||token!==epoch.current||!boundary.sameTransport(authToken)) return;
   if(!validGame(current)) throw new ApiError('SERVICE_UNAVAILABLE');if(!update(current,authToken)) return;token=epoch.current;
   const ownToken=controls.token(),sequence=controls.begin(),started=Date.now();
   try {const own=await api.request(base+'/self-actions');if(alive.current&&token===epoch.current&&boundary.sameTransport(authToken)){controls.accept(own,ownToken,sequence,started,Date.now());controlsChanged(n=>n+1);}}catch { /* Display metadata failure retains only previously confirmed own safety attempts. */ }
   if(!alive.current||token!==epoch.current||!boundary.sameTransport(authToken))return;
   const round=current.current_round,newScope=`${authToken.identity}:${current.session_id}:${round?.round_id??''}:${current.game_rev}`;
   if(scopeRef.current!==newScope) {scopeRef.current=newScope;publishPrivate(empty());setText('');setCondition('');vault.current.clear();setRetry(null);}
   if(connection!=='ready'||current.state!=='active'||!round||terminalRound(current)) {publishPrivate(empty());return;}
   if(!alive.current||token!==epoch.current||!boundary.sameTransport(authToken)||gameRef.current?.session_id!==current.session_id||gameRef.current.game_rev!==current.game_rev) return;
   const target=`${base}/${current.session_id}/round/${round.round_id}`;
   async function optional<T>(suffix:string):Promise<T|null> {if(!alive.current||token!==epoch.current||!boundary.sameTransport(authToken)) return null;try {return await api.request<T>(target+'/'+suffix);} catch(e) {if(e instanceof ApiError&&['NOT_FOUND','CONSENT_NOT_ACTIVE','ACTION_CONSENT_UNAVAILABLE','GAME_NOT_ACTIVE','ROUND_STALE','CHAT_UNAVAILABLE','PRIVATE_CHAT_UNAVAILABLE','PRIVATE_CHAT_NOT_AVAILABLE'].includes(e.code)) return null;throw e;}}
   const [invitation,prompt,action,terms]=await Promise.all([optional<PairInvitation>('invitation'),round.kind==='generic'?optional<PrivatePrompt>('private'):Promise.resolve(null),optional<ActionConsentState>('action-consent'),current.mode==='yes_but'?optional<PairCondition>('condition'):Promise.resolve(null)]);
   let chat:ChatView|null=null;if(prompt&&room.meeting_context==='online'&&token===epoch.current&&boundary.sameTransport(authToken)) {try {chat=await optional<ChatView>('chat');} catch { /* Private text is never rerouted to the room. */ }}
   if(!alive.current||token!==epoch.current||!boundary.sameTransport(authToken)||gameRef.current?.session_id!==current.session_id||gameRef.current?.game_rev!==current.game_rev) return;
   const scoped=scopePrivate({invitation,prompt,action,condition:terms,chat},current.session_id,round.round_id,prefs.owner_member_id,Date.now());
   controls.observeRefusals([
    ...(scoped.invitation?[{kind:'invitation' as const,offer:scoped.invitation.offer_id,proposal:scoped.invitation.proposal_revision,expiresAt:Date.parse(scoped.invitation.expires_at),active:Boolean(scoped.prompt)}]:[]),
    ...(scoped.action?[{kind:'action' as const,offer:scoped.action.offer_id,proposal:scoped.action.proposal_revision,expiresAt:Date.parse(scoped.action.expires_at),active:scoped.action.state==='active'}]:[])
   ],ownToken,Date.now());
   publishPrivate(scoped,authToken);
  } catch(e) {if(alive.current&&token===epoch.current&&boundary.sameTransport(authToken)) {clear();if(!(e instanceof ApiError&&e.code==='GAME_NOT_FOUND')) setError(e instanceof ApiError?e.code:'SERVICE_UNAVAILABLE');if(e instanceof ApiError&&['ENTRY_REACCEPT_REQUIRED','AUTH_REQUIRED'].includes(e.code)) onErrorRef.current(e);}}
  finally {inFlight.current=false;}
 },[api,base,connection,room.meeting_context,update,clear,publishPrivate,setText,setCondition,setError,setRetry,prefs.owner_member_id,authToken,boundary,controls,controlsChanged]);
 useEffect(()=>{alive.current=true;const generation=epoch,operationCounter=operations,privateCache=privateRef,retryVault=vault.current;queueMicrotask(()=>{void sync();});const timer=setInterval(()=>{void sync();},1500);return()=>{alive.current=false;generation.current++;operationCounter.current++;retryVault.clear();privateCache.current=empty();clearInterval(timer);};},[sync]);
 useEffect(()=>{let live=true;queueMicrotask(()=>{if(!live) return;if(privateScope.current&&!boundary.sameTransport(privateScope.current)||connection!=='ready') clear();if(connection==='ready') void sync();});return()=>{live=false;};},[authToken,boundary,connection,clear,sync]);
 useEffect(()=>{let live=true;queueMicrotask(()=>{if(!live) return;
  if(privateCleared(frame,room.room_id,prefs.owner_member_id)) {clear();void sync();return;}
  const view=gameFrame(frame,room.room_id);if(view&&frame&&typeof frame==='object'&&'room_rev' in frame&&typeof frame.room_rev==='number'&&frame.room_rev>roomStream.current) {roomStream.current=frame.room_rev;const old=gameRef.current;if(old?.session_id!==view.session_id||old.game_rev!==view.game_rev) clear();update(view,authToken);void sync();}
 });return()=>{live=false;};},[frame,room.room_id,prefs.owner_member_id,clear,sync,update,authToken]);
 useEffect(()=>{const hide=()=>clear(),visibility=()=>{clear();if(document.visibilityState==='visible') void sync();};window.addEventListener('pagehide',hide);document.addEventListener('visibilitychange',visibility);return()=>{window.removeEventListener('pagehide',hide);document.removeEventListener('visibilitychange',visibility);};},[clear,sync]);
 const [clock,setClock]=useState(()=>Date.now());
 useEffect(()=>{const timer=setInterval(()=>{wall.current=Math.max(wall.current,Date.now());const now=wall.current;
  const entry=retry===null?null:vault.current.get(retry);if([privateRef.current.invitation,privateRef.current.prompt,privateRef.current.action,privateRef.current.chat].some(v=>v&&Date.parse(v.expires_at)<=now)||entry?.scope.deadline!==null&&entry?.scope.deadline!==undefined&&entry.scope.deadline<=now) clear();setClock(now);
 },500);return()=>clearInterval(timer);},[clear,retry]);
 useEffect(()=>{const entry=retry===null?null:vault.current.get(retry),deadlines=[privateData.invitation?.expires_at,privateData.prompt?.expires_at,privateData.action?.expires_at,privateData.chat?.expires_at].filter((d):d is string=>Boolean(d)).map(Date.parse);if(entry?.scope.deadline) deadlines.push(entry.scope.deadline);if(!deadlines.length) return;const wait=Math.max(0,Math.min(...deadlines)-Date.now());const timer=setTimeout(()=>clear(),wait);return()=>clearTimeout(timer);},[privateData,retry,clear]);
 const visible=connection==='ready'&&!privateCleared(frame,room.room_id,prefs.owner_member_id)?privateData:empty();
 const invitation=visible.invitation&&Date.parse(visible.invitation.expires_at)>clock?visible.invitation:null;
 const prompt=visible.prompt&&Date.parse(visible.prompt.expires_at)>clock?visible.prompt:null;
 const action=visible.action&&Date.parse(visible.action.expires_at)>clock?visible.action:null;
 const round=game?.current_round,active=game?.state==='active'||game?.state==='paused',currentPath=game&&round?`${base}/${game.session_id}/round/${round.round_id}`:'';
 const renderedScope={room:room.room_id,member:prefs.owner_member_id,identity:authToken.identity,transport:authToken.transport,session:game?.session_id??null,round:round?.round_id??null};
 function currentContext():RetryContext {const value=boundary.sameIdentity(gameScope.current)?gameRef.current:null;return {...boundary.current,session:value?.session_id??null,round:value?.current_round?.round_id??null,grants:grants(boundary.sameTransport(privateScope.current)?privateRef.current:empty())};}
 function allowed(scope:RetryScope) {wall.current=Math.max(wall.current,Date.now());return alive.current&&retryAllowed(scope,currentContext(),wall.current);}
 async function attempt(id:number,safety=false) {
  const entry=vault.current.get(id);if(!entry?.operation) return;if(!allowed(entry.scope)) {vault.current.clear();setRetry(null);return;}
  if(!safety&&ordinaryLock.current) return;if(!safety) ordinaryLock.current=true;
  epoch.current++;const generation=++operations.current;const current=()=>alive.current&&operations.current===generation&&allowed(entry.scope);
  (safety?setSafetyPending:setPending)(true);setError('');
  try {let execute:RetryOperation|null=entry.operation;const result=execute(current);execute=null;await result;
   if(alive.current&&generation===operations.current) {vault.current.clear();setRetry(null);epoch.current++;await sync();await refreshRef.current();}
  } catch(e) {if(alive.current&&generation===operations.current) {if(!allowed(entry.scope)) {vault.current.clear();setRetry(null);}setError(e instanceof ApiError?e.code:'SERVICE_UNAVAILABLE');if(e instanceof ApiError&&entry.scope.kind==='setup'&&['REVISION_CONFLICT','GAME_SETUP_CHANGED','PLAYERS_NOT_READY'].includes(e.code)) {vault.current.clear();setRetry(null);setAvailability(null);try {await refreshRef.current();await sync();} catch(refreshError) {onErrorRef.current(refreshError);}}if(e instanceof ApiError&&['ENTRY_REACCEPT_REQUIRED','AUTH_REQUIRED'].includes(e.code)) {clear();onErrorRef.current(e);}if(e instanceof ApiError&&/CONSENT|STALE|NOT_FOUND|ROUND_NOT_ACTIVE/.test(e.code)) clear();}}
  finally {if(!safety) ordinaryLock.current=false;if(alive.current) (safety?setSafetyPending:setPending)(false);}
 }
 function run(operation:RetryOperation,safety=false,kind:RetryKind='public',grant?:Grant) {
  const scope:RetryScope={...renderedScope,kind,offer:grant?.offer??null,proposal:grant?.proposal??null,deadline:grant?.deadline??null};
  if(!allowed(scope)) return Promise.resolve();if(safety) clear();const id=vault.current.install(operation,scope);setRetry(id);return attempt(id,safety);
 }
 // A newer shared frame may revoke controls before passive effects publish its
 // GameView. It must never authorize a request whose body still uses old JSX.
 const can=(action:OwnAction)=>action==='neutral_reset'||game?.session_id===controlToken.session&&(['stop','abort','pause'].includes(action)||game.game_rev===controlToken.rev&&(game.current_round?.round_id??null)===controlToken.round)?controls.allowed(action,controlToken,Date.now()):false;
 function mutation(path:string,body:unknown,safety=false,kind:RetryKind='public',grant?:Grant,own?:OwnAction) {if(own&&!can(own))return;void run(async current=>{if(own&&!can(own))return;await api.request(path,body);if(!current())return;},safety,kind,grant);}
 function response(kind:'accept'|'decline'|'skip'|'stop',scope?:'invitation'|'action') {if(!game||!round) return;const own:OwnAction=kind==='skip'?'skip':kind==='stop'?'withdraw_action':kind==='decline'?(scope==='action'?'withdraw_action':'decline_invitation'):scope==='invitation'?'accept_invitation':'accept_action';if(!can(own))return;const offer=scope==='invitation'?invitation:action;mutation(currentPath+'/response',{kind,request_id:crypto.randomUUID(),...(scope&&offer?{scope,offer_id:offer.offer_id,proposal_revision:offer.proposal_revision}:{})},kind!=='accept',kind==='accept'&&scope?scope:'public',kind==='accept'?grants(visible).find(g=>g.kind===scope):undefined,own);}
 async function prepare() {
  const intent={mode,players:[...players],round_count:rounds,idempotency_key:crypto.randomUUID()},previous=gameRef.current?.session_id;let preparedInput:ReturnType<typeof freshPreparation>|null=null;
  roomStream.current=boundary.sameIdentity(gameScope.current)?Math.max(roomStream.current,room.room_rev):room.room_rev;
  await run(async current=>{if(!preparedInput) {const fresh=await api.request<RoomView>(`/api/v1/rooms/${room.room_id}`);if(!current()) return;preparedInput=freshPreparation(room,fresh,intent);roomStream.current=Math.max(roomStream.current,fresh.room_rev);}const result=await api.request<GameView>(base+'/prepare',preparedInput);if(!current()) return;
   const known=gameRef.current?.session_id;if(known&&known!==previous&&known!==result.session_id) return;if(!update(result,authToken)) return;setAvailability(null);
   const a=await api.request<Availability>(base+'/availability');if(current()&&gameRef.current?.session_id===result.session_id&&gameRef.current.game_rev===a.draft_rev) setAvailability({scope:authToken,session:result.session_id,value:a});
  },false,'setup');
 }
 const canSetup=!game||['draft','waiting','completed','aborted'].includes(game.state),selected=room.members.filter(m=>players.includes(m.id)),ready=selected.length===players.length&&selected.length>=2&&selected.length<=8&&selected.every(m=>m.setup_ready);
 const ownRelations=Object.entries(prefs.edges).map(([id,edge])=>({name:room.members.find(m=>m.id===id)?.display_name??'',relation:edge.relation}));
 const relationLabels:Record<string,readonly [string,string,string]>={just_met:['Недавно знакомы','Just met','Yeni tanıştık'],friendship:['Дружба','Friendship','Arkadaşlık'],crush:['Симпатия','Crush','Hoşlanma'],situationship:['Неопределённость','Situationship','Belirsiz ilişki'],in_relationships:['Отношения','In a relationship','İlişki'],not_a_friend:['Не друзья','Not friends','Arkadaş değiliz']};
 const publicText=round?.kind==='public'?(round.mode==='questions'?round.text.question:round.mode==='truth_or_dare'?round.text?.prompt:round.text.proposal):null;
 return <section className="games-panel panel" data-testid="games-panel" aria-labelledby="games-title">
  <header className="game-heading"><div><p className="eyebrow">VENUS</p><h2 id="games-title">{c.title}</h2></div>{game?<p role="status" data-testid="game-state">{c[game.mode]} · {c[game.state]}</p>:null}</header>
  {connection!=='ready'?<p className="notice" role="status">{c.offline}</p>:null}
  {room.features.games==='unavailable'?<p className="notice" data-testid="games-unavailable">{c.unavailable}</p>:null}
  {error?<div className="notice error" role="alert" data-testid="game-error"><p>{gameError(c,error)}</p>{retry!==null&&boundary.vault.get(retry)?<button type="button" data-testid="game-retry" onClick={()=>void attempt(retry)} disabled={pending}>{c.retry}</button>:null}<button type="button" data-testid="game-refresh" onClick={()=>{if(!boundary.sameIdentity(authToken)) return;clear();setAvailability(null);setError('');void refreshRef.current().then(()=>sync()).catch(e=>setError(e instanceof ApiError?e.code:'SERVICE_UNAVAILABLE'));}}>{c.refresh}</button></div>:null}
  {canSetup&&host?<form onSubmit={e=>{e.preventDefault();void prepare();}} className="game-setup">
   <label>{c.mode}<select data-testid="game-mode" disabled={pending} value={mode} onChange={e=>{setMode(e.target.value as GameView['mode']);setAvailability(null);}}>{modes.map(m=><option key={m} value={m}>{c[m]}</option>)}</select></label>
   <fieldset><legend>{c.players}</legend>{room.members.map(m=><label className="check" key={m.id}><input data-testid={'game-player-'+m.id} type="checkbox" checked={players.includes(m.id)} disabled={pending} onChange={e=>{setPlayers(old=>e.target.checked?[...old,m.id]:old.filter(id=>id!==m.id));setAvailability(null);}}/><span>{m.display_name} · {m.setup_ready?'✓':'…'}</span></label>)}<button type="button" data-testid="game-reset-selection" disabled={pending} onClick={()=>{setPlayers(room.members.map(m=>m.id));setAvailability(null);}}>{c.resetSelection}</button></fieldset>
   <label>{c.rounds}<input data-testid="game-rounds" type="number" min="1" max="100" required value={Number.isNaN(rounds)?'':rounds} disabled={pending} onChange={e=>{setRounds(e.target.valueAsNumber);setAvailability(null);}}/></label>
   {!ready?<p className="hint">{c.notReady}</p>:null}<button className="primary" data-testid="game-prepare" disabled={pending||!ready||!Number.isInteger(rounds)||rounds<1||rounds>100}>{pending?c.saving:c.prepare}</button>
   <details><summary>{c.ownSummary}</summary><p>{c.comfort}: {prefs.comfort}</p><ul>{ownRelations.map((r,i)=><li key={i}>{r.name}: {relationLabels[r.relation]?.[{ru:0,en:1,tr:2}[locale]]}</li>)}</ul></details>
   {availability?<section className="notice" data-testid="game-availability"><h3>{c.review}</h3><p>{c[mode]} · {room.meeting_context==='online'?c.contextOnline:c.contextInPerson} · {rounds}</p><p>{selected.map(m=>m.display_name).join(' · ')}</p><p>{availability.available?c.available:c.insufficient}</p><button type="button" className="primary" data-testid="game-start" disabled={pending||!availability.available||game?.state!=='waiting'||availability.draft_rev!==game.game_rev} onClick={()=>mutation(base+'/start',{draft_rev:availability.draft_rev,idempotency_key:crypto.randomUUID()})}>{c.start}</button></section>:null}
  </form>:canSetup&&!host?<p>{c.waiting}</p>:null}
  {game&&active?<>
   <p className="hint">{c.frozen}</p><p role="status" className="round-progress" data-testid="game-round">{c.round} {round?.round_index??0} / {game.total_rounds}</p>
   {game.state==='paused'?<p className="notice">{game.pause_reason?c[game.pause_reason]:c.paused}</p>:null}
   {round?<article className="game-card" aria-label={c.round}>{round.kind==='generic'?<p>{c.generic}</p>:<><p data-testid="game-prompt" data-card-id={round.card_id} data-card-revision={round.card_revision} className="game-prompt">{publicText??c.choose}</p>{round.kind==='public'&&round.mode==='yes_but'?<p>{round.text.responder}</p>:null}{round.kind==='public'&&round.actors.length?<p>{round.actors.map(id=>room.members.find(m=>m.id===id)?.display_name??'').join(' · ')}</p>:null}</>}</article>:null}
   {invitation&&!prompt?<section className="private-panel" data-testid="pair-invitation"><h3>{c.invitationTitle}</h3><p>{invitation.invitation}</p><p>{c.invitationHint}</p><p>{c.expires}: {new Date(invitation.expires_at).toLocaleTimeString(locale)}</p><div className="actions"><button className="primary" data-testid="pair-accept" disabled={pending||invitation.own_state==='accepted'||!can('accept_invitation')} onClick={()=>response('accept','invitation')}>{invitation.own_state==='accepted'?c.accepted:c.accept}</button><button data-testid="pair-decline" disabled={!can('decline_invitation')} onClick={()=>response('decline','invitation')}>{c.decline}</button><button type="button" onClick={e=>e.currentTarget.blur()}>{c.wait}</button></div></section>:null}
   {prompt?<section className="private-panel" data-testid="private-prompt"><h3>{c.privateTitle}</h3><p className="game-prompt">{prompt.prompt}</p><p className="hint">{c.privateHint}</p></section>:null}
   {game.mode==='truth_or_dare'&&round&&(can('choose_truth')||can('choose_dare'))?<div className="actions"><button data-testid="game-truth" disabled={pending||!can('choose_truth')} onClick={()=>mutation(currentPath+'/choice',{side:'truth',request_id:crypto.randomUUID()},false,'public',undefined,'choose_truth')}>{c.truth}</button><button data-testid="game-dare" disabled={pending||!can('choose_dare')} onClick={()=>mutation(currentPath+'/choice',{side:'dare',request_id:crypto.randomUUID()},false,'public',undefined,'choose_dare')}>{c.dare}</button></div>:null}
   {visible.condition&&action&&visible.condition.proposal_revision===action.proposal_revision?<section className="private-panel" data-testid="game-current-condition"><h3>{c.conditionCurrent}</h3><p>{visible.condition.condition}</p></section>:null}
   {game.mode==='yes_but'&&can('propose_condition')&&action?.state==='pending'?<form className="private-panel" onSubmit={e=>{e.preventDefault();if(!validCondition(condition)||!can('propose_condition')) return;mutation(currentPath+'/condition',{condition,offer_id:action.offer_id,proposal_revision:action.proposal_revision,request_id:crypto.randomUUID()},false,'condition',grants(visible).find(g=>g.kind==='condition'),'propose_condition');}}><p className="hint">{c.conditionHint}</p><label>{c.condition}<textarea data-testid="game-condition-input" value={condition} maxLength={4000} onChange={e=>setCondition(e.target.value)} required/></label><button data-testid="game-condition-submit" disabled={pending||!validCondition(condition)||!can('propose_condition')}>{c.conditionSubmit}</button></form>:null}
   {action&&['pending','active'].includes(action.state)?<section className="private-panel" data-testid="action-consent"><h3>{c.actionTitle} · {action.proposal_revision}</h3><p>{c.quiet}</p><div className="actions"><button className="primary" data-testid="action-accept" disabled={pending||action.own_state==='accepted'||action.state!=='pending'||!can('accept_action')} onClick={()=>response('accept','action')}>{action.state==='active'?c.confirmed:action.own_state==='accepted'?c.accepted:c.actionAccept}</button><button data-testid="action-decline" disabled={!can('withdraw_action')} onClick={()=>response('decline','action')}>{c.decline}</button><button data-testid="action-withdraw" disabled={!can('withdraw_action')} onClick={()=>response('stop','action')}>{c.withdraw}</button></div></section>:null}
   {((!invitation||Boolean(prompt))&&can('decline_invitation')||!action&&can('withdraw_action'))?<section className="notice" data-testid="round-refusal-fallback"><h3>{c.roundRefusal}</h3><p>{c.roundRefusalHint}</p><div className="actions">{(!invitation||Boolean(prompt))&&can('decline_invitation')?<button data-testid="pair-decline" onClick={()=>response('decline','invitation')}>{c.decline}</button>:null}{!action&&can('withdraw_action')?<button data-testid="action-withdraw" onClick={()=>response('stop','action')}>{c.withdraw}</button>:null}</div></section>:null}
   {prompt&&room.meeting_context==='online'?<section className="private-panel" data-testid="pair-chat"><h3>{c.chat}</h3><p className="hint">{c.chatHint}</p>{visible.chat?<><ul className="chat-messages" data-testid="pair-chat-messages" aria-live="polite" aria-relevant="additions text">{visible.chat.messages.filter(m=>Date.parse(m.expires_at)>clock).map(m=><li key={m.message_id}><strong>{room.members.find(p=>p.id===m.sender_member_id)?.display_name??''}</strong><p>{m.text}</p></li>)}</ul><form onSubmit={e=>{e.preventDefault();if(!validChat(text)) return;const input={text,request_id:crypto.randomUUID()};void run(async current=>{await api.request(currentPath+'/chat',input);if(current()) setText('');},false,'chat',grants(visible).find(g=>g.kind==='chat'));}}><label>{c.chatInput}<textarea data-testid="pair-chat-input" value={text} maxLength={2000} onChange={e=>setText(e.target.value)} required/></label><button data-testid="pair-chat-send" disabled={pending||!validChat(text)}>{c.send}</button></form></>:<p>{c.chatUnavailable}</p>}</section>:null}
   {connection==='ready'&&[privateData.invitation,privateData.prompt,privateData.action].some(v=>v&&Date.parse(v.expires_at)<=clock)?<p role="status">{c.expired}</p>:null}
   <div className="actions game-transport">{round&&can('finish')?<button data-testid="game-finish" disabled={pending||!can('finish')} onClick={()=>mutation(currentPath+'/finish',{request_id:crypto.randomUUID()},false,'public',undefined,'finish')}>{c.finish}</button>:null}{can('advance')?<button className="primary" data-testid="game-next" disabled={pending} onClick={()=>mutation(`${base}/${game.session_id}/round/advance`,{expected_rev:game.game_rev,idempotency_key:crypto.randomUUID()},false,'public',undefined,'advance')}>{c.next}</button>:null}{can('resume')?<button data-testid="game-resume" disabled={pending} onClick={()=>mutation(`${base}/${game.session_id}/resume`,{expected_rev:game.game_rev,idempotency_key:crypto.randomUUID()},false,'public',undefined,'resume')}>{c.resume}</button>:null}</div>
   <aside className="safety-controls" aria-label={c.safetyHint}><p>{c.safetyHint}</p><div className="actions">{round&&can('skip')?<button data-testid="game-skip" onClick={()=>response('skip')}>{c.skip}</button>:null}{can('pause')?<button data-testid="game-pause" onClick={()=>mutation(`${base}/${game.session_id}/pause`,{expected_rev:game.game_rev,idempotency_key:crypto.randomUUID()},true,'public',undefined,'pause')}>{c.pause}</button>:null}{can('abort')||can('stop')?<button className="danger" data-testid="game-stop" onClick={()=>mutation(`${base}/${game.session_id}/${can('abort')?'abort':'stop'}`,{request_id:crypto.randomUUID()},true,'public',undefined,can('abort')?'abort':'stop')}>{can('abort')?c.abort:c.stop}</button>:null}<button data-testid="game-neutral-reset" onClick={()=>mutation(`/api/v1/rooms/${room.room_id}/me/setup/skip`,{expected_rev:prefs.rev,idempotency_key:crypto.randomUUID()},true,'public',undefined,'neutral_reset')}>{controls.resetAborts(clock)?c.neutralReset:c.neutralResetOwn}</button></div>{controls.unconfirmed(clock)?<p role="status" data-testid="game-safety-unconfirmed">{c.safetyUnconfirmed}</p>:null}{safetyPending?<p role="status">{c.saving}</p>:null}</aside>
  </>:null}
  {game&&['completed','aborted'].includes(game.state)?<section className="game-end"><h3>{c[game.state]}</h3><p>{c.noCamera}</p>{host?<button data-testid="game-replay" onClick={()=>{clear();setAvailability(null);setError('');void prepare();}} disabled={pending}>{c.replay}</button>:null}</section>:null}
  <p className="hint">{c.noCamera}</p>
 </section>;
}
