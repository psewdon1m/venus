import {describe,it,expect,vi} from 'vitest';
import type pg from 'pg';
import type {GameView} from '@venus/contracts';
import {Rooms,gameDeliveryFence,type RoomGameHooks,type FencedGameView} from './rooms.js';
import type {RoomPrivateProtocolHooks} from './room-private-protocol.js';
function fixture() {
 let now=100,retired=false,deleted=false,offer={version:'mock',digest:'digest'},generation='7';
 const room={id:'room',private_protocol:2,state:'open',rev:'1',last_activity_at:new Date(0)},member={id:'member',room_id:'room',slot:0,locale:'en',socket_generation:'7'};
 let expiry=1000;
 const hooks={guard:vi.fn(async()=>()=>{if(retired)throw new Error('EXTERNAL_RETIRED');})} as unknown as RoomPrivateProtocolHooks;
 const query=vi.fn(async(sql:string)=>{
  if(sql==='SELECT * FROM rooms WHERE id=$1 FOR UPDATE')return {rows:[room]};
  if(sql.startsWith('SELECT m.*'))return {rows:[member]};
  if(sql.startsWith('SELECT offer_version'))return {rows:[{offer_version:offer.version,offer_digest:offer.digest}]};
  if(sql.startsWith('SELECT s.expires_at'))return {rows:[{expires_at:new Date(expiry),offer_version:'mock',offer_digest:'digest',socket_generation:generation,slot:member.slot}]};
  if(['BEGIN','COMMIT','ROLLBACK'].includes(sql)||sql.startsWith('SELECT pg_advisory'))return {rows:[]};
  throw new Error('Unexpected query '+sql);
 });
 const c={query,release:vi.fn()} as unknown as pg.PoolClient,pool={connect:async()=>c} as unknown as pg.Pool;
 const rooms=new Rooms({pool,keys:{} as Rooms['options']['keys'],ledger:{contains:()=>deleted} as Rooms['options']['ledger'],origin:'https://localhost',offer:()=>({...offer,synthetic:true,text:{en:'',ru:'',tr:''}}),now:()=>now,privateProtocol:hooks});
 const a={room,member,sessionHash:'session'} as Awaited<ReturnType<Rooms['access']>>;
 const grant={roomId:room.id,memberId:member.id,generation:7,sessionHash:'session'};
 return {rooms,room,member,c,query,hooks,a,grant,setNow:(n:number)=>{now=n;},expire:()=>{expiry=99;},retire:()=>{retired=true;},remove:()=>{deleted=true;},changeOffer:()=>{offer={version:'new',digest:'new'};},replaceSocket:()=>{generation='8';}};
}
describe('protocol2 final credential and exact-value delivery fences',()=>{
 it('rechecks clock at invocation rather than capturing the earlier clock',async()=>{
  const f=fixture(),fence=await f.rooms.finalAccessFence(f.c,f.a);f.setNow(1000);expect(fence).toThrow(expect.objectContaining({code:'AUTH_REQUIRED'}));
 });
 it('rechecks external withdrawal after the last awaited SQL read',async()=>{
  const f=fixture(),fence=await f.rooms.finalAccessFence(f.c,f.a);f.retire();expect(fence).toThrow('EXTERNAL_RETIRED');
 });
 it('does not make safety actions depend on current offer acceptance',async()=>{
  const f=fixture(),fence=await f.rooms.finalAccessFence(f.c,f.a,true);f.changeOffer();expect(fence).not.toThrow();
 });
 it('normal delivery requires the current offer at actual publication',async()=>{
  const f=fixture(),fence=await f.rooms.finalAccessFence(f.c,f.a);f.changeOffer();expect(fence).toThrow(expect.objectContaining({code:'ENTRY_REACCEPT_REQUIRED'}));
 });
 it('retains room deletion and idle expiry fences even for safety actions',async()=>{
  const f=fixture(),fence=await f.rooms.finalAccessFence(f.c,f.a,true);f.remove();expect(fence).toThrow(expect.objectContaining({code:'ROOM_CLOSED'}));
 });
 for(const cut of ['child-expiry','sql-expiry','socket','withdrawal','child-fence'] as const)it(`does not enqueue a public game across ${cut}`,async()=>{
  const f=fixture(),enqueue=vi.fn(),ownFence=vi.fn(()=>{if(cut==='child-fence')throw new Error('TOPIC_EPOCH_CHANGED');});
  const view=Object.assign({} as GameView,{[gameDeliveryFence]:ownFence});
  f.rooms.attachGames({publicDelivery:async()=>{if(cut==='child-expiry')f.setNow(1000);if(cut==='socket')f.replaceSocket();if(cut==='withdrawal')f.retire();return view;}} as unknown as RoomGameHooks);
  if(cut==='sql-expiry'){const original=f.query.getMockImplementation()!;f.query.mockImplementation(async sql=>{const value=await original(sql);if(sql.startsWith('SELECT s.expires_at'))f.setNow(1000);return value;});}
  await expect(f.rooms.dispatchGame(f.grant,enqueue)).rejects.toBeDefined();expect(enqueue).not.toHaveBeenCalled();expect(f.query.mock.calls.at(-1)?.[0]).toBe('ROLLBACK');
 });
 it('rejects a child DTO without its exact publication capability',async()=>{
  const f=fixture(),enqueue=vi.fn();f.rooms.attachGames({publicDelivery:async()=>({})} as unknown as RoomGameHooks);
  await expect(f.rooms.dispatchGame(f.grant,enqueue)).rejects.toMatchObject({code:'GAME_DELIVERY_FENCE_REQUIRED'});expect(enqueue).not.toHaveBeenCalled();
 });
 it('invokes the exact DTO fence after the final SQL and immediately before enqueue',async()=>{
  const f=fixture(),trace:string[]=[],view={} as FencedGameView;
  Object.defineProperty(view,gameDeliveryFence,{value:()=>{trace.push('child-fence');}});
  const original=f.query.getMockImplementation()!;f.query.mockImplementation(async sql=>{const value=await original(sql);if(sql.startsWith('SELECT s.expires_at'))trace.push('credential-read');return value;});
  f.rooms.attachGames({publicDelivery:async()=>view} as unknown as RoomGameHooks);
  await f.rooms.dispatchGame(f.grant,()=>{trace.push('enqueue');});expect(trace).toEqual(['credential-read','child-fence','enqueue']);expect(JSON.stringify(view)).toBe('{}');
 });
 it('cannot use protocol2 without its mandatory external lifecycle implementation',async()=>{
  const f=fixture(),rooms=new Rooms({...f.rooms.options,privateProtocol:undefined});
  await expect(rooms.finalAccessFence(f.c,f.a)).rejects.toMatchObject({code:'PRIVATE_PROTOCOL_UNAVAILABLE'});expect(f.query).not.toHaveBeenCalled();
 });
});
