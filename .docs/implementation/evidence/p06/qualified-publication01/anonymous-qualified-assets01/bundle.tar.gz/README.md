Venus standalone local-pilot release. Operator runtime uses the verified installed template; archive contents are never executed.
